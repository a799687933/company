
-- -----------------------------
-- Table structure for `xt_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `xt_action_log`;
CREATE TABLE `xt_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行会员id',
  `username` char(30) NOT NULL DEFAULT '' COMMENT '用户名',
  `ip` char(30) NOT NULL DEFAULT '' COMMENT '执行行为者ip',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '行为名称',
  `describe` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '执行的URL',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2635 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- -----------------------------
-- Records of `xt_action_log`
-- -----------------------------
INSERT INTO `xt_action_log` VALUES ('1874', '1098', '888888', '192.168.0.141', '登录', '登录操作，username：888888', '/s8726/public/admin/login/loginhandle.html', '1', '1535189040', '1535189040');
INSERT INTO `xt_action_log` VALUES ('1873', '1', '100000', '192.168.0.141', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535189000', '1535189000');
INSERT INTO `xt_action_log` VALUES ('1872', '1097', '444444', '192.168.0.141', '登录', '登录操作，username：444444', '/s8726/public/admin/login/loginhandle.html', '1', '1535188729', '1535188729');
INSERT INTO `xt_action_log` VALUES ('1871', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535188357', '1535188357');
INSERT INTO `xt_action_log` VALUES ('1870', '1096', '777777', '127.0.0.1', '登录', '登录操作，username：777777', '/s8726/public/admin/login/loginhandle.html', '1', '1535187768', '1535187768');
INSERT INTO `xt_action_log` VALUES ('1869', '1096', '777777', '127.0.0.1', '登录', '登录操作，username：777777', '/s8726/public/admin/login/loginhandle.html', '1', '1535187706', '1535187706');
INSERT INTO `xt_action_log` VALUES ('1868', '1095', '666666', '127.0.0.1', '登录', '登录操作，username：666666', '/s8726/public/admin/login/loginhandle.html', '1', '1535186639', '1535186639');
INSERT INTO `xt_action_log` VALUES ('1867', '1094', '555555', '127.0.0.1', '登录', '登录操作，username：555555', '/s8726/public/admin/login/loginhandle.html', '1', '1535186547', '1535186547');
INSERT INTO `xt_action_log` VALUES ('1866', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535186133', '1535186133');
INSERT INTO `xt_action_log` VALUES ('1865', '1094', '555555', '127.0.0.1', '登录', '登录操作，username：555555', '/s8726/public/admin/login/loginhandle.html', '1', '1535186033', '1535186033');
INSERT INTO `xt_action_log` VALUES ('1864', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535184910', '1535184910');
INSERT INTO `xt_action_log` VALUES ('1863', '1091', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535181694', '1535181694');
INSERT INTO `xt_action_log` VALUES ('1862', '1091', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535181641', '1535181641');
INSERT INTO `xt_action_log` VALUES ('1861', '1', '100000', '192.168.0.141', '编辑', '编辑会员，id：1093', '/s8726/public/admin/member/memberedit.html', '1', '1535181555', '1535181555');
INSERT INTO `xt_action_log` VALUES ('1860', '1093', '333333', '192.168.0.141', '登录', '登录操作，username：333333', '/s8726/public/admin/login/loginhandle.html', '1', '1535181541', '1535181541');
INSERT INTO `xt_action_log` VALUES ('1859', '1091', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535181244', '1535181244');
INSERT INTO `xt_action_log` VALUES ('1858', '1092', '222222', '192.168.0.141', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1535181230', '1535181230');
INSERT INTO `xt_action_log` VALUES ('1857', '1', '100000', '192.168.0.141', '编辑', '编辑会员，id：1092', '/s8726/public/admin/member/memberedit.html', '1', '1535181109', '1535181109');
INSERT INTO `xt_action_log` VALUES ('1856', '1092', '222222', '192.168.0.141', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1535181093', '1535181093');
INSERT INTO `xt_action_log` VALUES ('1855', '1091', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535180899', '1535180899');
INSERT INTO `xt_action_log` VALUES ('1854', '1091', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535180636', '1535180636');
INSERT INTO `xt_action_log` VALUES ('1853', '1', '100000', '192.168.0.141', '编辑', '编辑会员，id：1091', '/s8726/public/admin/member/memberedit.html', '1', '1535180605', '1535180605');
INSERT INTO `xt_action_log` VALUES ('1852', '1091', '111111', '192.168.0.141', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535180559', '1535180559');
INSERT INTO `xt_action_log` VALUES ('1851', '1', '100000', '192.168.0.141', '编辑', '编辑会员，id：1090', '/s8726/public/admin/member/memberedit.html', '1', '1535179485', '1535179485');
INSERT INTO `xt_action_log` VALUES ('1850', '1090', '111111', '192.168.0.141', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535179465', '1535179465');
INSERT INTO `xt_action_log` VALUES ('1849', '1089', '222222', '127.0.0.1', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1535179204', '1535179204');
INSERT INTO `xt_action_log` VALUES ('1848', '1089', '222222', '127.0.0.1', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1535171195', '1535171195');
INSERT INTO `xt_action_log` VALUES ('1847', '1088', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535171076', '1535171076');
INSERT INTO `xt_action_log` VALUES ('1846', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535171007', '1535171007');
INSERT INTO `xt_action_log` VALUES ('1845', '1088', '111111', '192.168.0.141', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535170940', '1535170940');
INSERT INTO `xt_action_log` VALUES ('1844', '1088', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535170584', '1535170584');
INSERT INTO `xt_action_log` VALUES ('1843', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1088', '/s8726/public/admin/member/memberedit.html', '1', '1535170560', '1535170560');
INSERT INTO `xt_action_log` VALUES ('1842', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535170542', '1535170542');
INSERT INTO `xt_action_log` VALUES ('1841', '1088', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535170456', '1535170456');
INSERT INTO `xt_action_log` VALUES ('1840', '1083', '111111', '192.168.0.141', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535170245', '1535170245');
INSERT INTO `xt_action_log` VALUES ('1839', '1', '100000', '192.168.0.141', '编辑', '编辑会员，id：1083', '/s8726/public/admin/member/memberedit.html', '1', '1535170220', '1535170220');
INSERT INTO `xt_action_log` VALUES ('1838', '1', '100000', '127.0.0.1', '删除', '删除会员，where：id=1085', '/s8726/public/admin/member/memberdel/id/1085.html', '1', '1535169155', '1535169155');
INSERT INTO `xt_action_log` VALUES ('1837', '1', '100000', '127.0.0.1', '删除', '删除会员，where：id=1086', '/s8726/public/admin/member/memberdel/id/1086.html', '1', '1535169151', '1535169151');
INSERT INTO `xt_action_log` VALUES ('1836', '1', '100000', '127.0.0.1', '删除', '删除会员，where：id=1087', '/s8726/public/admin/member/memberdel/id/1087.html', '1', '1535169140', '1535169140');
INSERT INTO `xt_action_log` VALUES ('1835', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535169122', '1535169122');
INSERT INTO `xt_action_log` VALUES ('1834', '1084', '444444', '127.0.0.1', '登录', '登录操作，username：444444', '/s8726/public/admin/login/loginhandle.html', '1', '1535168187', '1535168187');
INSERT INTO `xt_action_log` VALUES ('1833', '1082', '333333', '127.0.0.1', '登录', '登录操作，username：333333', '/s8726/public/admin/login/loginhandle.html', '1', '1535168101', '1535168101');
INSERT INTO `xt_action_log` VALUES ('1832', '1078', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1535167866', '1535167866');
INSERT INTO `xt_action_log` VALUES ('1831', '1081', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535167768', '1535167768');
INSERT INTO `xt_action_log` VALUES ('1830', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1081', '/s8726/public/admin/member/memberedit.html', '1', '1535167716', '1535167716');
INSERT INTO `xt_action_log` VALUES ('1829', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1081', '/s8726/public/admin/member/memberedit.html', '1', '1535167685', '1535167685');
INSERT INTO `xt_action_log` VALUES ('1828', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1081', '/s8726/public/admin/member/memberedit.html', '1', '1535167592', '1535167592');
INSERT INTO `xt_action_log` VALUES ('1827', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1081', '/s8726/public/admin/member/memberedit.html', '1', '1535167536', '1535167536');
INSERT INTO `xt_action_log` VALUES ('1826', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535167492', '1535167492');
INSERT INTO `xt_action_log` VALUES ('1825', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1081', '/s8726/public/admin/member/memberedit.html', '1', '1535167045', '1535167045');
INSERT INTO `xt_action_log` VALUES ('1824', '1081', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535166609', '1535166609');
INSERT INTO `xt_action_log` VALUES ('1823', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535166109', '1535166109');
INSERT INTO `xt_action_log` VALUES ('1822', '1078', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1535165916', '1535165916');
INSERT INTO `xt_action_log` VALUES ('1821', '1079', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535162915', '1535162915');
INSERT INTO `xt_action_log` VALUES ('1820', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535162702', '1535162702');
INSERT INTO `xt_action_log` VALUES ('1819', '1', '100000', '192.168.0.141', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535162366', '1535162366');
INSERT INTO `xt_action_log` VALUES ('1818', '1', '100000', '192.168.0.141', '编辑', '编辑会员，id：1080', '/s8726/public/admin/member/memberedit.html', '1', '1535162182', '1535162182');
INSERT INTO `xt_action_log` VALUES ('1817', '1080', '222222', '192.168.0.141', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1535162165', '1535162165');
INSERT INTO `xt_action_log` VALUES ('1816', '1', '100000', '192.168.0.141', '数据状态', '数据状态调整，model：Shop，ids：59,58,57,56,55，status：-1', '/s8726/public/admin/shopadmin/setstatus.html', '1', '1535161927', '1535161927');
INSERT INTO `xt_action_log` VALUES ('1815', '1', '100000', '192.168.0.141', '编辑', '编辑会员，id：1079', '/s8726/public/admin/member/memberedit.html', '1', '1535161906', '1535161906');
INSERT INTO `xt_action_log` VALUES ('1814', '1079', '111111', '192.168.0.141', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535161881', '1535161881');
INSERT INTO `xt_action_log` VALUES ('1813', '1', '100000', '192.168.0.141', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535161813', '1535161813');
INSERT INTO `xt_action_log` VALUES ('1812', '1', '100000', '192.168.0.141', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535161685', '1535161685');
INSERT INTO `xt_action_log` VALUES ('1811', '1', '100000', '192.168.0.168', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535161284', '1535161284');
INSERT INTO `xt_action_log` VALUES ('1810', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535083216', '1535083216');
INSERT INTO `xt_action_log` VALUES ('1809', '1078', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1535082020', '1535082020');
INSERT INTO `xt_action_log` VALUES ('1808', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535081910', '1535081910');
INSERT INTO `xt_action_log` VALUES ('1807', '1078', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1535074047', '1535074047');
INSERT INTO `xt_action_log` VALUES ('1806', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535018485', '1535018485');
INSERT INTO `xt_action_log` VALUES ('1805', '1078', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1535018301', '1535018301');
INSERT INTO `xt_action_log` VALUES ('1804', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535018265', '1535018265');
INSERT INTO `xt_action_log` VALUES ('1803', '1078', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1535017366', '1535017366');
INSERT INTO `xt_action_log` VALUES ('1802', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535017321', '1535017321');
INSERT INTO `xt_action_log` VALUES ('1801', '1078', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1535016705', '1535016705');
INSERT INTO `xt_action_log` VALUES ('1800', '1078', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1535015837', '1535015837');
INSERT INTO `xt_action_log` VALUES ('1799', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535014593', '1535014593');
INSERT INTO `xt_action_log` VALUES ('1798', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535012187', '1535012187');
INSERT INTO `xt_action_log` VALUES ('1797', '1076', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1535011938', '1535011938');
INSERT INTO `xt_action_log` VALUES ('1796', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：reco', '/s8726/public/admin/config/configedit.html', '1', '1535011470', '1535011470');
INSERT INTO `xt_action_log` VALUES ('1795', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535009637', '1535009637');
INSERT INTO `xt_action_log` VALUES ('1794', '1', '100000', '127.0.0.1', '新增', '产品新增，name：343r3', '/s8726/public/admin/shopadmin/shopadd.html', '1', '1535007201', '1535007201');
INSERT INTO `xt_action_log` VALUES ('1793', '1', '100000', '127.0.0.1', '新增', '产品新增，name：4243232', '/s8726/public/admin/shopadmin/shopadd.html', '1', '1535007179', '1535007179');
INSERT INTO `xt_action_log` VALUES ('1792', '1', '100000', '127.0.0.1', '新增', '产品新增，name：2342342', '/s8726/public/admin/shopadmin/shopadd.html', '1', '1535007171', '1535007171');
INSERT INTO `xt_action_log` VALUES ('1791', '1', '100000', '127.0.0.1', '新增', '产品新增，name：1231231', '/s8726/public/admin/shopadmin/shopadd.html', '1', '1535007162', '1535007162');
INSERT INTO `xt_action_log` VALUES ('1790', '1', '100000', '127.0.0.1', '新增', '产品新增，name：3453533', '/s8726/public/admin/shopadmin/shopadd.html', '1', '1535007154', '1535007154');
INSERT INTO `xt_action_log` VALUES ('1789', '1', '100000', '127.0.0.1', '新增', '产品新增，name：消费品', '/s8726/public/admin/shopadmin/shopadd.html', '1', '1535006718', '1535006718');
INSERT INTO `xt_action_log` VALUES ('1788', '1', '100000', '127.0.0.1', '新增', '文章新增，name：312312321312', '/s8726/public/admin/article/articleadd.html', '1', '1535006408', '1535006408');
INSERT INTO `xt_action_log` VALUES ('1787', '1075', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535006179', '1535006179');
INSERT INTO `xt_action_log` VALUES ('1786', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535005960', '1535005960');
INSERT INTO `xt_action_log` VALUES ('1785', '1', '100000', '192.168.0.168', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535005900', '1535005900');
INSERT INTO `xt_action_log` VALUES ('1784', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：agent_income', '/s8726/public/admin/config/configedit.html', '1', '1534999314', '1534999314');
INSERT INTO `xt_action_log` VALUES ('1783', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534999150', '1534999150');
INSERT INTO `xt_action_log` VALUES ('1782', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534999120', '1534999120');
INSERT INTO `xt_action_log` VALUES ('1781', '1077', '222222', '127.0.0.1', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1534998116', '1534998116');
INSERT INTO `xt_action_log` VALUES ('1780', '1076', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1534998005', '1534998005');
INSERT INTO `xt_action_log` VALUES ('1779', '1075', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1534997849', '1534997849');
INSERT INTO `xt_action_log` VALUES ('1778', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534997773', '1534997773');
INSERT INTO `xt_action_log` VALUES ('1777', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534997661', '1534997661');
INSERT INTO `xt_action_log` VALUES ('1776', '1074', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1534996348', '1534996348');
INSERT INTO `xt_action_log` VALUES ('1775', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534994606', '1534994606');
INSERT INTO `xt_action_log` VALUES ('1774', '1074', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1534994546', '1534994546');
INSERT INTO `xt_action_log` VALUES ('1773', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534994231', '1534994231');
INSERT INTO `xt_action_log` VALUES ('1772', '1074', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1534994065', '1534994065');
INSERT INTO `xt_action_log` VALUES ('1771', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534993883', '1534993883');
INSERT INTO `xt_action_log` VALUES ('1770', '1074', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1534992799', '1534992799');
INSERT INTO `xt_action_log` VALUES ('1769', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534992732', '1534992732');
INSERT INTO `xt_action_log` VALUES ('1768', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534992112', '1534992112');
INSERT INTO `xt_action_log` VALUES ('1767', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1072', '/s8726/public/admin/member/memberedit.html', '1', '1534989972', '1534989972');
INSERT INTO `xt_action_log` VALUES ('1766', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534989948', '1534989948');
INSERT INTO `xt_action_log` VALUES ('1765', '1073', '111112', '127.0.0.1', '登录', '登录操作，username：111112', '/s8726/public/admin/login/loginhandle.html', '1', '1534989872', '1534989872');
INSERT INTO `xt_action_log` VALUES ('1764', '1072', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1534989283', '1534989283');
INSERT INTO `xt_action_log` VALUES ('1763', '1', '100000', '127.0.0.1', '新增', '新增菜单，name：会员提现', '/s8726/public/admin/menu/menuadd.html', '1', '1534989255', '1534989255');
INSERT INTO `xt_action_log` VALUES ('1762', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534988964', '1534988964');
INSERT INTO `xt_action_log` VALUES ('1761', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：产品浏览', '/s8726/public/admin/menu/menuedit.html', '1', '1534931744', '1534931744');
INSERT INTO `xt_action_log` VALUES ('1760', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534931538', '1534931538');
INSERT INTO `xt_action_log` VALUES ('1759', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534926697', '1534926697');
INSERT INTO `xt_action_log` VALUES ('1758', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534923456', '1534923456');
INSERT INTO `xt_action_log` VALUES ('1757', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534920786', '1534920786');
INSERT INTO `xt_action_log` VALUES ('1756', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534920578', '1534920578');
INSERT INTO `xt_action_log` VALUES ('1755', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534918158', '1534918158');
INSERT INTO `xt_action_log` VALUES ('1754', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534909023', '1534909023');
INSERT INTO `xt_action_log` VALUES ('1753', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534903343', '1534903343');
INSERT INTO `xt_action_log` VALUES ('1752', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534899123', '1534899123');
INSERT INTO `xt_action_log` VALUES ('1751', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534841438', '1534841438');
INSERT INTO `xt_action_log` VALUES ('1750', '1070', 'admin1', '127.0.0.1', '登录', '登录操作，username：admin1', '/s8726/public/admin/login/loginhandle.html', '1', '1534840873', '1534840873');
INSERT INTO `xt_action_log` VALUES ('1749', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534840819', '1534840819');
INSERT INTO `xt_action_log` VALUES ('1748', '1070', 'admin1', '127.0.0.1', '登录', '登录操作，username：admin1', '/s8726/public/admin/login/loginhandle.html', '1', '1534840685', '1534840685');
INSERT INTO `xt_action_log` VALUES ('1747', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534838565', '1534838565');
INSERT INTO `xt_action_log` VALUES ('1746', '1', '100000', '127.0.0.1', '新增', '新增菜单，name：会员充值', '/s8726/public/admin/menu/menuadd.html', '1', '1534823178', '1534823178');
INSERT INTO `xt_action_log` VALUES ('1745', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：产品浏览', '/s8726/public/admin/menu/menuedit.html', '1', '1534822955', '1534822955');
INSERT INTO `xt_action_log` VALUES ('1744', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：产品列表', '/s8726/public/admin/menu/menuedit.html', '1', '1534822903', '1534822903');
INSERT INTO `xt_action_log` VALUES ('1743', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：购物商城', '/s8726/public/admin/menu/menuedit.html', '1', '1534822873', '1534822873');
INSERT INTO `xt_action_log` VALUES ('1742', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：会员添加', '/s8726/public/admin/menu/menuedit.html', '1', '1534822754', '1534822754');
INSERT INTO `xt_action_log` VALUES ('1741', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534822731', '1534822731');
INSERT INTO `xt_action_log` VALUES ('1740', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534820478', '1534820478');
INSERT INTO `xt_action_log` VALUES ('1739', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534820457', '1534820457');
INSERT INTO `xt_action_log` VALUES ('1738', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534763284', '1534763284');
INSERT INTO `xt_action_log` VALUES ('1737', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534763232', '1534763232');
INSERT INTO `xt_action_log` VALUES ('1736', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534763189', '1534763189');
INSERT INTO `xt_action_log` VALUES ('1735', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534752838', '1534752838');
INSERT INTO `xt_action_log` VALUES ('1734', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534752812', '1534752812');
INSERT INTO `xt_action_log` VALUES ('1733', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534752314', '1534752314');
INSERT INTO `xt_action_log` VALUES ('1732', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534746149', '1534746149');
INSERT INTO `xt_action_log` VALUES ('1731', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534739824', '1534739824');
INSERT INTO `xt_action_log` VALUES ('1730', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534739646', '1534739646');
INSERT INTO `xt_action_log` VALUES ('1729', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534737471', '1534737471');
INSERT INTO `xt_action_log` VALUES ('1728', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534589205', '1534589205');
INSERT INTO `xt_action_log` VALUES ('1727', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534588932', '1534588932');
INSERT INTO `xt_action_log` VALUES ('1726', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534588743', '1534588743');
INSERT INTO `xt_action_log` VALUES ('1725', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534588044', '1534588044');
INSERT INTO `xt_action_log` VALUES ('1724', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：权限管理', '/s8726/public/admin/menu/menuedit.html', '1', '1534586780', '1534586780');
INSERT INTO `xt_action_log` VALUES ('1723', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534586086', '1534586086');
INSERT INTO `xt_action_log` VALUES ('1722', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：订单管理', '/s8726/public/admin/menu/menuedit.html', '1', '1534585512', '1534585512');
INSERT INTO `xt_action_log` VALUES ('1721', '1', '100000', '127.0.0.1', '数据状态', '数据状态调整，model：Menu，ids：219，status：-1', '/s8726/public/admin/menu/setstatus/ids/219/status/-1.html', '1', '1534585375', '1534585375');
INSERT INTO `xt_action_log` VALUES ('1720', '1', '100000', '127.0.0.1', '数据状态', '数据状态调整，model：Menu，ids：220，status：-1', '/s8726/public/admin/menu/setstatus/ids/220/status/-1.html', '1', '1534585371', '1534585371');
INSERT INTO `xt_action_log` VALUES ('1719', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：订单管理', '/s8726/public/admin/menu/menuedit.html', '1', '1534585215', '1534585215');
INSERT INTO `xt_action_log` VALUES ('1718', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534585098', '1534585098');
INSERT INTO `xt_action_log` VALUES ('1717', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534583904', '1534583904');
INSERT INTO `xt_action_log` VALUES ('1716', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534583496', '1534583496');
INSERT INTO `xt_action_log` VALUES ('1715', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534583469', '1534583469');
INSERT INTO `xt_action_log` VALUES ('1714', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1069', '/s8726/public/admin/member/memberedit.html', '1', '1534582206', '1534582206');
INSERT INTO `xt_action_log` VALUES ('1713', '1', '100000', '127.0.0.1', '编辑', '产品编辑，name：报单产品', '/s8726/public/admin/shopadmin/shopedit.html', '1', '1534582026', '1534582026');
INSERT INTO `xt_action_log` VALUES ('1712', '1', '100000', '127.0.0.1', '授权', '会员授权，id：1069', '/s8726/public/admin/member/memberauth.html', '1', '1534581961', '1534581961');
INSERT INTO `xt_action_log` VALUES ('1711', '1', '100000', '127.0.0.1', '新增', '新增会员，username：1231', '/s8726/public/admin/member/memberadd.html', '1', '1534581916', '1534581916');
INSERT INTO `xt_action_log` VALUES ('1710', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534581636', '1534581636');
INSERT INTO `xt_action_log` VALUES ('1709', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534581624', '1534581624');
INSERT INTO `xt_action_log` VALUES ('1708', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1068', '/s8726/public/admin/member/memberedit.html', '1', '1534578131', '1534578131');
INSERT INTO `xt_action_log` VALUES ('1707', '1', '100000', '127.0.0.1', '编辑', '产品编辑，name：报单产品', '/s8726/public/admin/shopadmin/shopedit.html', '1', '1534578041', '1534578041');
INSERT INTO `xt_action_log` VALUES ('1706', '1068', '1', '127.0.0.1', '登录', '登录操作，username：1', '/s8726/public/admin/login/loginhandle.html', '1', '1534577859', '1534577859');
INSERT INTO `xt_action_log` VALUES ('1705', '1', '100000', '127.0.0.1', '新增', '新增会员，username：1', '/s8726/public/admin/member/memberadd.html', '1', '1534577830', '1534577830');
INSERT INTO `xt_action_log` VALUES ('1704', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534575884', '1534575884');
INSERT INTO `xt_action_log` VALUES ('1703', '1', '100000', '127.0.0.1', '编辑', '分类编辑，name：商城消费', '/s8726/public/admin/shopadmin/shopcategoryedit.html', '1', '1534574274', '1534574274');
INSERT INTO `xt_action_log` VALUES ('1702', '1', '100000', '127.0.0.1', '编辑', '分类编辑，name：报单产品', '/s8726/public/admin/shopadmin/shopcategoryedit.html', '1', '1534574261', '1534574261');
INSERT INTO `xt_action_log` VALUES ('1701', '1', '100000', '127.0.0.1', '编辑', '产品编辑，name：报单产品', '/s8726/public/admin/shopadmin/shopedit.html', '1', '1534574238', '1534574238');
INSERT INTO `xt_action_log` VALUES ('1700', '1', '100000', '127.0.0.1', '编辑', '文章分类编辑，name：报单产品', '/s8726/public/admin/article/articlecategoryedit.html', '1', '1534573945', '1534573945');
INSERT INTO `xt_action_log` VALUES ('1699', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534573861', '1534573861');
INSERT INTO `xt_action_log` VALUES ('1698', '1', '100000', '127.0.0.1', '数据状态', '数据状态调整，model：Config，ids：55，status：-1', '/s8726/public/admin/config/setstatus/ids/55/status/-1.html', '1', '1534571556', '1534571556');
INSERT INTO `xt_action_log` VALUES ('1697', '1', '100000', '127.0.0.1', '数据状态', '数据状态调整，model：Config，ids：55，status：0', '/s8726/public/admin/config/setstatus/ids/55/status/0.html', '1', '1534571536', '1534571536');
INSERT INTO `xt_action_log` VALUES ('1696', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534571496', '1534571496');
INSERT INTO `xt_action_log` VALUES ('1695', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534571491', '1534571491');
INSERT INTO `xt_action_log` VALUES ('1694', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534571484', '1534571484');
INSERT INTO `xt_action_log` VALUES ('1693', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534571479', '1534571479');
INSERT INTO `xt_action_log` VALUES ('1692', '1', '100000', '127.0.0.1', '新增', '新增配置，name：agent_income', '/s8726/public/admin/config/configadd.html', '1', '1534571441', '1534571441');
INSERT INTO `xt_action_log` VALUES ('1691', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534571010', '1534571010');
INSERT INTO `xt_action_log` VALUES ('1690', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534559800', '1534559800');
INSERT INTO `xt_action_log` VALUES ('1689', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534559358', '1534559358');
INSERT INTO `xt_action_log` VALUES ('1688', '1067', '3242sss', '127.0.0.1', '登录', '登录操作，username：3242sss', '/s8726/public/admin/login/loginhandle.html', '1', '1534557317', '1534557317');
INSERT INTO `xt_action_log` VALUES ('1687', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534555666', '1534555666');
INSERT INTO `xt_action_log` VALUES ('1686', '1067', '3242sss', '127.0.0.1', '登录', '登录操作，username：3242sss', '/s8726/public/admin/login/loginhandle.html', '1', '1534555559', '1534555559');
INSERT INTO `xt_action_log` VALUES ('1685', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534517877', '1534517877');
INSERT INTO `xt_action_log` VALUES ('1684', '1067', '3242sss', '127.0.0.1', '登录', '登录操作，username：3242sss', '/s8726/public/admin/login/loginhandle.html', '1', '1534517719', '1534517719');
INSERT INTO `xt_action_log` VALUES ('1683', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534517236', '1534517236');
INSERT INTO `xt_action_log` VALUES ('1682', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534517199', '1534517199');
INSERT INTO `xt_action_log` VALUES ('1681', '1067', '3242sss', '127.0.0.1', '登录', '登录操作，username：3242sss', '/s8726/public/admin/login/loginhandle.html', '1', '1534514726', '1534514726');
INSERT INTO `xt_action_log` VALUES ('1680', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534514639', '1534514639');
INSERT INTO `xt_action_log` VALUES ('1679', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534514618', '1534514618');
INSERT INTO `xt_action_log` VALUES ('1678', '1067', '3242sss', '127.0.0.1', '登录', '登录操作，username：3242sss', '/s8726/public/admin/login/loginhandle.html', '1', '1534513464', '1534513464');
INSERT INTO `xt_action_log` VALUES ('1677', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534513436', '1534513436');
INSERT INTO `xt_action_log` VALUES ('1676', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534511822', '1534511822');
INSERT INTO `xt_action_log` VALUES ('1675', '1067', '3242sss', '127.0.0.1', '登录', '登录操作，username：3242sss', '/s8726/public/admin/login/loginhandle.html', '1', '1534511529', '1534511529');
INSERT INTO `xt_action_log` VALUES ('1674', '1064', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1534508611', '1534508611');
INSERT INTO `xt_action_log` VALUES ('1673', '1064', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1534499726', '1534499726');
INSERT INTO `xt_action_log` VALUES ('1672', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534499516', '1534499516');
INSERT INTO `xt_action_log` VALUES ('1671', '1064', '1000001', '127.0.0.1', '登录', '登录操作，username：1000001', '/s8726/public/admin/login/loginhandle.html', '1', '1534496717', '1534496717');
INSERT INTO `xt_action_log` VALUES ('1670', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534496495', '1534496495');
INSERT INTO `xt_action_log` VALUES ('1669', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534496406', '1534496406');
INSERT INTO `xt_action_log` VALUES ('1668', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：菜单管理', '/s8726/public/admin/menu/menuedit.html', '1', '1534495581', '1534495581');
INSERT INTO `xt_action_log` VALUES ('1667', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：菜单列表', '/s8726/public/admin/menu/menuedit.html', '1', '1534495527', '1534495527');
INSERT INTO `xt_action_log` VALUES ('1666', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：菜单列表', '/s8726/public/admin/menu/menuedit.html', '1', '1534495504', '1534495504');
INSERT INTO `xt_action_log` VALUES ('1665', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：菜单状态', '/s8726/public/admin/menu/menuedit.html', '1', '1534495462', '1534495462');
INSERT INTO `xt_action_log` VALUES ('1664', '1', '100000', '127.0.0.1', '数据状态', '数据状态调整，model：Menu，ids：203，status：1', '/s8726/public/admin/menu/setstatus.html', '1', '1534495423', '1534495423');
INSERT INTO `xt_action_log` VALUES ('1663', '1', '100000', '127.0.0.1', '数据状态', '数据状态调整，model：Menu，ids：140,157,141,166，status：1', '/s8726/public/admin/menu/setstatus.html', '1', '1534495385', '1534495385');
INSERT INTO `xt_action_log` VALUES ('1662', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：接口管理', '/s8726/public/admin/menu/menuedit.html', '1', '1534495367', '1534495367');
INSERT INTO `xt_action_log` VALUES ('1661', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：插件管理', '/s8726/public/admin/menu/menuedit.html', '1', '1534495343', '1534495343');
INSERT INTO `xt_action_log` VALUES ('1660', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：服务管理', '/s8726/public/admin/menu/menuedit.html', '1', '1534495305', '1534495305');
INSERT INTO `xt_action_log` VALUES ('1659', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：驱动安装', '/s8726/public/admin/menu/menuedit.html', '1', '1534495282', '1534495282');
INSERT INTO `xt_action_log` VALUES ('1658', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：优化维护', '/s8726/public/admin/menu/menuedit.html', '1', '1534495253', '1534495253');
INSERT INTO `xt_action_log` VALUES ('1657', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：友情链接', '/s8726/public/admin/menu/menuedit.html', '1', '1534495203', '1534495203');
INSERT INTO `xt_action_log` VALUES ('1656', '1', '100000', '127.0.0.1', '数据状态', '数据状态调整，model：Menu，ids：135，status：-1', '/s8726/public/admin/menu/setstatus/ids/135/status/-1.html', '1', '1534495127', '1534495127');
INSERT INTO `xt_action_log` VALUES ('1655', '1', '100000', '127.0.0.1', '数据状态', '数据状态调整，model：Menu，ids：70，status：-1', '/s8726/public/admin/menu/setstatus/ids/70/status/-1.html', '1', '1534495080', '1534495080');
INSERT INTO `xt_action_log` VALUES ('1654', '1', '100000', '127.0.0.1', '数据状态', '数据状态调整，model：Menu，ids：70,135,140,157,141,166,203，status：0', '/s8726/public/admin/menu/setstatus.html', '1', '1534495066', '1534495066');
INSERT INTO `xt_action_log` VALUES ('1653', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534494922', '1534494922');
INSERT INTO `xt_action_log` VALUES ('1652', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534493969', '1534493969');
INSERT INTO `xt_action_log` VALUES ('1651', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534492447', '1534492447');
INSERT INTO `xt_action_log` VALUES ('1650', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534489538', '1534489538');
INSERT INTO `xt_action_log` VALUES ('1649', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534484184', '1534484184');
INSERT INTO `xt_action_log` VALUES ('1648', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534484174', '1534484174');
INSERT INTO `xt_action_log` VALUES ('1647', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534484052', '1534484052');
INSERT INTO `xt_action_log` VALUES ('1646', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534484035', '1534484035');
INSERT INTO `xt_action_log` VALUES ('1645', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534483839', '1534483839');
INSERT INTO `xt_action_log` VALUES ('1644', '1', '100000', '127.0.0.1', '清理', '文件清理', '/s8726/public/admin/fileclean/cleanlist.html', '1', '1534480742', '1534480742');
INSERT INTO `xt_action_log` VALUES ('1643', '1', '100000', '127.0.0.1', '清理', '文件清理', '/s8726/public/admin/fileclean/cleanlist.html', '1', '1534480714', '1534480714');
INSERT INTO `xt_action_log` VALUES ('1642', '1', '100000', '127.0.0.1', '清理', '文件清理', '/s8726/public/admin/fileclean/cleanlist.html', '1', '1534480713', '1534480713');
INSERT INTO `xt_action_log` VALUES ('1641', '1', '100000', '127.0.0.1', '清理', '文件清理', '/s8726/public/admin/fileclean/cleanlist.html', '1', '1534480710', '1534480710');
INSERT INTO `xt_action_log` VALUES ('1640', '1', '100000', '127.0.0.1', '清理', '文件清理', '/s8726/public/admin/fileclean/cleanlist.html', '1', '1534480125', '1534480125');
INSERT INTO `xt_action_log` VALUES ('1639', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534480107', '1534480107');
INSERT INTO `xt_action_log` VALUES ('1638', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534479137', '1534479137');
INSERT INTO `xt_action_log` VALUES ('1637', '1', '100000', '127.0.0.1', '数据状态', '数据状态调整，model：Menu，ids：222，status：-1', '/s8726/public/admin/menu/setstatus/ids/222/status/-1.html', '1', '1534478660', '1534478660');
INSERT INTO `xt_action_log` VALUES ('1636', '1', '100000', '127.0.0.1', '新增', '产品新增，name：会员网络图', '/s8726/public/admin/shopadmin/shopadd.html', '1', '1534478075', '1534478075');
INSERT INTO `xt_action_log` VALUES ('1635', '1', '100000', '127.0.0.1', '新增', '新增菜单，name：清空数据库', '/s8726/public/admin/menu/menuadd.html', '1', '1534476785', '1534476785');
INSERT INTO `xt_action_log` VALUES ('1634', '1', '100000', '127.0.0.1', '删除', '删除回收站数据，model_name：ActionLog，id0', '/s8726/public/admin/trash/trashdatadel/model_name/ActionLog.html', '1', '1534476424', '1534476424');
INSERT INTO `xt_action_log` VALUES ('1552', '1', '100000', '192.168.0.197', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534124432', '1534124432');
INSERT INTO `xt_action_log` VALUES ('1553', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534124506', '1534124506');
INSERT INTO `xt_action_log` VALUES ('1554', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534126244', '1534126244');
INSERT INTO `xt_action_log` VALUES ('1555', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534126752', '1534126752');
INSERT INTO `xt_action_log` VALUES ('1556', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534126866', '1534126866');
INSERT INTO `xt_action_log` VALUES ('1557', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534126933', '1534126933');
INSERT INTO `xt_action_log` VALUES ('1558', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534127280', '1534127280');
INSERT INTO `xt_action_log` VALUES ('1559', '1', '100000', '192.168.0.197', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534127703', '1534127703');
INSERT INTO `xt_action_log` VALUES ('1560', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534129554', '1534129554');
INSERT INTO `xt_action_log` VALUES ('1561', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534137239', '1534137239');
INSERT INTO `xt_action_log` VALUES ('1562', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534137843', '1534137843');
INSERT INTO `xt_action_log` VALUES ('1563', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534153778', '1534153778');
INSERT INTO `xt_action_log` VALUES ('1564', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534154386', '1534154386');
INSERT INTO `xt_action_log` VALUES ('1565', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534212439', '1534212439');
INSERT INTO `xt_action_log` VALUES ('1566', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534214348', '1534214348');
INSERT INTO `xt_action_log` VALUES ('1567', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534215391', '1534215391');
INSERT INTO `xt_action_log` VALUES ('1568', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534229764', '1534229764');
INSERT INTO `xt_action_log` VALUES ('1569', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534233587', '1534233587');
INSERT INTO `xt_action_log` VALUES ('1570', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534233866', '1534233866');
INSERT INTO `xt_action_log` VALUES ('1571', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534233901', '1534233901');
INSERT INTO `xt_action_log` VALUES ('1572', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534234479', '1534234479');
INSERT INTO `xt_action_log` VALUES ('1573', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534235028', '1534235028');
INSERT INTO `xt_action_log` VALUES ('1574', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534235300', '1534235300');
INSERT INTO `xt_action_log` VALUES ('1575', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534235847', '1534235847');
INSERT INTO `xt_action_log` VALUES ('1576', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534236924', '1534236924');
INSERT INTO `xt_action_log` VALUES ('1577', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534243950', '1534243950');
INSERT INTO `xt_action_log` VALUES ('1578', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534244591', '1534244591');
INSERT INTO `xt_action_log` VALUES ('1579', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534245381', '1534245381');
INSERT INTO `xt_action_log` VALUES ('1580', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534246028', '1534246028');
INSERT INTO `xt_action_log` VALUES ('1581', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534246644', '1534246644');
INSERT INTO `xt_action_log` VALUES ('1582', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534247683', '1534247683');
INSERT INTO `xt_action_log` VALUES ('1583', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534251760', '1534251760');
INSERT INTO `xt_action_log` VALUES ('1584', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534293660', '1534293660');
INSERT INTO `xt_action_log` VALUES ('1585', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534293990', '1534293990');
INSERT INTO `xt_action_log` VALUES ('1586', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534302262', '1534302262');
INSERT INTO `xt_action_log` VALUES ('1587', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534313169', '1534313169');
INSERT INTO `xt_action_log` VALUES ('1588', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534320811', '1534320811');
INSERT INTO `xt_action_log` VALUES ('1589', '1', '100000', '192.168.0.139', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534323930', '1534323930');
INSERT INTO `xt_action_log` VALUES ('1590', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534327580', '1534327580');
INSERT INTO `xt_action_log` VALUES ('1591', '1', '100000', '192.168.0.197', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534328008', '1534328008');
INSERT INTO `xt_action_log` VALUES ('1592', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534328721', '1534328721');
INSERT INTO `xt_action_log` VALUES ('1593', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534328732', '1534328732');
INSERT INTO `xt_action_log` VALUES ('1594', '1', '100000', '192.168.0.197', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534328968', '1534328968');
INSERT INTO `xt_action_log` VALUES ('1595', '1', '100000', '192.168.0.197', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534340748', '1534340748');
INSERT INTO `xt_action_log` VALUES ('1596', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534386815', '1534386815');
INSERT INTO `xt_action_log` VALUES ('1597', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534401568', '1534401568');
INSERT INTO `xt_action_log` VALUES ('1598', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534401807', '1534401807');
INSERT INTO `xt_action_log` VALUES ('1599', '1', '100000', '127.0.0.1', '删除', '删除会员，where：id=1050', '/s8726/public/admin/member/memberdel/id/1050.html', '1', '1534402025', '1534402025');
INSERT INTO `xt_action_log` VALUES ('1600', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534403085', '1534403085');
INSERT INTO `xt_action_log` VALUES ('1601', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534403122', '1534403122');
INSERT INTO `xt_action_log` VALUES ('1602', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534404054', '1534404054');
INSERT INTO `xt_action_log` VALUES ('1603', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534404124', '1534404124');
INSERT INTO `xt_action_log` VALUES ('1604', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534406967', '1534406967');
INSERT INTO `xt_action_log` VALUES ('1605', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1534407465', '1534407465');
INSERT INTO `xt_action_log` VALUES ('1606', '1', '100000', '127.0.0.1', '新增', '产品新增，name：4入4入34日4r', '/s8726/public/admin/shopadmin/shopadd.html', '1', '1534407829', '1534407829');
INSERT INTO `xt_action_log` VALUES ('1607', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534418345', '1534418345');
INSERT INTO `xt_action_log` VALUES ('1608', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534419811', '1534419811');
INSERT INTO `xt_action_log` VALUES ('1609', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534424842', '1534424842');
INSERT INTO `xt_action_log` VALUES ('1610', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534424889', '1534424889');
INSERT INTO `xt_action_log` VALUES ('1611', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534424949', '1534424949');
INSERT INTO `xt_action_log` VALUES ('1612', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534424993', '1534424993');
INSERT INTO `xt_action_log` VALUES ('1613', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534425236', '1534425236');
INSERT INTO `xt_action_log` VALUES ('1614', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534425297', '1534425297');
INSERT INTO `xt_action_log` VALUES ('1615', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534425350', '1534425350');
INSERT INTO `xt_action_log` VALUES ('1616', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534425411', '1534425411');
INSERT INTO `xt_action_log` VALUES ('1617', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534425442', '1534425442');
INSERT INTO `xt_action_log` VALUES ('1618', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534425566', '1534425566');
INSERT INTO `xt_action_log` VALUES ('1619', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534425611', '1534425611');
INSERT INTO `xt_action_log` VALUES ('1620', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534425768', '1534425768');
INSERT INTO `xt_action_log` VALUES ('1621', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534425866', '1534425866');
INSERT INTO `xt_action_log` VALUES ('1622', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534425880', '1534425880');
INSERT INTO `xt_action_log` VALUES ('1623', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534427188', '1534427188');
INSERT INTO `xt_action_log` VALUES ('1624', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534427216', '1534427216');
INSERT INTO `xt_action_log` VALUES ('1625', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534427255', '1534427255');
INSERT INTO `xt_action_log` VALUES ('1626', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/s8726/public/admin/member/memberedit.html', '1', '1534427600', '1534427600');
INSERT INTO `xt_action_log` VALUES ('1627', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534427770', '1534427770');
INSERT INTO `xt_action_log` VALUES ('1628', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534429371', '1534429371');
INSERT INTO `xt_action_log` VALUES ('1629', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534470309', '1534470309');
INSERT INTO `xt_action_log` VALUES ('1630', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534471208', '1534471208');
INSERT INTO `xt_action_log` VALUES ('1631', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1534475847', '1534475847');
INSERT INTO `xt_action_log` VALUES ('1632', '1', '100000', '127.0.0.1', '清理', '文件清理', '/s8726/public/admin/fileclean/cleanlist.html', '1', '1534476402', '1534476402');
INSERT INTO `xt_action_log` VALUES ('1633', '1', '100000', '127.0.0.1', '清理', '文件清理', '/s8726/public/admin/fileclean/cleanlist.html', '1', '1534476406', '1534476406');
INSERT INTO `xt_action_log` VALUES ('1875', '1', '100000', '192.168.0.141', '编辑', '编辑会员，id：1098', '/s8726/public/admin/member/memberedit.html', '1', '1535189060', '1535189060');
INSERT INTO `xt_action_log` VALUES ('1876', '1091', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535330834', '1535330834');
INSERT INTO `xt_action_log` VALUES ('1877', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535330856', '1535330856');
INSERT INTO `xt_action_log` VALUES ('1878', '1098', '888888', '127.0.0.1', '登录', '登录操作，username：888888', '/s8726/public/admin/login/loginhandle.html', '1', '1535330918', '1535330918');
INSERT INTO `xt_action_log` VALUES ('1879', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535330951', '1535330951');
INSERT INTO `xt_action_log` VALUES ('1880', '1091', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535331359', '1535331359');
INSERT INTO `xt_action_log` VALUES ('1881', '1091', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535331482', '1535331482');
INSERT INTO `xt_action_log` VALUES ('1882', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535331684', '1535331684');
INSERT INTO `xt_action_log` VALUES ('1883', '1092', '222222', '127.0.0.1', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1535331803', '1535331803');
INSERT INTO `xt_action_log` VALUES ('1884', '1093', '333333', '127.0.0.1', '登录', '登录操作，username：333333', '/s8726/public/admin/login/loginhandle.html', '1', '1535332409', '1535332409');
INSERT INTO `xt_action_log` VALUES ('1885', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535332432', '1535332432');
INSERT INTO `xt_action_log` VALUES ('1886', '1093', '333333', '127.0.0.1', '登录', '登录操作，username：333333', '/s8726/public/admin/login/loginhandle.html', '1', '1535332603', '1535332603');
INSERT INTO `xt_action_log` VALUES ('1887', '1092', '222222', '127.0.0.1', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1535332655', '1535332655');
INSERT INTO `xt_action_log` VALUES ('1888', '1098', '888888', '127.0.0.1', '登录', '登录操作，username：888888', '/s8726/public/admin/login/loginhandle.html', '1', '1535332739', '1535332739');
INSERT INTO `xt_action_log` VALUES ('1889', '1092', '222222', '127.0.0.1', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1535333043', '1535333043');
INSERT INTO `xt_action_log` VALUES ('1890', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535333153', '1535333153');
INSERT INTO `xt_action_log` VALUES ('1891', '1092', '222222', '127.0.0.1', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1535333503', '1535333503');
INSERT INTO `xt_action_log` VALUES ('1892', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535333624', '1535333624');
INSERT INTO `xt_action_log` VALUES ('1893', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1535333792', '1535333792');
INSERT INTO `xt_action_log` VALUES ('1894', '1092', '222222', '127.0.0.1', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1535333825', '1535333825');
INSERT INTO `xt_action_log` VALUES ('1895', '1093', '333333', '127.0.0.1', '登录', '登录操作，username：333333', '/s8726/public/admin/login/loginhandle.html', '1', '1535333871', '1535333871');
INSERT INTO `xt_action_log` VALUES ('1896', '1098', '888888', '127.0.0.1', '登录', '登录操作，username：888888', '/s8726/public/admin/login/loginhandle.html', '1', '1535333939', '1535333939');
INSERT INTO `xt_action_log` VALUES ('1897', '1091', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535333986', '1535333986');
INSERT INTO `xt_action_log` VALUES ('1898', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535335091', '1535335091');
INSERT INTO `xt_action_log` VALUES ('1899', '1092', '222222', '127.0.0.1', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1535335278', '1535335278');
INSERT INTO `xt_action_log` VALUES ('1900', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535335757', '1535335757');
INSERT INTO `xt_action_log` VALUES ('1901', '1098', '888888', '127.0.0.1', '登录', '登录操作，username：888888', '/s8726/public/admin/login/loginhandle.html', '1', '1535336719', '1535336719');
INSERT INTO `xt_action_log` VALUES ('1902', '1092', '222222', '127.0.0.1', '登录', '登录操作，username：222222', '/s8726/public/admin/login/loginhandle.html', '1', '1535336761', '1535336761');
INSERT INTO `xt_action_log` VALUES ('1903', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535339968', '1535339968');
INSERT INTO `xt_action_log` VALUES ('1904', '1099', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535340126', '1535340126');
INSERT INTO `xt_action_log` VALUES ('1905', '1099', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535340245', '1535340245');
INSERT INTO `xt_action_log` VALUES ('1906', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535340520', '1535340520');
INSERT INTO `xt_action_log` VALUES ('1907', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535340623', '1535340623');
INSERT INTO `xt_action_log` VALUES ('1908', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535340900', '1535340900');
INSERT INTO `xt_action_log` VALUES ('1909', '1099', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/s8726/public/admin/login/loginhandle.html', '1', '1535340998', '1535340998');
INSERT INTO `xt_action_log` VALUES ('1910', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535341274', '1535341274');
INSERT INTO `xt_action_log` VALUES ('1911', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535342268', '1535342268');
INSERT INTO `xt_action_log` VALUES ('1912', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535349795', '1535349795');
INSERT INTO `xt_action_log` VALUES ('1913', '1', '100000', '192.168.0.168', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535350013', '1535350013');
INSERT INTO `xt_action_log` VALUES ('1914', '1', '100000', '192.168.0.183', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535350719', '1535350719');
INSERT INTO `xt_action_log` VALUES ('1915', '1', '100000', '192.168.0.183', '编辑', '编辑配置，name：seo_title', '/s8726/public/admin/config/configedit.html', '1', '1535351121', '1535351121');
INSERT INTO `xt_action_log` VALUES ('1916', '1', '100000', '192.168.0.183', '编辑', '编辑配置，name：seo_keywords', '/s8726/public/admin/config/configedit.html', '1', '1535351135', '1535351135');
INSERT INTO `xt_action_log` VALUES ('1917', '1', '100000', '192.168.0.183', '编辑', '编辑配置，name：seo_description', '/s8726/public/admin/config/configedit.html', '1', '1535351160', '1535351160');
INSERT INTO `xt_action_log` VALUES ('1918', '1', '100000', '192.168.0.109', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535351176', '1535351176');
INSERT INTO `xt_action_log` VALUES ('1919', '1', '100000', '192.168.0.120', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535352563', '1535352563');
INSERT INTO `xt_action_log` VALUES ('1920', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535938895', '1535938895');
INSERT INTO `xt_action_log` VALUES ('1921', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：菜单管理', '/s8726/public/admin/menu/menuedit.html', '1', '1535942122', '1535942122');
INSERT INTO `xt_action_log` VALUES ('1922', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：服务管理', '/s8726/public/admin/menu/menuedit.html', '1', '1535942133', '1535942133');
INSERT INTO `xt_action_log` VALUES ('1923', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：接口管理', '/s8726/public/admin/menu/menuedit.html', '1', '1535942154', '1535942154');
INSERT INTO `xt_action_log` VALUES ('1924', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：插件管理', '/s8726/public/admin/menu/menuedit.html', '1', '1535942160', '1535942160');
INSERT INTO `xt_action_log` VALUES ('1925', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：优化维护', '/s8726/public/admin/menu/menuedit.html', '1', '1535942167', '1535942167');
INSERT INTO `xt_action_log` VALUES ('1926', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：权限等级', '/s8726/public/admin/menu/menuedit.html', '1', '1535942209', '1535942209');
INSERT INTO `xt_action_log` VALUES ('1927', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：权限管理', '/s8726/public/admin/menu/menuedit.html', '1', '1535942236', '1535942236');
INSERT INTO `xt_action_log` VALUES ('1928', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：产品浏览', '/s8726/public/admin/menu/menuedit.html', '1', '1535942312', '1535942312');
INSERT INTO `xt_action_log` VALUES ('1929', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/s8726/public/admin/config/setting.html', '1', '1535943185', '1535943185');
INSERT INTO `xt_action_log` VALUES ('1930', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535943577', '1535943577');
INSERT INTO `xt_action_log` VALUES ('1931', '1', '100000', '127.0.0.1', '数据状态', '数据状态调整，model：Shop，ids：53，status：-1', '/s8726/public/admin/shopadmin/setstatus/ids/53/status/-1.html', '1', '1535944513', '1535944513');
INSERT INTO `xt_action_log` VALUES ('1932', '1', '100000', '127.0.0.1', '编辑', '产品编辑，name：广告包', '/s8726/public/admin/shopadmin/shopedit.html', '1', '1535944526', '1535944526');
INSERT INTO `xt_action_log` VALUES ('1933', '1', '100000', '127.0.0.1', '编辑', '产品编辑，name：广告包', '/s8726/public/admin/shopadmin/shopedit.html', '1', '1535944546', '1535944546');
INSERT INTO `xt_action_log` VALUES ('1934', '1', '100000', '127.0.0.1', '删除', '产品分类删除，where：id=12', '/s8726/public/admin/shopadmin/shopcategorydel/id/12.html', '1', '1535946092', '1535946092');
INSERT INTO `xt_action_log` VALUES ('1935', '1', '100000', '127.0.0.1', '编辑', '分类编辑，name：广告包', '/s8726/public/admin/shopadmin/shopcategoryedit.html', '1', '1535946108', '1535946108');
INSERT INTO `xt_action_log` VALUES ('1936', '1', '100000', '127.0.0.1', '删除', '产品分类删除，where：id=7', '/s8726/public/admin/shopadmin/shopcategorydel/id/7.html', '1', '1535946233', '1535946233');
INSERT INTO `xt_action_log` VALUES ('1937', '1', '100000', '127.0.0.1', '新增', '分类新增，name：广告包', '/s8726/public/admin/shopadmin/shopcategoryadd.html', '1', '1535946321', '1535946321');
INSERT INTO `xt_action_log` VALUES ('1938', '1', '100000', '127.0.0.1', '编辑', '产品编辑，name：广告包', '/s8726/public/admin/shopadmin/shopedit.html', '1', '1535947730', '1535947730');
INSERT INTO `xt_action_log` VALUES ('1939', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：推荐图', '/s8726/public/admin/menu/menuedit.html', '1', '1535955798', '1535955798');
INSERT INTO `xt_action_log` VALUES ('1940', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/s8726/public/admin/login/loginhandle.html', '1', '1535957721', '1535957721');
INSERT INTO `xt_action_log` VALUES ('1941', '1', '100000', '192.168.0.103', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1535959740', '1535959740');
INSERT INTO `xt_action_log` VALUES ('1942', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：购物商城', '/c8903/public/admin/menu/menuedit.html', '1', '1535966122', '1535966122');
INSERT INTO `xt_action_log` VALUES ('1943', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：权限等级', '/c8903/public/admin/menu/menuedit.html', '1', '1535966149', '1535966149');
INSERT INTO `xt_action_log` VALUES ('1944', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：后台管理', '/c8903/public/admin/menu/menuedit.html', '1', '1535966266', '1535966266');
INSERT INTO `xt_action_log` VALUES ('1945', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：会员管理', '/c8903/public/admin/menu/menuedit.html', '1', '1535966341', '1535966341');
INSERT INTO `xt_action_log` VALUES ('1946', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：文章管理', '/c8903/public/admin/menu/menuedit.html', '1', '1535966471', '1535966471');
INSERT INTO `xt_action_log` VALUES ('1947', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：个人设置', '/c8903/public/admin/menu/menuadd.html', '1', '1535966736', '1535966736');
INSERT INTO `xt_action_log` VALUES ('1948', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：会员档案', '/c8903/public/admin/menu/menuadd.html', '1', '1535966788', '1535966788');
INSERT INTO `xt_action_log` VALUES ('1949', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：注册账户', '/c8903/public/admin/menu/menuadd.html', '1', '1535966876', '1535966876');
INSERT INTO `xt_action_log` VALUES ('1950', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：二维码分享', '/c8903/public/admin/menu/menuadd.html', '1', '1535966957', '1535966957');
INSERT INTO `xt_action_log` VALUES ('1951', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：225，value：1', '/c8903/public/admin/menu/setsort.html', '1', '1535967101', '1535967101');
INSERT INTO `xt_action_log` VALUES ('1952', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：198，value：2', '/c8903/public/admin/menu/setsort.html', '1', '1535967132', '1535967132');
INSERT INTO `xt_action_log` VALUES ('1953', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：二维码分享', '/c8903/public/admin/menu/menuedit.html', '1', '1535967387', '1535967387');
INSERT INTO `xt_action_log` VALUES ('1954', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：会员档案', '/c8903/public/admin/menu/menuedit.html', '1', '1535967596', '1535967596');
INSERT INTO `xt_action_log` VALUES ('1955', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：注册账户', '/c8903/public/admin/menu/menuedit.html', '1', '1535967614', '1535967614');
INSERT INTO `xt_action_log` VALUES ('1956', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：推荐图', '/c8903/public/admin/menu/menuedit.html', '1', '1535967780', '1535967780');
INSERT INTO `xt_action_log` VALUES ('1957', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：货币流向', '/c8903/public/menu/menuedit.html', '1', '1535968523', '1535968523');
INSERT INTO `xt_action_log` VALUES ('1958', '1', '100000', '192.168.0.103', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1535968582', '1535968582');
INSERT INTO `xt_action_log` VALUES ('1959', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：资料修改', '/c8903/public/menu/menuedit.html', '1', '1535969069', '1535969069');
INSERT INTO `xt_action_log` VALUES ('1960', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：我的信息', '/c8903/public/menu/menuedit.html', '1', '1535969097', '1535969097');
INSERT INTO `xt_action_log` VALUES ('1961', '1', '100000', '192.168.0.144', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1535969138', '1535969138');
INSERT INTO `xt_action_log` VALUES ('1962', '1', '100000', '192.168.0.103', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1535969147', '1535969147');
INSERT INTO `xt_action_log` VALUES ('1963', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：会员中心', '/c8903/public/menu/menuadd.html', '1', '1535969770', '1535969770');
INSERT INTO `xt_action_log` VALUES ('1964', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：229，value：1', '/c8903/public/menu/setsort.html', '1', '1535969798', '1535969798');
INSERT INTO `xt_action_log` VALUES ('1965', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：提现', '/c8903/public/menu/menuadd.html', '1', '1535969850', '1535969850');
INSERT INTO `xt_action_log` VALUES ('1966', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：转账', '/c8903/public/menu/menuadd.html', '1', '1535969902', '1535969902');
INSERT INTO `xt_action_log` VALUES ('1967', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：财务明细', '/c8903/public/menu/menuadd.html', '1', '1535970098', '1535970098');
INSERT INTO `xt_action_log` VALUES ('1968', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：优化维护', '/c8903/public/menu/menuedit.html', '1', '1535971031', '1535971031');
INSERT INTO `xt_action_log` VALUES ('1969', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：插件管理', '/c8903/public/menu/menuedit.html', '1', '1535971039', '1535971039');
INSERT INTO `xt_action_log` VALUES ('1970', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：接口管理', '/c8903/public/menu/menuedit.html', '1', '1535971048', '1535971048');
INSERT INTO `xt_action_log` VALUES ('1971', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：服务管理', '/c8903/public/menu/menuedit.html', '1', '1535971054', '1535971054');
INSERT INTO `xt_action_log` VALUES ('1972', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：新闻公告管理', '/c8903/public/menu/menuedit.html', '1', '1535971068', '1535971068');
INSERT INTO `xt_action_log` VALUES ('1973', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：公告管理', '/c8903/public/menu/menuedit.html', '1', '1535971086', '1535971086');
INSERT INTO `xt_action_log` VALUES ('1974', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：75，value：5', '/c8903/public/menu/setsort.html', '1', '1535971110', '1535971110');
INSERT INTO `xt_action_log` VALUES ('1975', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：69，value：10', '/c8903/public/menu/setsort.html', '1', '1535971152', '1535971152');
INSERT INTO `xt_action_log` VALUES ('1976', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：170，value：11', '/c8903/public/menu/setsort.html', '1', '1535971158', '1535971158');
INSERT INTO `xt_action_log` VALUES ('1977', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：209，value：9', '/c8903/public/menu/setsort.html', '1', '1535971174', '1535971174');
INSERT INTO `xt_action_log` VALUES ('1978', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：新闻公告', '/c8903/public/menu/menuadd.html', '1', '1535971273', '1535971273');
INSERT INTO `xt_action_log` VALUES ('1979', '1', '100000', '192.168.0.103', '编辑', '文章编辑，name：312312321312', '/c8903/public/article/articleedit.html', '1', '1535971435', '1535971435');
INSERT INTO `xt_action_log` VALUES ('1980', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：邮箱', '/c8903/public/menu/menuadd.html', '1', '1535971624', '1535971624');
INSERT INTO `xt_action_log` VALUES ('1981', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：收件箱', '/c8903/public/menu/menuadd.html', '1', '1535971652', '1535971652');
INSERT INTO `xt_action_log` VALUES ('1982', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：发件箱', '/c8903/public/menu/menuadd.html', '1', '1535971664', '1535971664');
INSERT INTO `xt_action_log` VALUES ('1983', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：写邮件', '/c8903/public/menu/menuadd.html', '1', '1535971675', '1535971675');
INSERT INTO `xt_action_log` VALUES ('1984', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：230，value：1', '/c8903/public/menu/setsort.html', '1', '1535971806', '1535971806');
INSERT INTO `xt_action_log` VALUES ('1985', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：231，value：1', '/c8903/public/menu/setsort.html', '1', '1535971815', '1535971815');
INSERT INTO `xt_action_log` VALUES ('1986', '1', '100000', '192.168.0.103', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1535971923', '1535971923');
INSERT INTO `xt_action_log` VALUES ('1987', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：会员充值', '/c8903/public/menu/menuedit.html', '1', '1535972305', '1535972305');
INSERT INTO `xt_action_log` VALUES ('1988', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：奖金明细', '/c8903/public/menu/menuadd.html', '1', '1535972688', '1535972688');
INSERT INTO `xt_action_log` VALUES ('1989', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：奖金明细', '/c8903/public/menu/menuedit.html', '1', '1535972711', '1535972711');
INSERT INTO `xt_action_log` VALUES ('1990', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：奖金明细', '/c8903/public/menu/menuedit.html', '1', '1535972759', '1535972759');
INSERT INTO `xt_action_log` VALUES ('1991', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：234，value：1', '/c8903/public/menu/setsort.html', '1', '1535973618', '1535973618');
INSERT INTO `xt_action_log` VALUES ('1992', '1', '100000', '192.168.0.103', '新增', '新增会员，username：1000001', '/c8903/public/index/member_add.html', '1', '1535976662', '1535976662');
INSERT INTO `xt_action_log` VALUES ('1993', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：充值', '/c8903/public/menu/menuadd.html', '1', '1536025887', '1536025887');
INSERT INTO `xt_action_log` VALUES ('1994', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：充值', '/c8903/public/menu/menuedit.html', '1', '1536027493', '1536027493');
INSERT INTO `xt_action_log` VALUES ('1995', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：会员充值', '/c8903/public/menu/menuedit.html', '1', '1536028784', '1536028784');
INSERT INTO `xt_action_log` VALUES ('1996', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：会员充值', '/c8903/public/menu/menuedit.html', '1', '1536028816', '1536028816');
INSERT INTO `xt_action_log` VALUES ('1997', '1', '100000', '192.168.0.103', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536029380', '1536029380');
INSERT INTO `xt_action_log` VALUES ('1998', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：会员充值', '/c8903/public/menu/menuedit.html', '1', '1536029508', '1536029508');
INSERT INTO `xt_action_log` VALUES ('1999', '1', '100000', '192.168.0.103', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536030240', '1536030240');
INSERT INTO `xt_action_log` VALUES ('2000', '1', '100000', '192.168.0.144', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536030368', '1536030368');
INSERT INTO `xt_action_log` VALUES ('2001', '1', '100000', '192.168.0.103', '新增', '新增菜单，name：会员激活', '/c8903/public/menu/menuadd.html', '1', '1536030963', '1536030963');
INSERT INTO `xt_action_log` VALUES ('2002', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：239，value：1', '/c8903/public/menu/setsort.html', '1', '1536030978', '1536030978');
INSERT INTO `xt_action_log` VALUES ('2003', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：234，value：3', '/c8903/public/menu/setsort.html', '1', '1536031025', '1536031025');
INSERT INTO `xt_action_log` VALUES ('2004', '1', '100000', '192.168.0.103', '数据排序', '数据排序调整，model：Menu，id：230，value：2', '/c8903/public/menu/setsort.html', '1', '1536031040', '1536031040');
INSERT INTO `xt_action_log` VALUES ('2005', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：充值', '/c8903/public/menu/menuedit.html', '1', '1536031218', '1536031218');
INSERT INTO `xt_action_log` VALUES ('2006', '1', '100000', '192.168.0.103', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536031307', '1536031307');
INSERT INTO `xt_action_log` VALUES ('2007', '1', '100000', '192.168.0.103', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536039082', '1536039082');
INSERT INTO `xt_action_log` VALUES ('2008', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323123', '/c8903/public/index/member_add.html', '1', '1536042509', '1536042509');
INSERT INTO `xt_action_log` VALUES ('2009', '1', '100000', '192.168.0.103', '删除', '删除会员，where：id=1099', '/c8903/public/member/memberdel/id/1099.html', '1', '1536043048', '1536043048');
INSERT INTO `xt_action_log` VALUES ('2010', '1', '100000', '192.168.0.103', '删除', '删除会员，where：id=1099', '/c8903/public/member/memberdel/id/1099.html', '1', '1536043051', '1536043051');
INSERT INTO `xt_action_log` VALUES ('2011', '1', '100000', '192.168.0.103', '删除', '删除会员，where：id=1100', '/c8903/public/member/memberdel/id/1100.html', '1', '1536043055', '1536043055');
INSERT INTO `xt_action_log` VALUES ('2012', '1', '100000', '192.168.0.103', '删除', '删除会员，where：id=1101', '/c8903/public/member/memberdel/id/1101.html', '1', '1536043059', '1536043059');
INSERT INTO `xt_action_log` VALUES ('2013', '1', '100000', '192.168.0.103', '新增', '新增会员，username：111111', '/c8903/public/index/member_add.html', '1', '1536043481', '1536043481');
INSERT INTO `xt_action_log` VALUES ('2014', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：会员激活', '/c8903/public/menu/menuedit.html', '1', '1536043817', '1536043817');
INSERT INTO `xt_action_log` VALUES ('2015', '1', '100000', '192.168.0.103', '编辑', '编辑菜单，name：会员激活', '/c8903/public/menu/menuedit.html', '1', '1536043848', '1536043848');
INSERT INTO `xt_action_log` VALUES ('2016', '1', '100000', '192.168.0.103', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536046808', '1536046808');
INSERT INTO `xt_action_log` VALUES ('2017', '1', '100000', '192.168.0.103', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536047208', '1536047208');
INSERT INTO `xt_action_log` VALUES ('2018', '1', '100000', '192.168.0.103', '新增', '新增会员，username：222222', '/c8903/public/index/member_add.html', '1', '1536047878', '1536047878');
INSERT INTO `xt_action_log` VALUES ('2019', '1', '100000', '192.168.0.103', '新增', '新增会员，username：2222222', '/c8903/public/index/member_add.html', '1', '1536047886', '1536047886');
INSERT INTO `xt_action_log` VALUES ('2020', '1', '100000', '192.168.0.103', '新增', '新增会员，username：1232323', '/c8903/public/index/member_add.html', '1', '1536047988', '1536047988');
INSERT INTO `xt_action_log` VALUES ('2021', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236', '/c8903/public/index/member_add.html', '1', '1536048070', '1536048070');
INSERT INTO `xt_action_log` VALUES ('2022', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e', '/c8903/public/index/member_add.html', '1', '1536048274', '1536048274');
INSERT INTO `xt_action_log` VALUES ('2023', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e41', '/c8903/public/index/member_add.html', '1', '1536048378', '1536048378');
INSERT INTO `xt_action_log` VALUES ('2024', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e413', '/c8903/public/index/member_add.html', '1', '1536048440', '1536048440');
INSERT INTO `xt_action_log` VALUES ('2025', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e4133', '/c8903/public/index/member_add.html', '1', '1536048452', '1536048452');
INSERT INTO `xt_action_log` VALUES ('2026', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e4w133', '/c8903/public/index/member_add.html', '1', '1536048522', '1536048522');
INSERT INTO `xt_action_log` VALUES ('2027', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e4w1w33', '/c8903/public/index/member_add.html', '1', '1536048551', '1536048551');
INSERT INTO `xt_action_log` VALUES ('2028', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e4w1w3w3', '/c8903/public/index/member_add.html', '1', '1536048561', '1536048561');
INSERT INTO `xt_action_log` VALUES ('2029', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e4w1w3w3', '/c8903/public/index/member_add.html', '1', '1536048589', '1536048589');
INSERT INTO `xt_action_log` VALUES ('2030', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e4w1w3w3', '/c8903/public/index/member_add.html', '1', '1536048590', '1536048590');
INSERT INTO `xt_action_log` VALUES ('2031', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e4w1w3w3', '/c8903/public/index/member_add.html', '1', '1536048590', '1536048590');
INSERT INTO `xt_action_log` VALUES ('2032', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e4w1w3w3', '/c8903/public/index/member_add.html', '1', '1536048591', '1536048591');
INSERT INTO `xt_action_log` VALUES ('2033', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e4w1w3w3', '/c8903/public/index/member_add.html', '1', '1536048592', '1536048592');
INSERT INTO `xt_action_log` VALUES ('2034', '1', '100000', '192.168.0.103', '新增', '新增会员，username：12323236e4w1w3w3', '/c8903/public/index/member_add.html', '1', '1536048592', '1536048592');
INSERT INTO `xt_action_log` VALUES ('2035', '1', '100000', '192.168.0.103', '新增', '新增会员，username：111111', '/c8903/public/index/member_add.html', '1', '1536049183', '1536049183');
INSERT INTO `xt_action_log` VALUES ('2036', '1', '100000', '192.168.0.103', '授权', '设置权限组权限，id：1', '/c8903/public/auth/menuauth.html', '1', '1536049311', '1536049311');
INSERT INTO `xt_action_log` VALUES ('2037', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：会员添加', '/c8903/public/menu/menuedit.html', '1', '1536051254', '1536051254');
INSERT INTO `xt_action_log` VALUES ('2038', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：会员添加', '/c8903/public/menu/menuedit.html', '1', '1536051284', '1536051284');
INSERT INTO `xt_action_log` VALUES ('2039', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：会员添加', '/c8903/public/menu/menuedit.html', '1', '1536051303', '1536051303');
INSERT INTO `xt_action_log` VALUES ('2040', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536051980', '1536051980');
INSERT INTO `xt_action_log` VALUES ('2041', '1', '100000', '127.0.0.1', '新增', '新增菜单，name：配置列表', '/c8903/public/menu/menuadd.html', '1', '1536052149', '1536052149');
INSERT INTO `xt_action_log` VALUES ('2042', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536052191', '1536052191');
INSERT INTO `xt_action_log` VALUES ('2043', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536052199', '1536052199');
INSERT INTO `xt_action_log` VALUES ('2044', '1', '100000', '127.0.0.1', '新增', '新增会员，username：111111', '/c8903/public/index/member_add.html', '1', '1536059124', '1536059124');
INSERT INTO `xt_action_log` VALUES ('2045', '1', '100000', '127.0.0.1', '新增', '新增会员，username：111111', '/c8903/public/index/member_add.html', '1', '1536059567', '1536059567');
INSERT INTO `xt_action_log` VALUES ('2046', '1', '100000', '127.0.0.1', '新增', '新增会员，username：111111', '/c8903/public/index/member_add.html', '1', '1536059634', '1536059634');
INSERT INTO `xt_action_log` VALUES ('2047', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536060396', '1536060396');
INSERT INTO `xt_action_log` VALUES ('2048', '1', '100000', '127.0.0.1', '新增', '新增会员，username：111111', '/c8903/public/index/member_add.html', '1', '1536060431', '1536060431');
INSERT INTO `xt_action_log` VALUES ('2049', '1126', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/c8903/public/login/loginhandle.html', '1', '1536060458', '1536060458');
INSERT INTO `xt_action_log` VALUES ('2050', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536060486', '1536060486');
INSERT INTO `xt_action_log` VALUES ('2051', '1', '100000', '127.0.0.1', '删除', '删除权限组，where：id=1', '/c8903/public/auth/groupdel/id/1.html', '1', '1536060525', '1536060525');
INSERT INTO `xt_action_log` VALUES ('2052', '1', '100000', '127.0.0.1', '新增', '新增权限组，name：1232', '/c8903/public/auth/groupadd.html', '1', '1536060680', '1536060680');
INSERT INTO `xt_action_log` VALUES ('2053', '1', '100000', '127.0.0.1', '授权', '设置权限组权限，id：3', '/c8903/public/auth/menuauth.html', '1', '1536060703', '1536060703');
INSERT INTO `xt_action_log` VALUES ('2054', '1', '100000', '127.0.0.1', '新增', '新增会员，username：222222', '/c8903/public/index/member_add.html', '1', '1536061443', '1536061443');
INSERT INTO `xt_action_log` VALUES ('2055', '1127', '222222', '127.0.0.1', '登录', '登录操作，username：222222', '/c8903/public/login/loginhandle.html', '1', '1536061475', '1536061475');
INSERT INTO `xt_action_log` VALUES ('2056', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536061612', '1536061612');
INSERT INTO `xt_action_log` VALUES ('2057', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536061636', '1536061636');
INSERT INTO `xt_action_log` VALUES ('2058', '1', '100000', '127.0.0.1', '新增', '新增会员，username：111111', '/c8903/public/index/member_add.html', '1', '1536061665', '1536061665');
INSERT INTO `xt_action_log` VALUES ('2059', '1128', '111111', '127.0.0.1', '登录', '登录操作，username：111111', '/c8903/public/login/loginhandle.html', '1', '1536061688', '1536061688');
INSERT INTO `xt_action_log` VALUES ('2060', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536061715', '1536061715');
INSERT INTO `xt_action_log` VALUES ('2061', '1', '100000', '127.0.0.1', '新增', '新增权限组，name：报单中心', '/c8903/public/auth/groupadd.html', '1', '1536062691', '1536062691');
INSERT INTO `xt_action_log` VALUES ('2062', '1', '100000', '127.0.0.1', '编辑', '编辑权限组，name：普通会员', '/c8903/public/auth/groupedit.html', '1', '1536062702', '1536062702');
INSERT INTO `xt_action_log` VALUES ('2063', '1', '100000', '127.0.0.1', '授权', '设置权限组权限，id：3', '/c8903/public/auth/menuauth.html', '1', '1536062740', '1536062740');
INSERT INTO `xt_action_log` VALUES ('2064', '1', '100000', '127.0.0.1', '授权', '设置权限组权限，id：4', '/c8903/public/auth/menuauth.html', '1', '1536062776', '1536062776');
INSERT INTO `xt_action_log` VALUES ('2065', '1', '100000', '127.0.0.1', '新增', '新增会员，username：222222', '/c8903/public/index/member_add.html', '1', '1536063170', '1536063170');
INSERT INTO `xt_action_log` VALUES ('2066', '1', '100000', '127.0.0.1', '新增', '新增会员，username：2222222', '/c8903/public/index/member_add.html', '1', '1536108254', '1536108254');
INSERT INTO `xt_action_log` VALUES ('2067', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：vip_level', '/c8903/public/config/configedit.html', '1', '1536109229', '1536109229');
INSERT INTO `xt_action_log` VALUES ('2068', '1', '100000', '127.0.0.1', '新增', '新增配置，name：is_agent', '/c8903/public/config/configadd.html', '1', '1536109819', '1536109819');
INSERT INTO `xt_action_log` VALUES ('2069', '1', '100000', '127.0.0.1', '新增', '新增会员，username：111111', '/c8903/public/index/member_add.html', '1', '1536109935', '1536109935');
INSERT INTO `xt_action_log` VALUES ('2070', '1', '100000', '127.0.0.1', '新增', '新增会员，username：222222', '/c8903/public/index/member_add.html', '1', '1536109953', '1536109953');
INSERT INTO `xt_action_log` VALUES ('2071', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536110074', '1536110074');
INSERT INTO `xt_action_log` VALUES ('2072', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536110080', '1536110080');
INSERT INTO `xt_action_log` VALUES ('2073', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536110110', '1536110110');
INSERT INTO `xt_action_log` VALUES ('2074', '1', '100000', '127.0.0.1', '新增', '新增配置，name：s_ratio', '/c8903/public/config/configadd.html', '1', '1536110316', '1536110316');
INSERT INTO `xt_action_log` VALUES ('2075', '1', '100000', '127.0.0.1', '数据状态', '数据状态调整，model：Config，ids：72，status：-1', '/c8903/public/config/setstatus/ids/72/status/-1.html', '1', '1536110329', '1536110329');
INSERT INTO `xt_action_log` VALUES ('2076', '1', '100000', '127.0.0.1', '新增', '新增配置，name：everyday_time', '/c8903/public/config/configadd.html', '1', '1536110905', '1536110905');
INSERT INTO `xt_action_log` VALUES ('2077', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：everyday_time', '/c8903/public/config/configedit.html', '1', '1536110997', '1536110997');
INSERT INTO `xt_action_log` VALUES ('2078', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：everyday_time', '/c8903/public/config/configedit.html', '1', '1536111172', '1536111172');
INSERT INTO `xt_action_log` VALUES ('2079', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：everyday_time', '/c8903/public/config/configedit.html', '1', '1536111272', '1536111272');
INSERT INTO `xt_action_log` VALUES ('2080', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536112092', '1536112092');
INSERT INTO `xt_action_log` VALUES ('2081', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536112499', '1536112499');
INSERT INTO `xt_action_log` VALUES ('2082', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536112842', '1536112842');
INSERT INTO `xt_action_log` VALUES ('2083', '1', '100000', '127.0.0.1', '新增', '新增会员，username：18799', '/c8903/public/index/member_add.html', '1', '1536113979', '1536113979');
INSERT INTO `xt_action_log` VALUES ('2084', '1', '100000', '127.0.0.1', '新增', '新增会员，username：617767', '/c8903/public/index/member_add.html', '1', '1536114102', '1536114102');
INSERT INTO `xt_action_log` VALUES ('2085', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536114578', '1536114578');
INSERT INTO `xt_action_log` VALUES ('2086', '1', '100000', '127.0.0.1', '新增', '新增配置，name：junc', '/c8903/public/config/configadd.html', '1', '1536121084', '1536121084');
INSERT INTO `xt_action_log` VALUES ('2087', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536121120', '1536121120');
INSERT INTO `xt_action_log` VALUES ('2088', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：reco', '/c8903/public/config/configedit.html', '1', '1536121134', '1536121134');
INSERT INTO `xt_action_log` VALUES ('2089', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：achievement', '/c8903/public/config/configedit.html', '1', '1536121203', '1536121203');
INSERT INTO `xt_action_log` VALUES ('2090', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536123113', '1536123113');
INSERT INTO `xt_action_log` VALUES ('2091', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536123317', '1536123317');
INSERT INTO `xt_action_log` VALUES ('2092', '1', '100000', '127.0.0.1', '新增', '新增配置，name： manage', '/c8903/public/config/configadd.html', '1', '1536124636', '1536124636');
INSERT INTO `xt_action_log` VALUES ('2093', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：everyday_time', '/c8903/public/config/configedit.html', '1', '1536124663', '1536124663');
INSERT INTO `xt_action_log` VALUES ('2094', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：static_domain', '/c8903/public/config/configedit.html', '1', '1536124701', '1536124701');
INSERT INTO `xt_action_log` VALUES ('2095', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：seo_title', '/c8903/public/config/configedit.html', '1', '1536124756', '1536124756');
INSERT INTO `xt_action_log` VALUES ('2096', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：loading_icon', '/c8903/public/config/configedit.html', '1', '1536124784', '1536124784');
INSERT INTO `xt_action_log` VALUES ('2097', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：seo_title', '/c8903/public/config/configedit.html', '1', '1536124800', '1536124800');
INSERT INTO `xt_action_log` VALUES ('2098', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：seo_keywords', '/c8903/public/config/configedit.html', '1', '1536124854', '1536124854');
INSERT INTO `xt_action_log` VALUES ('2099', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：seo_description', '/c8903/public/config/configedit.html', '1', '1536124866', '1536124866');
INSERT INTO `xt_action_log` VALUES ('2100', '1', '100000', '127.0.0.1', '新增', '新增配置，name：see_you', '/c8903/public/config/configadd.html', '1', '1536125806', '1536125806');
INSERT INTO `xt_action_log` VALUES ('2101', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：see_you', '/c8903/public/config/configedit.html', '1', '1536126037', '1536126037');
INSERT INTO `xt_action_log` VALUES ('2102', '1', '100000', '127.0.0.1', '新增', '新增配置，name：see_you_ratio', '/c8903/public/config/configadd.html', '1', '1536126087', '1536126087');
INSERT INTO `xt_action_log` VALUES ('2103', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：see_you', '/c8903/public/config/configedit.html', '1', '1536126099', '1536126099');
INSERT INTO `xt_action_log` VALUES ('2104', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：see_you_ratio', '/c8903/public/config/configedit.html', '1', '1536126815', '1536126815');
INSERT INTO `xt_action_log` VALUES ('2105', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：manage', '/c8903/public/config/configedit.html', '1', '1536127194', '1536127194');
INSERT INTO `xt_action_log` VALUES ('2106', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：treeplace', '/c8903/public/config/configedit.html', '1', '1536127968', '1536127968');
INSERT INTO `xt_action_log` VALUES ('2107', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536128951', '1536128951');
INSERT INTO `xt_action_log` VALUES ('2108', '1', '100000', '127.0.0.1', '新增', '新增会员，username：800811', '/c8903/public/index/member_add.html', '1', '1536129728', '1536129728');
INSERT INTO `xt_action_log` VALUES ('2109', '1134', '617767', '127.0.0.1', '登录', '登录操作，username：617767', '/c8903/public/login/loginhandle.html', '1', '1536130102', '1536130102');
INSERT INTO `xt_action_log` VALUES ('2110', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536130170', '1536130170');
INSERT INTO `xt_action_log` VALUES ('2111', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536130746', '1536130746');
INSERT INTO `xt_action_log` VALUES ('2112', '1', '100000', '127.0.0.1', '新增', '新增配置，name：agent_center', '/c8903/public/config/configadd.html', '1', '1536130873', '1536130873');
INSERT INTO `xt_action_log` VALUES ('2113', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：agent_center', '/c8903/public/config/configedit.html', '1', '1536130881', '1536130881');
INSERT INTO `xt_action_log` VALUES ('2114', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：agent_center', '/c8903/public/config/configedit.html', '1', '1536131086', '1536131086');
INSERT INTO `xt_action_log` VALUES ('2115', '1', '100000', '127.0.0.1', '新增', '新增配置，name：tax', '/c8903/public/config/configadd.html', '1', '1536132648', '1536132648');
INSERT INTO `xt_action_log` VALUES ('2116', '1', '100000', '127.0.0.1', '编辑', '编辑配置，name：tax', '/c8903/public/config/configedit.html', '1', '1536132656', '1536132656');
INSERT INTO `xt_action_log` VALUES ('2117', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/c8903/public/config/setting.html', '1', '1536132811', '1536132811');
INSERT INTO `xt_action_log` VALUES ('2118', '1', '100000', '127.0.0.1', '新增', '新增会员，username：53437', '/c8903/public/index/member_add.html', '1', '1536133849', '1536133849');
INSERT INTO `xt_action_log` VALUES ('2119', '1', '100000', '127.0.0.1', '新增', '新增会员，username：685028', '/c8903/public/index/member_add.html', '1', '1536134633', '1536134633');
INSERT INTO `xt_action_log` VALUES ('2120', '1', '100000', '127.0.0.1', '新增', '新增会员，username：764709', '/c8903/public/index/member_add.html', '1', '1536134937', '1536134937');
INSERT INTO `xt_action_log` VALUES ('2121', '1', '100000', '127.0.0.1', '新增', '新增会员，username：448822', '/c8903/public/index/member_add.html', '1', '1536135598', '1536135598');
INSERT INTO `xt_action_log` VALUES ('2122', '1', '100000', '127.0.0.1', '新增', '新增会员，username：685425', '/c8903/public/index/member_add.html', '1', '1536135794', '1536135794');
INSERT INTO `xt_action_log` VALUES ('2123', '1', '100000', '127.0.0.1', '新增', '新增会员，username：332825', '/c8903/public/index/member_add.html', '1', '1536135847', '1536135847');
INSERT INTO `xt_action_log` VALUES ('2124', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536222497', '1536222497');
INSERT INTO `xt_action_log` VALUES ('2125', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536222573', '1536222573');
INSERT INTO `xt_action_log` VALUES ('2126', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536309160', '1536309160');
INSERT INTO `xt_action_log` VALUES ('2127', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536136665', '1536136665');
INSERT INTO `xt_action_log` VALUES ('2128', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536223178', '1536223178');
INSERT INTO `xt_action_log` VALUES ('2129', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536223230', '1536223230');
INSERT INTO `xt_action_log` VALUES ('2130', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536309666', '1536309666');
INSERT INTO `xt_action_log` VALUES ('2131', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536137188', '1536137188');
INSERT INTO `xt_action_log` VALUES ('2132', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：货币流向', '/c8903/public/menu/menuedit.html', '1', '1536137950', '1536137950');
INSERT INTO `xt_action_log` VALUES ('2133', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：货币流向', '/c8903/public/menu/menuedit.html', '1', '1536138149', '1536138149');
INSERT INTO `xt_action_log` VALUES ('2134', '1', '100000', '127.0.0.1', '新增', '新增会员，username：679291', '/c8903/public/index/member_add.html', '1', '1536141112', '1536141112');
INSERT INTO `xt_action_log` VALUES ('2135', '1', '100000', '127.0.0.1', '新增', '新增会员，username：497559', '/c8903/public/index/member_add.html', '1', '1536141232', '1536141232');
INSERT INTO `xt_action_log` VALUES ('2136', '1', '100000', '192.168.0.115', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536141315', '1536141315');
INSERT INTO `xt_action_log` VALUES ('2137', '1', '100000', '127.0.0.1', '删除', '文章分类删除，where：id=7', '/c8903/public/article/articlecategorydel/id/7.html', '1', '1536146329', '1536146329');
INSERT INTO `xt_action_log` VALUES ('2138', '1', '100000', '127.0.0.1', '编辑', '文章编辑，name：312312321312', '/c8903/public/article/articleedit.html', '1', '1536146339', '1536146339');
INSERT INTO `xt_action_log` VALUES ('2139', '1', '100000', '127.0.0.1', '导出', '导出会员列表', '/c8903/public/member/exportmemberlist.html?', '1', '1536146482', '1536146482');
INSERT INTO `xt_action_log` VALUES ('2140', '1', '100000', '127.0.0.1', '导出', '导出会员列表', '/c8903/public/member/exportmemberlist.html?', '1', '1536146495', '1536146495');
INSERT INTO `xt_action_log` VALUES ('2141', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：关系图', '/c8903/public/menu/menuedit.html', '1', '1536194662', '1536194662');
INSERT INTO `xt_action_log` VALUES ('2142', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：注册账户', '/c8903/public/menu/menuedit.html', '1', '1536194702', '1536194702');
INSERT INTO `xt_action_log` VALUES ('2143', '1', '100000', '127.0.0.1', '新增', '新增菜单，name：会员财务', '/c8903/public/menu/menuadd.html', '1', '1536194839', '1536194839');
INSERT INTO `xt_action_log` VALUES ('2144', '1', '100000', '127.0.0.1', '新增', '新增菜单，name：会员资讯', '/c8903/public/menu/menuadd.html', '1', '1536194878', '1536194878');
INSERT INTO `xt_action_log` VALUES ('2145', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：财务明细', '/c8903/public/menu/menuedit.html', '1', '1536194901', '1536194901');
INSERT INTO `xt_action_log` VALUES ('2146', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：奖金明细', '/c8903/public/menu/menuedit.html', '1', '1536194918', '1536194918');
INSERT INTO `xt_action_log` VALUES ('2147', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：转账', '/c8903/public/menu/menuedit.html', '1', '1536194934', '1536194934');
INSERT INTO `xt_action_log` VALUES ('2148', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：充值', '/c8903/public/menu/menuedit.html', '1', '1536194951', '1536194951');
INSERT INTO `xt_action_log` VALUES ('2149', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：提现', '/c8903/public/menu/menuedit.html', '1', '1536194963', '1536194963');
INSERT INTO `xt_action_log` VALUES ('2150', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：新闻公告', '/c8903/public/menu/menuedit.html', '1', '1536194999', '1536194999');
INSERT INTO `xt_action_log` VALUES ('2151', '1', '100000', '127.0.0.1', '数据排序', '数据排序调整，model：Menu，id：1，value：0', '/c8903/public/menu/setsort.html', '1', '1536195068', '1536195068');
INSERT INTO `xt_action_log` VALUES ('2152', '1', '100000', '127.0.0.1', '数据排序', '数据排序调整，model：Menu，id：229，value：2', '/c8903/public/menu/setsort.html', '1', '1536195078', '1536195078');
INSERT INTO `xt_action_log` VALUES ('2153', '1', '100000', '127.0.0.1', '数据排序', '数据排序调整，model：Menu，id：242，value：3', '/c8903/public/menu/setsort.html', '1', '1536195085', '1536195085');
INSERT INTO `xt_action_log` VALUES ('2154', '1', '100000', '127.0.0.1', '数据排序', '数据排序调整，model：Menu，id：243，value：4', '/c8903/public/menu/setsort.html', '1', '1536195090', '1536195090');
INSERT INTO `xt_action_log` VALUES ('2155', '1', '100000', '127.0.0.1', '数据排序', '数据排序调整，model：Menu，id：198，value：5', '/c8903/public/menu/setsort.html', '1', '1536195119', '1536195119');
INSERT INTO `xt_action_log` VALUES ('2156', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：二维码分享', '/c8903/public/menu/menuedit.html', '1', '1536195197', '1536195197');
INSERT INTO `xt_action_log` VALUES ('2157', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536197611', '1536197611');
INSERT INTO `xt_action_log` VALUES ('2158', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：写邮件', '/c8903/public/menu/menuedit.html', '1', '1536197753', '1536197753');
INSERT INTO `xt_action_log` VALUES ('2159', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：发件箱', '/c8903/public/menu/menuedit.html', '1', '1536197852', '1536197852');
INSERT INTO `xt_action_log` VALUES ('2160', '1', '100000', '127.0.0.1', '编辑', '编辑菜单，name：收件箱', '/c8903/public/menu/menuedit.html', '1', '1536197898', '1536197898');
INSERT INTO `xt_action_log` VALUES ('2161', '1', '100000', '192.168.0.112', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536203683', '1536203683');
INSERT INTO `xt_action_log` VALUES ('2162', '1', '100000', '192.168.0.115', '导出', '导出会员列表', '/c8903/public/member/exportmemberlist.html?', '1', '1536214588', '1536214588');
INSERT INTO `xt_action_log` VALUES ('2163', '1', '100000', '192.168.0.115', '导出', '导出会员列表', '/c8903/public/member/exportmemberlist.html?', '1', '1536215045', '1536215045');
INSERT INTO `xt_action_log` VALUES ('2164', '1', '100000', '192.168.0.115', '导出', '导出会员列表', '/c8903/public/member/exportmemberlist.html', '1', '1536215228', '1536215228');
INSERT INTO `xt_action_log` VALUES ('2165', '1', '100000', '192.168.0.115', '导出', '导出会员列表', '/c8903/public/member/exportmemberlist.html?', '1', '1536215261', '1536215261');
INSERT INTO `xt_action_log` VALUES ('2166', '1', '100000', '192.168.0.115', '导出', '导出会员列表', '/c8903/public/member/exportmemberlist.html?', '1', '1536215310', '1536215310');
INSERT INTO `xt_action_log` VALUES ('2167', '1', '100000', '192.168.0.115', '导出', '导出会员列表', '/c8903/public/member/exportmemberlist.html', '1', '1536217567', '1536217567');
INSERT INTO `xt_action_log` VALUES ('2168', '1', '100000', '192.168.0.115', '导出', '导出提现列表', '/c8903/public/member/exportdrawallist.html', '1', '1536217795', '1536217795');
INSERT INTO `xt_action_log` VALUES ('2169', '1', '100000', '192.168.0.115', '导出', '导出提现列表', '/c8903/public/member/exportdrawallist.html', '1', '1536217814', '1536217814');
INSERT INTO `xt_action_log` VALUES ('2170', '1', '100000', '192.168.0.115', '导出', '导出提现列表', '/c8903/public/member/exportdrawallist.html', '1', '1536218049', '1536218049');
INSERT INTO `xt_action_log` VALUES ('2171', '1', '100000', '192.168.0.115', '导出', '导出提现列表', '/c8903/public/member/exportdrawallist.html', '1', '1536218348', '1536218348');
INSERT INTO `xt_action_log` VALUES ('2172', '1', '100000', '192.168.0.115', '导出', '导出提现列表', '/c8903/public/member/exportdrawallist.html', '1', '1536218428', '1536218428');
INSERT INTO `xt_action_log` VALUES ('2173', '1', '100000', '192.168.0.115', '导出', '导出会员列表', '/c8903/public/member/exportmemberlist.html', '1', '1536218583', '1536218583');
INSERT INTO `xt_action_log` VALUES ('2174', '1', '100000', '192.168.0.115', '导出', '导出提现列表', '/c8903/public/member/exportdrawallist.html', '1', '1536219302', '1536219302');
INSERT INTO `xt_action_log` VALUES ('2175', '1', '100000', '192.168.0.115', '导出', '导出充值列表', '/c8903/public/member/exportchargelist.html', '1', '1536219391', '1536219391');
INSERT INTO `xt_action_log` VALUES ('2176', '1', '100000', '192.168.0.115', '导出', '导出提现列表', '/c8903/public/member/exportdrawallist.html', '1', '1536219468', '1536219468');
INSERT INTO `xt_action_log` VALUES ('2177', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/c8903/public/login/loginhandle.html', '1', '1536229673', '1536229673');
INSERT INTO `xt_action_log` VALUES ('2178', '1', '100000', '192.168.0.115', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536230437', '1536230437');
INSERT INTO `xt_action_log` VALUES ('2179', '1', '100000', '192.168.0.115', '编辑', '编辑配置，name：seo_title', '/j8830/public/admin/config/configedit.html', '1', '1536230715', '1536230715');
INSERT INTO `xt_action_log` VALUES ('2180', '1', '100000', '192.168.0.115', '编辑', '编辑配置，name：seo_keywords', '/j8830/public/admin/config/configedit.html', '1', '1536230770', '1536230770');
INSERT INTO `xt_action_log` VALUES ('2181', '1', '100000', '192.168.0.115', '编辑', '编辑配置，name：seo_description', '/j8830/public/admin/config/configedit.html', '1', '1536230823', '1536230823');
INSERT INTO `xt_action_log` VALUES ('2182', '1', '100000', '192.168.0.115', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536231036', '1536231036');
INSERT INTO `xt_action_log` VALUES ('2183', '1', '100000', '192.168.0.115', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536231043', '1536231043');
INSERT INTO `xt_action_log` VALUES ('2184', '1', '100000', '192.168.0.115', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536231051', '1536231051');
INSERT INTO `xt_action_log` VALUES ('2185', '1', '100000', '192.168.0.115', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536231059', '1536231059');
INSERT INTO `xt_action_log` VALUES ('2186', '1', '100000', '192.168.0.115', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536231067', '1536231067');
INSERT INTO `xt_action_log` VALUES ('2187', '1', '100000', '192.168.0.115', '编辑', '编辑配置，name：seo_keywords', '/j8830/public/admin/config/configedit.html', '1', '1536231316', '1536231316');
INSERT INTO `xt_action_log` VALUES ('2188', '1', '100000', '192.168.0.115', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536231356', '1536231356');
INSERT INTO `xt_action_log` VALUES ('2189', '1', '100000', '192.168.0.115', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536231487', '1536231487');
INSERT INTO `xt_action_log` VALUES ('2190', '1', '100000', '127.0.0.1', '新增', '新增配置，name：money_type', '/j8830/public/admin/config/configadd.html', '1', '1536281115', '1536281115');
INSERT INTO `xt_action_log` VALUES ('2191', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536281204', '1536281204');
INSERT INTO `xt_action_log` VALUES ('2192', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536281730', '1536281730');
INSERT INTO `xt_action_log` VALUES ('2193', '1', '100000', '192.168.0.161', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536281955', '1536281955');
INSERT INTO `xt_action_log` VALUES ('2194', '1', '100000', '127.0.0.1', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536282905', '1536282905');
INSERT INTO `xt_action_log` VALUES ('2195', '1', '100000', '127.0.0.1', '导出', '导出充值列表', '/j8830/public/admin/member/exportchargelist.html', '1', '1536284421', '1536284421');
INSERT INTO `xt_action_log` VALUES ('2196', '1', '100000', '127.0.0.1', '新增', '新增菜单，name：任务', '/j8830/public/admin/menu/menuadd.html', '1', '1536284638', '1536284638');
INSERT INTO `xt_action_log` VALUES ('2197', '1', '100000', '127.0.0.1', '新增', '新增菜单，name：会员任务', '/j8830/public/admin/menu/menuadd.html', '1', '1536284783', '1536284783');
INSERT INTO `xt_action_log` VALUES ('2198', '1', '100000', '192.168.0.161', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536284792', '1536284792');
INSERT INTO `xt_action_log` VALUES ('2199', '1', '100000', '192.168.0.161', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536287638', '1536287638');
INSERT INTO `xt_action_log` VALUES ('2200', '1', '100000', '192.168.0.161', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536288210', '1536288210');
INSERT INTO `xt_action_log` VALUES ('2201', '1', '100000', '192.168.0.161', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536288521', '1536288521');
INSERT INTO `xt_action_log` VALUES ('2202', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536288602', '1536288602');
INSERT INTO `xt_action_log` VALUES ('2203', '1', '100000', '192.168.0.161', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536288975', '1536288975');
INSERT INTO `xt_action_log` VALUES ('2204', '1', '100000', '192.168.0.115', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536289129', '1536289129');
INSERT INTO `xt_action_log` VALUES ('2205', '1', '100000', '192.168.0.161', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536289443', '1536289443');
INSERT INTO `xt_action_log` VALUES ('2206', '1', '100000', '192.168.0.161', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536289591', '1536289591');
INSERT INTO `xt_action_log` VALUES ('2207', '1', '100000', '192.168.0.115', '新增', '新增菜单，name：任务提交', '/j8830/public/admin/menu/menuadd.html', '1', '1536294967', '1536294967');
INSERT INTO `xt_action_log` VALUES ('2208', '1', '100000', '192.168.0.115', '新增', '新增菜单，name：任务记录', '/j8830/public/admin/menu/menuadd.html', '1', '1536294989', '1536294989');
INSERT INTO `xt_action_log` VALUES ('2209', '1', '100000', '192.168.0.115', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536296709', '1536296709');
INSERT INTO `xt_action_log` VALUES ('2210', '1', '100000', '192.168.0.115', '编辑', '编辑菜单，name：购物商城', '/j8830/public/admin/menu/menuedit.html', '1', '1536303417', '1536303417');
INSERT INTO `xt_action_log` VALUES ('2211', '1', '100000', '192.168.0.115', '编辑', '产品编辑，name：广告包', '/j8830/public/admin/shopadmin/shopedit.html', '1', '1536303512', '1536303512');
INSERT INTO `xt_action_log` VALUES ('2212', '1', '100000', '192.168.0.115', '编辑', '产品编辑，name：广告包', '/j8830/public/admin/shopadmin/shopedit.html', '1', '1536303596', '1536303596');
INSERT INTO `xt_action_log` VALUES ('2213', '1', '100000', '192.168.0.115', '编辑', '产品编辑，name：广告包', '/j8830/public/admin/shopadmin/shopedit.html', '1', '1536310473', '1536310473');
INSERT INTO `xt_action_log` VALUES ('2214', '1', '100000', '192.168.0.115', '编辑', '产品编辑，name：广告包', '/j8830/public/admin/shopadmin/shopedit.html', '1', '1536310554', '1536310554');
INSERT INTO `xt_action_log` VALUES ('2215', '1', '100000', '192.168.0.115', '编辑', '产品编辑，name：广告包', '/j8830/public/admin/shopadmin/shopedit.html', '1', '1536310570', '1536310570');
INSERT INTO `xt_action_log` VALUES ('2216', '1', '100000', '192.168.0.115', '编辑', '产品编辑，name：广告包', '/j8830/public/admin/shopadmin/shopedit.html', '1', '1536310595', '1536310595');
INSERT INTO `xt_action_log` VALUES ('2217', '1', '100000', '192.168.0.115', '编辑', '产品编辑，name：广告包', '/j8830/public/admin/shopadmin/shopedit.html', '1', '1536310648', '1536310648');
INSERT INTO `xt_action_log` VALUES ('2218', '1', '100000', '192.168.0.115', '数据状态', '数据状态调整，model：Menu，ids：246，status：-1', '/j8830/public/admin/menu/setstatus/ids/246/status/-1.html', '1', '1536371323', '1536371323');
INSERT INTO `xt_action_log` VALUES ('2219', '1', '100000', '192.168.0.115', '数据状态', '数据状态调整，model：Menu，ids：247，status：-1', '/j8830/public/admin/menu/setstatus/ids/247/status/-1.html', '1', '1536371329', '1536371329');
INSERT INTO `xt_action_log` VALUES ('2220', '1', '100000', '192.168.0.115', '数据状态', '数据状态调整，model：Menu，ids：244，status：-1', '/j8830/public/admin/menu/setstatus/ids/244/status/-1.html', '1', '1536371334', '1536371334');
INSERT INTO `xt_action_log` VALUES ('2221', '1', '100000', '192.168.0.115', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536372377', '1536372377');
INSERT INTO `xt_action_log` VALUES ('2222', '1', '100000', '192.168.0.115', '编辑', '产品编辑，name：广告包', '/j8830/public/admin/shopadmin/shopedit.html', '1', '1536379872', '1536379872');
INSERT INTO `xt_action_log` VALUES ('2223', '1', '100000', '192.168.0.161', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536387729', '1536387729');
INSERT INTO `xt_action_log` VALUES ('2224', '1', '100000', '192.168.0.115', '编辑', '产品编辑，name：广告包', '/j8830/public/admin/shopadmin/shopedit.html', '1', '1536392283', '1536392283');
INSERT INTO `xt_action_log` VALUES ('2225', '1', '100000', '192.168.0.115', '编辑', '产品编辑，name：广告包', '/j8830/public/admin/shopadmin/shopedit.html', '1', '1536394129', '1536394129');
INSERT INTO `xt_action_log` VALUES ('2226', '1', '100000', '192.168.0.115', '新增', '新增配置，name：alipay', '/j8830/public/admin/config/configadd.html', '1', '1536404196', '1536404196');
INSERT INTO `xt_action_log` VALUES ('2227', '1', '100000', '192.168.0.115', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536404228', '1536404228');
INSERT INTO `xt_action_log` VALUES ('2228', '1', '100000', '192.168.0.115', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536404242', '1536404242');
INSERT INTO `xt_action_log` VALUES ('2229', '1', '100000', '192.168.0.115', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536404258', '1536404258');
INSERT INTO `xt_action_log` VALUES ('2230', '1', '100000', '192.168.0.115', '新增', '新增配置，name：weixin', '/j8830/public/admin/config/configadd.html', '1', '1536404301', '1536404301');
INSERT INTO `xt_action_log` VALUES ('2231', '1', '100000', '192.168.0.115', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536404318', '1536404318');
INSERT INTO `xt_action_log` VALUES ('2232', '1', '100000', '192.168.0.115', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536406389', '1536406389');
INSERT INTO `xt_action_log` VALUES ('2233', '1', '100000', '192.168.0.115', '新增', '新增配置，name：ad', '/j8830/public/admin/config/configadd.html', '1', '1536406831', '1536406831');
INSERT INTO `xt_action_log` VALUES ('2234', '1', '100000', '192.168.0.115', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536407964', '1536407964');
INSERT INTO `xt_action_log` VALUES ('2235', '1', '100000', '192.168.0.115', '新增', '新增配置，name：how', '/j8830/public/admin/config/configadd.html', '1', '1536409204', '1536409204');
INSERT INTO `xt_action_log` VALUES ('2236', '1', '100000', '192.168.0.115', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536409233', '1536409233');
INSERT INTO `xt_action_log` VALUES ('2237', '1', '100000', '192.168.0.115', '编辑', '编辑菜单，name：接口管理', '/j8830/public/admin/menu/menuedit.html', '1', '1536410799', '1536410799');
INSERT INTO `xt_action_log` VALUES ('2238', '1', '100000', '192.168.0.115', '编辑', '编辑菜单，name：服务管理', '/j8830/public/admin/menu/menuedit.html', '1', '1536411048', '1536411048');
INSERT INTO `xt_action_log` VALUES ('2239', '1', '100000', '192.168.0.115', '编辑', '编辑菜单，name：服务管理', '/j8830/public/admin/menu/menuedit.html', '1', '1536411896', '1536411896');
INSERT INTO `xt_action_log` VALUES ('2240', '1', '100000', '192.168.0.115', '编辑', '编辑菜单，name：驱动安装', '/j8830/public/admin/menu/menuedit.html', '1', '1536411965', '1536411965');
INSERT INTO `xt_action_log` VALUES ('2241', '1', '100000', '192.168.0.115', '安装', '驱动安装或设置，service_name：Pay，driver_nameAlipay', '/j8830/public/admin/service/driverinstall.html', '1', '1536412913', '1536412913');
INSERT INTO `xt_action_log` VALUES ('2242', '1', '100000', '192.168.0.115', '卸载', '驱动卸载，service_name：Pay，driver_nameAlipay', '/j8830/public/admin/service/driveruninstall/service_class/Pay/driver_class/Alipay.html', '1', '1536412927', '1536412927');
INSERT INTO `xt_action_log` VALUES ('2243', '1', '100000', '192.168.0.115', '新增', '新增配置，name：task', '/j8830/public/admin/config/configadd.html', '1', '1536539506', '1536539506');
INSERT INTO `xt_action_log` VALUES ('2244', '1', '100000', '192.168.0.115', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536539771', '1536539771');
INSERT INTO `xt_action_log` VALUES ('2245', '1', '100000', '192.168.0.115', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536541992', '1536541992');
INSERT INTO `xt_action_log` VALUES ('2246', '1', '100000', '192.168.0.115', '编辑', '产品编辑，name：广告包', '/j8830/public/admin/shopadmin/shopedit.html', '1', '1536546137', '1536546137');
INSERT INTO `xt_action_log` VALUES ('2247', '1', '100000', '192.168.0.115', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536546164', '1536546164');
INSERT INTO `xt_action_log` VALUES ('2248', '1', '100000', '192.168.0.115', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536546509', '1536546509');
INSERT INTO `xt_action_log` VALUES ('2249', '1', '100000', '192.168.0.161', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536547176', '1536547176');
INSERT INTO `xt_action_log` VALUES ('2250', '1', '100000', '192.168.0.115', '数据状态', '数据状态调整，model：Config，ids：81,80,79,78，status：-1', '/j8830/public/admin/config/setstatus.html', '1', '1536549388', '1536549388');
INSERT INTO `xt_action_log` VALUES ('2251', '1', '100000', '192.168.0.115', '数据状态', '数据状态调整，model：Config，ids：77,76,74，status：-1', '/j8830/public/admin/config/setstatus.html', '1', '1536549400', '1536549400');
INSERT INTO `xt_action_log` VALUES ('2252', '1', '100000', '192.168.0.115', '编辑', '编辑菜单，name：流水明细', '/j8830/public/admin/menu/menuedit.html', '1', '1536549578', '1536549578');
INSERT INTO `xt_action_log` VALUES ('2253', '1', '100000', '192.168.0.115', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536549873', '1536549873');
INSERT INTO `xt_action_log` VALUES ('2254', '1', '100000', '192.168.0.115', '新增', '新增配置，name：statistic_income', '/j8830/public/admin/config/configadd.html', '1', '1536549994', '1536549994');
INSERT INTO `xt_action_log` VALUES ('2255', '1', '100000', '192.168.0.115', '新增', '新增配置，name：dynamic_income', '/j8830/public/admin/config/configadd.html', '1', '1536550117', '1536550117');
INSERT INTO `xt_action_log` VALUES ('2256', '1', '100000', '192.168.0.115', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536550206', '1536550206');
INSERT INTO `xt_action_log` VALUES ('2257', '1', '100000', '192.168.0.115', '数据状态', '数据状态调整，model：Config，ids：67，status：-1', '/j8830/public/admin/config/setstatus/ids/67/status/-1.html', '1', '1536550226', '1536550226');
INSERT INTO `xt_action_log` VALUES ('2258', '1', '100000', '192.168.0.115', '数据排序', '数据排序调整，model：Config，id：89，value：1', '/j8830/public/admin/config/setsort.html', '1', '1536550321', '1536550321');
INSERT INTO `xt_action_log` VALUES ('2259', '1', '100000', '192.168.0.115', '数据排序', '数据排序调整，model：Config，id：88，value：1', '/j8830/public/admin/config/setsort.html', '1', '1536550326', '1536550326');
INSERT INTO `xt_action_log` VALUES ('2260', '1', '100000', '192.168.0.115', '数据排序', '数据排序调整，model：Config，id：84，value：2', '/j8830/public/admin/config/setsort.html', '1', '1536550340', '1536550340');
INSERT INTO `xt_action_log` VALUES ('2261', '1', '100000', '192.168.0.115', '数据状态', '数据状态调整，model：Config，ids：70，status：-1', '/j8830/public/admin/config/setstatus/ids/70/status/-1.html', '1', '1536550353', '1536550353');
INSERT INTO `xt_action_log` VALUES ('2262', '1', '100000', '192.168.0.115', '编辑', '编辑配置，name：cpzj', '/j8830/public/admin/config/configedit.html', '1', '1536550367', '1536550367');
INSERT INTO `xt_action_log` VALUES ('2263', '1', '100000', '192.168.0.115', '数据排序', '数据排序调整，model：Config，id：83，value：2', '/j8830/public/admin/config/setsort.html', '1', '1536550397', '1536550397');
INSERT INTO `xt_action_log` VALUES ('2264', '1', '100000', '192.168.0.115', '数据排序', '数据排序调整，model：Config，id：86，value：3', '/j8830/public/admin/config/setsort.html', '1', '1536550450', '1536550450');
INSERT INTO `xt_action_log` VALUES ('2265', '1', '100000', '192.168.0.115', '数据排序', '数据排序调整，model：Config，id：71，value：4', '/j8830/public/admin/config/setsort.html', '1', '1536550469', '1536550469');
INSERT INTO `xt_action_log` VALUES ('2266', '1', '100000', '192.168.0.115', '数据排序', '数据排序调整，model：Config，id：82，value：4', '/j8830/public/admin/config/setsort.html', '1', '1536550473', '1536550473');
INSERT INTO `xt_action_log` VALUES ('2267', '1', '100000', '192.168.0.115', '编辑', '编辑菜单，name：接点图', '/j8830/public/admin/menu/menuedit.html', '1', '1536553566', '1536553566');
INSERT INTO `xt_action_log` VALUES ('2268', '1', '100000', '192.168.0.115', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536553896', '1536553896');
INSERT INTO `xt_action_log` VALUES ('2269', '1', '100000', '192.168.0.115', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536555219', '1536555219');
INSERT INTO `xt_action_log` VALUES ('2270', '1', '100000', '192.168.0.115', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536557250', '1536557250');
INSERT INTO `xt_action_log` VALUES ('2271', '1', '100000', '192.168.0.115', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536557262', '1536557262');
INSERT INTO `xt_action_log` VALUES ('2272', '2', '111111', '192.168.0.115', '登录', '登录操作，username：111111', '/j8830/public/admin/login/loginhandle.html', '1', '1536562244', '1536562244');
INSERT INTO `xt_action_log` VALUES ('2273', '2', '111111', '192.168.0.115', '登录', '登录操作，username：111111', '/j8830/public/admin/login/loginhandle.html', '1', '1536562329', '1536562329');
INSERT INTO `xt_action_log` VALUES ('2274', '1', '100000', '192.168.0.115', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536562558', '1536562558');
INSERT INTO `xt_action_log` VALUES ('2275', '1', '100000', '192.168.0.115', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536562759', '1536562759');
INSERT INTO `xt_action_log` VALUES ('2276', '1', '100000', '192.168.0.115', '数据状态', '数据状态调整，model：Menu，ids：227,240，status：0', '/j8830/public/admin/menu/setstatus.html', '1', '1536563010', '1536563010');
INSERT INTO `xt_action_log` VALUES ('2277', '1', '100000', '192.168.0.115', '编辑', '编辑菜单，name：会员激活', '/j8830/public/admin/menu/menuedit.html', '1', '1536563027', '1536563027');
INSERT INTO `xt_action_log` VALUES ('2278', '1', '100000', '192.168.0.115', '编辑', '编辑菜单，name：注册账户', '/j8830/public/admin/menu/menuedit.html', '1', '1536563044', '1536563044');
INSERT INTO `xt_action_log` VALUES ('2279', '3', '111111', '192.168.0.115', '登录', '登录操作，username：111111', '/j8830/public/admin/login/loginhandle.html', '1', '1536563083', '1536563083');
INSERT INTO `xt_action_log` VALUES ('2280', '1', '100000', '192.168.0.115', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536563824', '1536563824');
INSERT INTO `xt_action_log` VALUES ('2281', '3', '111111', '192.168.0.115', '登录', '登录操作，username：111111', '/j8830/public/admin/login/loginhandle.html', '1', '1536563866', '1536563866');
INSERT INTO `xt_action_log` VALUES ('2282', '1', '100000', '192.168.0.115', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536564155', '1536564155');
INSERT INTO `xt_action_log` VALUES ('2283', '1', '100000', '192.168.0.115', '编辑', '编辑菜单，name：会员资讯', '/j8830/public/admin/menu/menuedit.html', '1', '1536568245', '1536568245');
INSERT INTO `xt_action_log` VALUES ('2284', '1', '100000', '192.168.0.115', '编辑', '编辑菜单，name：公告管理', '/j8830/public/admin/menu/menuedit.html', '1', '1536568258', '1536568258');
INSERT INTO `xt_action_log` VALUES ('2285', '1', '100000', '192.168.0.115', '编辑', '编辑菜单，name：个人设置', '/j8830/public/admin/menu/menuedit.html', '1', '1536568298', '1536568298');
INSERT INTO `xt_action_log` VALUES ('2286', '1', '100000', '192.168.0.115', '编辑', '编辑菜单，name：会员中心', '/j8830/public/admin/menu/menuedit.html', '1', '1536568310', '1536568310');
INSERT INTO `xt_action_log` VALUES ('2287', '1', '100000', '192.168.0.115', '编辑', '编辑菜单，name：关系图', '/j8830/public/admin/menu/menuedit.html', '1', '1536568331', '1536568331');
INSERT INTO `xt_action_log` VALUES ('2288', '1', '100000', '192.168.0.115', '编辑', '编辑菜单，name：会员财务', '/j8830/public/admin/menu/menuedit.html', '1', '1536568372', '1536568372');
INSERT INTO `xt_action_log` VALUES ('2289', '1', '100000', '192.168.0.115', '新增', '新增配置，name：kefu_weixin', '/j8830/public/admin/config/configadd.html', '1', '1536568561', '1536568561');
INSERT INTO `xt_action_log` VALUES ('2290', '1', '100000', '192.168.0.115', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536568587', '1536568587');
INSERT INTO `xt_action_log` VALUES ('2291', '1', '100000', '192.168.0.115', '数据排序', '数据排序调整，model：Config，id：90，value：2', '/j8830/public/admin/config/setsort.html', '1', '1536568615', '1536568615');
INSERT INTO `xt_action_log` VALUES ('2292', '1', '100000', '192.168.0.115', '编辑', '编辑菜单，name：我的信息', '/j8830/public/admin/menu/menuedit.html', '1', '1536570093', '1536570093');
INSERT INTO `xt_action_log` VALUES ('2293', '1', '100000', '192.168.0.115', '编辑', '编辑菜单，name：产品管理', '/j8830/public/admin/menu/menuedit.html', '1', '1536570158', '1536570158');
INSERT INTO `xt_action_log` VALUES ('2294', '1', '100000', '192.168.0.115', '编辑', '编辑菜单，name：购物商城', '/j8830/public/admin/menu/menuedit.html', '1', '1536570177', '1536570177');
INSERT INTO `xt_action_log` VALUES ('2295', '1', '100000', '192.168.0.115', '编辑', '编辑菜单，name：产品管理', '/j8830/public/admin/menu/menuedit.html', '1', '1536570227', '1536570227');
INSERT INTO `xt_action_log` VALUES ('2296', '1', '100000', '192.168.0.115', '编辑', '编辑菜单，name：会员管理', '/j8830/public/admin/menu/menuedit.html', '1', '1536570250', '1536570250');
INSERT INTO `xt_action_log` VALUES ('2297', '1', '100000', '192.168.0.115', '编辑', '编辑菜单，name：系统设置', '/j8830/public/admin/menu/menuedit.html', '1', '1536570294', '1536570294');
INSERT INTO `xt_action_log` VALUES ('2298', '1', '100000', '192.168.0.115', '编辑', '编辑菜单，name：货币流向', '/j8830/public/admin/menu/menuedit.html', '1', '1536570308', '1536570308');
INSERT INTO `xt_action_log` VALUES ('2299', '1', '100000', '192.168.0.115', '编辑', '编辑菜单，name：数据还原', '/j8830/public/admin/menu/menuedit.html', '1', '1536570326', '1536570326');
INSERT INTO `xt_action_log` VALUES ('2300', '1', '100000', '192.168.0.115', '编辑', '编辑菜单，name：权限管理', '/j8830/public/admin/menu/menuedit.html', '1', '1536570394', '1536570394');
INSERT INTO `xt_action_log` VALUES ('2301', '1', '100000', '192.168.0.115', '编辑', '编辑菜单，name：会员注册', '/j8830/public/admin/menu/menuedit.html', '1', '1536570487', '1536570487');
INSERT INTO `xt_action_log` VALUES ('2302', '1', '100000', '192.168.0.115', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536570822', '1536570822');
INSERT INTO `xt_action_log` VALUES ('2303', '1', '100000', '192.168.0.115', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536570963', '1536570963');
INSERT INTO `xt_action_log` VALUES ('2304', '1', '100000', '192.168.0.115', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536570998', '1536570998');
INSERT INTO `xt_action_log` VALUES ('2305', '1', '100000', '192.168.0.115', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536571070', '1536571070');
INSERT INTO `xt_action_log` VALUES ('2306', '1', '100000', '192.168.0.115', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536571126', '1536571126');
INSERT INTO `xt_action_log` VALUES ('2307', '1', '100000', '192.168.0.115', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536573242', '1536573242');
INSERT INTO `xt_action_log` VALUES ('2308', '1', '100000', '127.0.0.1', '编辑', '编辑会员，id：1', '/j8830/public/admin/member/memberedit.html', '1', '1536581040', '1536581040');
INSERT INTO `xt_action_log` VALUES ('2309', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536581425', '1536581425');
INSERT INTO `xt_action_log` VALUES ('2310', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536582109', '1536582109');
INSERT INTO `xt_action_log` VALUES ('2311', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536582142', '1536582142');
INSERT INTO `xt_action_log` VALUES ('2312', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536641428', '1536641428');
INSERT INTO `xt_action_log` VALUES ('2313', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536646415', '1536646415');
INSERT INTO `xt_action_log` VALUES ('2314', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：ad', '/j8830/public/admin/config/configedit.html', '1', '1536646443', '1536646443');
INSERT INTO `xt_action_log` VALUES ('2315', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536646747', '1536646747');
INSERT INTO `xt_action_log` VALUES ('2316', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536646850', '1536646850');
INSERT INTO `xt_action_log` VALUES ('2317', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536646915', '1536646915');
INSERT INTO `xt_action_log` VALUES ('2318', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536646946', '1536646946');
INSERT INTO `xt_action_log` VALUES ('2319', '1', '100000', '192.168.0.122', '新增', '新增配置，name：ad_content', '/j8830/public/admin/config/configadd.html', '1', '1536647163', '1536647163');
INSERT INTO `xt_action_log` VALUES ('2320', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536647202', '1536647202');
INSERT INTO `xt_action_log` VALUES ('2321', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：how', '/j8830/public/admin/config/configedit.html', '1', '1536647756', '1536647756');
INSERT INTO `xt_action_log` VALUES ('2322', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：weixin', '/j8830/public/admin/config/configedit.html', '1', '1536647770', '1536647770');
INSERT INTO `xt_action_log` VALUES ('2323', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：alipay', '/j8830/public/admin/config/configedit.html', '1', '1536647782', '1536647782');
INSERT INTO `xt_action_log` VALUES ('2324', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：kefu_weixin', '/j8830/public/admin/config/configedit.html', '1', '1536647819', '1536647819');
INSERT INTO `xt_action_log` VALUES ('2325', '1', '100000', '192.168.0.122', '数据排序', '数据排序调整，model：Config，id：91，value：10', '/j8830/public/admin/config/setsort.html', '1', '1536647863', '1536647863');
INSERT INTO `xt_action_log` VALUES ('2326', '1', '100000', '192.168.0.122', '数据排序', '数据排序调整，model：Config，id：91，value：1', '/j8830/public/admin/config/setsort.html', '1', '1536647873', '1536647873');
INSERT INTO `xt_action_log` VALUES ('2327', '1', '100000', '192.168.0.122', '数据排序', '数据排序调整，model：Config，id：85，value：10', '/j8830/public/admin/config/setsort.html', '1', '1536647883', '1536647883');
INSERT INTO `xt_action_log` VALUES ('2328', '1', '100000', '192.168.0.122', '数据排序', '数据排序调整，model：Config，id：89，value：11', '/j8830/public/admin/config/setsort.html', '1', '1536647890', '1536647890');
INSERT INTO `xt_action_log` VALUES ('2329', '1', '100000', '192.168.0.122', '数据排序', '数据排序调整，model：Config，id：90，value：12', '/j8830/public/admin/config/setsort.html', '1', '1536647897', '1536647897');
INSERT INTO `xt_action_log` VALUES ('2330', '1', '100000', '192.168.0.122', '数据排序', '数据排序调整，model：Config，id：88，value：13', '/j8830/public/admin/config/setsort.html', '1', '1536647903', '1536647903');
INSERT INTO `xt_action_log` VALUES ('2331', '1', '100000', '192.168.0.122', '数据排序', '数据排序调整，model：Config，id：90，value：1', '/j8830/public/admin/config/setsort.html', '1', '1536647934', '1536647934');
INSERT INTO `xt_action_log` VALUES ('2332', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536648037', '1536648037');
INSERT INTO `xt_action_log` VALUES ('2333', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536648066', '1536648066');
INSERT INTO `xt_action_log` VALUES ('2334', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536648075', '1536648075');
INSERT INTO `xt_action_log` VALUES ('2335', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536648580', '1536648580');
INSERT INTO `xt_action_log` VALUES ('2336', '1', '100000', '192.168.0.144', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536651862', '1536651862');
INSERT INTO `xt_action_log` VALUES ('2337', '1', '100000', '192.168.0.122', '编辑', '编辑菜单，name：关系图', '/j8830/public/admin/menu/menuedit.html', '1', '1536668944', '1536668944');
INSERT INTO `xt_action_log` VALUES ('2338', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536739627', '1536739627');
INSERT INTO `xt_action_log` VALUES ('2339', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536739821', '1536739821');
INSERT INTO `xt_action_log` VALUES ('2340', '1', '100000', '192.168.0.122', '新增', '新增配置，name：scroll_picture ', '/j8830/public/admin/config/configadd.html', '1', '1536740209', '1536740209');
INSERT INTO `xt_action_log` VALUES ('2341', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：scroll_picture ', '/j8830/public/admin/config/configedit.html', '1', '1536740249', '1536740249');
INSERT INTO `xt_action_log` VALUES ('2342', '1', '100000', '192.168.0.122', '数据排序', '数据排序调整，model：Config，id：92，value：21', '/j8830/public/admin/config/setsort.html', '1', '1536740277', '1536740277');
INSERT INTO `xt_action_log` VALUES ('2343', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：scroll_picture ', '/j8830/public/admin/config/configedit.html', '1', '1536740345', '1536740345');
INSERT INTO `xt_action_log` VALUES ('2344', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：scroll_picture ', '/j8830/public/admin/config/configedit.html', '1', '1536740408', '1536740408');
INSERT INTO `xt_action_log` VALUES ('2345', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：scroll_picture ', '/j8830/public/admin/config/configedit.html', '1', '1536740471', '1536740471');
INSERT INTO `xt_action_log` VALUES ('2346', '1', '100000', '192.168.0.122', '数据状态', '数据状态调整，model：Config，ids：92，status：-1', '/j8830/public/admin/config/setstatus/ids/92/status/-1.html', '1', '1536740640', '1536740640');
INSERT INTO `xt_action_log` VALUES ('2347', '1', '100000', '192.168.0.122', '新增', '新增配置，name：2342', '/j8830/public/admin/config/configadd.html', '1', '1536740653', '1536740653');
INSERT INTO `xt_action_log` VALUES ('2348', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：scroll_picture 1', '/j8830/public/admin/config/configedit.html', '1', '1536740727', '1536740727');
INSERT INTO `xt_action_log` VALUES ('2349', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：scroll_picture1', '/j8830/public/admin/config/configedit.html', '1', '1536740764', '1536740764');
INSERT INTO `xt_action_log` VALUES ('2350', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：scroll_p', '/j8830/public/admin/config/configedit.html', '1', '1536740797', '1536740797');
INSERT INTO `xt_action_log` VALUES ('2351', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：scroll_p', '/j8830/public/admin/config/configedit.html', '1', '1536740891', '1536740891');
INSERT INTO `xt_action_log` VALUES ('2352', '1', '100000', '192.168.0.122', '新增', '新增配置，name：end_time', '/j8830/public/admin/config/configadd.html', '1', '1536741568', '1536741568');
INSERT INTO `xt_action_log` VALUES ('2353', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536742063', '1536742063');
INSERT INTO `xt_action_log` VALUES ('2354', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536742246', '1536742246');
INSERT INTO `xt_action_log` VALUES ('2355', '1', '100000', '192.168.0.144', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536743772', '1536743772');
INSERT INTO `xt_action_log` VALUES ('2356', '1', '100000', '192.168.0.144', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536745985', '1536745985');
INSERT INTO `xt_action_log` VALUES ('2357', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536747079', '1536747079');
INSERT INTO `xt_action_log` VALUES ('2358', '1', '100000', '192.168.0.144', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536799506', '1536799506');
INSERT INTO `xt_action_log` VALUES ('2359', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536800579', '1536800579');
INSERT INTO `xt_action_log` VALUES ('2360', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536800605', '1536800605');
INSERT INTO `xt_action_log` VALUES ('2361', '1', '100000', '192.168.0.122', '新增', '新增配置，name：max_ad', '/j8830/public/admin/config/configadd.html', '1', '1536808039', '1536808039');
INSERT INTO `xt_action_log` VALUES ('2362', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：max_ad', '/j8830/public/admin/config/configedit.html', '1', '1536808054', '1536808054');
INSERT INTO `xt_action_log` VALUES ('2363', '1', '100000', '192.168.0.122', '新增', '新增配置，name：be_out_ad', '/j8830/public/admin/config/configadd.html', '1', '1536808506', '1536808506');
INSERT INTO `xt_action_log` VALUES ('2364', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：be_out_ad', '/j8830/public/admin/config/configedit.html', '1', '1536808516', '1536808516');
INSERT INTO `xt_action_log` VALUES ('2365', '1', '100000', '192.168.0.122', '数据排序', '数据排序调整，model：Config，id：96，value：35', '/j8830/public/admin/config/setsort.html', '1', '1536808540', '1536808540');
INSERT INTO `xt_action_log` VALUES ('2366', '1', '100000', '192.168.0.122', '数据排序', '数据排序调整，model：Config，id：95，value：36', '/j8830/public/admin/config/setsort.html', '1', '1536808546', '1536808546');
INSERT INTO `xt_action_log` VALUES ('2367', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536808557', '1536808557');
INSERT INTO `xt_action_log` VALUES ('2368', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：max_ad', '/j8830/public/admin/config/configedit.html', '1', '1536808592', '1536808592');
INSERT INTO `xt_action_log` VALUES ('2369', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536810001', '1536810001');
INSERT INTO `xt_action_log` VALUES ('2370', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536810001', '1536810001');
INSERT INTO `xt_action_log` VALUES ('2371', '1', '100000', '192.168.0.122', '编辑', '产品编辑，name：广告包', '/j8830/public/admin/shopadmin/shopedit.html', '1', '1536810026', '1536810026');
INSERT INTO `xt_action_log` VALUES ('2372', '1', '100000', '192.168.0.122', '新增', '新增配置，name：dynamic_out', '/j8830/public/admin/config/configadd.html', '1', '1536831572', '1536831572');
INSERT INTO `xt_action_log` VALUES ('2373', '1', '100000', '192.168.0.122', '新增', '新增配置，name：statistic_out', '/j8830/public/admin/config/configadd.html', '1', '1536831625', '1536831625');
INSERT INTO `xt_action_log` VALUES ('2374', '1', '100000', '192.168.0.122', '数据排序', '数据排序调整，model：Config，id：98，value：37', '/j8830/public/admin/config/setsort.html', '1', '1536831655', '1536831655');
INSERT INTO `xt_action_log` VALUES ('2375', '1', '100000', '192.168.0.122', '数据排序', '数据排序调整，model：Config，id：97，value：38', '/j8830/public/admin/config/setsort.html', '1', '1536831661', '1536831661');
INSERT INTO `xt_action_log` VALUES ('2376', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：dynamic_out', '/j8830/public/admin/config/configedit.html', '1', '1536831701', '1536831701');
INSERT INTO `xt_action_log` VALUES ('2377', '1', '100000', '192.168.0.144', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536885956', '1536885956');
INSERT INTO `xt_action_log` VALUES ('2378', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536886702', '1536886702');
INSERT INTO `xt_action_log` VALUES ('2379', '1', '100000', '192.168.0.122', '编辑', '产品编辑，name：广告包', '/j8830/public/admin/shopadmin/shopedit.html', '1', '1536886769', '1536886769');
INSERT INTO `xt_action_log` VALUES ('2380', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536886789', '1536886789');
INSERT INTO `xt_action_log` VALUES ('2381', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：be_out_ad', '/j8830/public/admin/config/configedit.html', '1', '1536886862', '1536886862');
INSERT INTO `xt_action_log` VALUES ('2382', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：be_out_ad', '/j8830/public/admin/config/configedit.html', '1', '1536887001', '1536887001');
INSERT INTO `xt_action_log` VALUES ('2383', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536887120', '1536887120');
INSERT INTO `xt_action_log` VALUES ('2384', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：be_out_ad', '/j8830/public/admin/config/configedit.html', '1', '1536887193', '1536887193');
INSERT INTO `xt_action_log` VALUES ('2385', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：be_out_ad', '/j8830/public/admin/config/configedit.html', '1', '1536887411', '1536887411');
INSERT INTO `xt_action_log` VALUES ('2386', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：be_out_ad', '/j8830/public/admin/config/configedit.html', '1', '1536887746', '1536887746');
INSERT INTO `xt_action_log` VALUES ('2387', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536893323', '1536893323');
INSERT INTO `xt_action_log` VALUES ('2388', '1', '100000', '192.168.0.122', '编辑', '编辑会员，id：2', '/j8830/public/admin/member/memberedit.html', '1', '1536893459', '1536893459');
INSERT INTO `xt_action_log` VALUES ('2389', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536893509', '1536893509');
INSERT INTO `xt_action_log` VALUES ('2390', '2', '111111', '192.168.0.122', '登录', '登录操作，username：111111', '/j8830/public/admin/login/loginhandle.html', '1', '1536893645', '1536893645');
INSERT INTO `xt_action_log` VALUES ('2391', '2', '111111', '192.168.0.122', '登录', '登录操作，username：111111', '/j8830/public/admin/login/loginhandle.html', '1', '1536896271', '1536896271');
INSERT INTO `xt_action_log` VALUES ('2392', '1', '100000', '192.168.0.144', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536897196', '1536897196');
INSERT INTO `xt_action_log` VALUES ('2393', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536899505', '1536899505');
INSERT INTO `xt_action_log` VALUES ('2394', '1', '100000', '192.168.0.122', '新增', '新增配置，name：bank', '/j8830/public/admin/config/configadd.html', '1', '1536899953', '1536899953');
INSERT INTO `xt_action_log` VALUES ('2395', '1', '100000', '192.168.0.144', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536905348', '1536905348');
INSERT INTO `xt_action_log` VALUES ('2396', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536912378', '1536912378');
INSERT INTO `xt_action_log` VALUES ('2397', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：scroll_p', '/j8830/public/admin/config/configedit.html', '1', '1536917911', '1536917911');
INSERT INTO `xt_action_log` VALUES ('2398', '1', '100000', '192.168.0.122', '编辑', '编辑菜单，name：关系图', '/j8830/public/admin/menu/menuedit.html', '1', '1536917935', '1536917935');
INSERT INTO `xt_action_log` VALUES ('2399', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：bank', '/j8830/public/admin/config/configedit.html', '1', '1536918139', '1536918139');
INSERT INTO `xt_action_log` VALUES ('2400', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：bank', '/j8830/public/admin/config/configedit.html', '1', '1536918146', '1536918146');
INSERT INTO `xt_action_log` VALUES ('2401', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536918431', '1536918431');
INSERT INTO `xt_action_log` VALUES ('2402', '1', '100000', '192.168.0.144', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536918680', '1536918680');
INSERT INTO `xt_action_log` VALUES ('2403', '1', '100000', '192.168.0.122', '编辑', '编辑菜单，name：菜单管理', '/j8830/public/admin/menu/menuedit.html', '1', '1536918778', '1536918778');
INSERT INTO `xt_action_log` VALUES ('2404', '1', '100000', '192.168.0.122', '编辑', '编辑菜单，name：服务管理', '/j8830/public/admin/menu/menuedit.html', '1', '1536918795', '1536918795');
INSERT INTO `xt_action_log` VALUES ('2405', '1', '100000', '192.168.0.122', '编辑', '编辑菜单，name：接口管理', '/j8830/public/admin/menu/menuedit.html', '1', '1536918823', '1536918823');
INSERT INTO `xt_action_log` VALUES ('2406', '1', '100000', '192.168.0.122', '编辑', '编辑菜单，name：后台管理', '/j8830/public/admin/menu/menuedit.html', '1', '1536918855', '1536918855');
INSERT INTO `xt_action_log` VALUES ('2407', '1', '100000', '192.168.0.122', '编辑', '编辑菜单，name：数据库', '/j8830/public/admin/menu/menuedit.html', '1', '1536918914', '1536918914');
INSERT INTO `xt_action_log` VALUES ('2408', '1', '100000', '192.168.0.122', '编辑', '编辑菜单，name：数据还原', '/j8830/public/admin/menu/menuedit.html', '1', '1536918969', '1536918969');
INSERT INTO `xt_action_log` VALUES ('2409', '1', '100000', '192.168.0.122', '备份', '数据库备份', '/j8830/public/admin/database/databackup.html', '1', '1536919022', '1536919022');
INSERT INTO `xt_action_log` VALUES ('2410', '1', '100000', '192.168.0.122', '备份', '数据库备份', '/j8830/public/admin/database/databackup.html', '1', '1536930285', '1536930285');
INSERT INTO `xt_action_log` VALUES ('2411', '1', '100000', '192.168.0.122', '删除', '数据库备份文件删除，path：D:\\wamp64\\www\\j8830\\data\\20180914-210444-*.sql*', '/j8830/public/admin/database/backupdel/time/1536930284.html', '1', '1536930301', '1536930301');
INSERT INTO `xt_action_log` VALUES ('2412', '1', '100000', '192.168.0.122', '备份', '数据库备份', '/s8726/public/admin/database/databackup.html', '1', '1536930377', '1536930377');
INSERT INTO `xt_action_log` VALUES ('2413', '1', '100000', '192.168.0.144', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536972478', '1536972478');
INSERT INTO `xt_action_log` VALUES ('2414', '1', '100000', '192.168.0.122', '编辑', '编辑菜单，name：菜单管理', '/j8830/public/admin/menu/menuedit.html', '1', '1536974142', '1536974142');
INSERT INTO `xt_action_log` VALUES ('2415', '1', '100000', '192.168.0.122', '编辑', '编辑菜单，name：菜单管理', '/j8830/public/admin/menu/menuedit.html', '1', '1536974178', '1536974178');
INSERT INTO `xt_action_log` VALUES ('2416', '1', '100000', '192.168.0.122', '新增', '新增配置，name：bank_gathering', '/j8830/public/admin/config/configadd.html', '1', '1536974273', '1536974273');
INSERT INTO `xt_action_log` VALUES ('2417', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536974359', '1536974359');
INSERT INTO `xt_action_log` VALUES ('2418', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536979373', '1536979373');
INSERT INTO `xt_action_log` VALUES ('2419', '1', '100000', '192.168.0.122', '新增', '新增配置，name：task2', '/j8830/public/admin/config/configadd.html', '1', '1536995620', '1536995620');
INSERT INTO `xt_action_log` VALUES ('2420', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536995660', '1536995660');
INSERT INTO `xt_action_log` VALUES ('2421', '1', '100000', '192.168.0.122', '新增', '新增配置，name：task_specification', '/j8830/public/admin/config/configadd.html', '1', '1536995754', '1536995754');
INSERT INTO `xt_action_log` VALUES ('2422', '1', '100000', '192.168.0.122', '编辑', '编辑配置，name：task', '/j8830/public/admin/config/configedit.html', '1', '1536995791', '1536995791');
INSERT INTO `xt_action_log` VALUES ('2423', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536995827', '1536995827');
INSERT INTO `xt_action_log` VALUES ('2424', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536995847', '1536995847');
INSERT INTO `xt_action_log` VALUES ('2425', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1536996136', '1536996136');
INSERT INTO `xt_action_log` VALUES ('2426', '1', '100000', '192.168.0.122', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1536997050', '1536997050');
INSERT INTO `xt_action_log` VALUES ('2427', '1', '100000', '192.168.0.144', '登录', '登录操作，username：100000', '/j8830/public/admin/login/loginhandle.html', '1', '1537004917', '1537004917');
INSERT INTO `xt_action_log` VALUES ('2428', '1', '100000', '192.168.0.122', '设置', '系统设置保存', '/j8830/public/admin/config/setting.html', '1', '1537014006', '1537014006');
INSERT INTO `xt_action_log` VALUES ('2429', '1', '100000', '192.168.0.110', '登录', '登录操作，username：100000', '/epock/public/admin/login/loginhandle.html', '1', '1537871392', '1537871392');
INSERT INTO `xt_action_log` VALUES ('2430', '1', '100000', '192.168.0.110', '编辑', '编辑菜单，name：后台管理', '/epock/public/admin/menu/menuedit.html', '1', '1537879226', '1537879226');
INSERT INTO `xt_action_log` VALUES ('2431', '1', '100000', '192.168.0.110', '编辑', '编辑菜单，name：菜单管理', '/epock/public/admin/menu/menuedit.html', '1', '1537879243', '1537879243');
INSERT INTO `xt_action_log` VALUES ('2432', '1', '100000', '192.168.0.110', '编辑', '编辑菜单，name：优化维护', '/epock/public/admin/menu/menuedit.html', '1', '1537879280', '1537879280');
INSERT INTO `xt_action_log` VALUES ('2433', '1', '100000', '192.168.0.110', '数据状态', '数据状态调整，model：Config，ids：102,101,87,91,90,84,83,100,86,82，status：0', '/epock/public/admin/config/setstatus.html', '1', '1537879610', '1537879610');
INSERT INTO `xt_action_log` VALUES ('2434', '1', '100000', '192.168.0.110', '数据状态', '数据状态调整，model：Config，ids：71,85,89,88,94,95,98,97，status：0', '/epock/public/admin/config/setstatus.html', '1', '1537879624', '1537879624');
INSERT INTO `xt_action_log` VALUES ('2435', '1', '100000', '192.168.0.110', '数据状态', '数据状态调整，model：Config，ids：102,101,99,87,75,73,69,68,65,61，status：1', '/epock/public/admin/config/setstatus.html', '1', '1537879642', '1537879642');
INSERT INTO `xt_action_log` VALUES ('2436', '1', '100000', '192.168.0.110', '数据状态', '数据状态调整，model：Config，ids：102,101,87,91,90,84,83,100,86,82，status：1', '/epock/public/admin/config/setstatus.html', '1', '1537879654', '1537879654');
INSERT INTO `xt_action_log` VALUES ('2437', '1', '100000', '192.168.0.110', '数据状态', '数据状态调整，model：Config，ids：71,85,89,88,94,95,98,97，status：1', '/epock/public/admin/config/setstatus.html', '1', '1537879664', '1537879664');
INSERT INTO `xt_action_log` VALUES ('2438', '1', '100000', '192.168.0.110', '编辑', '编辑配置，name：config_group_list', '/epock/public/admin/config/configedit.html', '1', '1537879886', '1537879886');
INSERT INTO `xt_action_log` VALUES ('2439', '1', '100000', '192.168.0.110', '编辑', '编辑配置，name：config_group_list', '/epock/public/admin/config/configedit.html', '1', '1537879944', '1537879944');
INSERT INTO `xt_action_log` VALUES ('2440', '1', '100000', '192.168.0.110', '编辑', '编辑配置，name：config_group_list', '/epock/public/admin/config/configedit.html', '1', '1537879981', '1537879981');
INSERT INTO `xt_action_log` VALUES ('2441', '1', '100000', '192.168.0.110', '编辑', '编辑配置，name：config_group_list', '/epock/public/admin/config/configedit.html', '1', '1537880156', '1537880156');
INSERT INTO `xt_action_log` VALUES ('2442', '1', '100000', '192.168.0.110', '编辑', '编辑配置，name：config_group_list', '/epock/public/admin/config/configedit.html', '1', '1537881536', '1537881536');
INSERT INTO `xt_action_log` VALUES ('2443', '1', '100000', '192.168.0.110', '编辑', '编辑配置，name：config_group_list', '/epock/public/admin/config/configedit.html', '1', '1537881576', '1537881576');
INSERT INTO `xt_action_log` VALUES ('2444', '1', '100000', '192.168.0.110', '编辑', '编辑配置，name：config_group_list', '/epock/public/admin/config/configedit.html', '1', '1537881616', '1537881616');
INSERT INTO `xt_action_log` VALUES ('2445', '1', '100000', '192.168.0.110', '编辑', '编辑配置，name：config_group_list', '/epock/public/admin/config/configedit.html', '1', '1537881651', '1537881651');
INSERT INTO `xt_action_log` VALUES ('2446', '1', '100000', '192.168.0.110', '编辑', '编辑配置，name：config_group_list', '/epock/public/admin/config/configedit.html', '1', '1537881672', '1537881672');
INSERT INTO `xt_action_log` VALUES ('2447', '1', '100000', '192.168.0.110', '编辑', '编辑配置，name：config_group_list', '/epock/public/admin/config/configedit.html', '1', '1537881692', '1537881692');
INSERT INTO `xt_action_log` VALUES ('2448', '1', '100000', '192.168.0.110', '编辑', '编辑配置，name：config_group_list', '/epock/public/admin/config/configedit.html', '1', '1537881715', '1537881715');
INSERT INTO `xt_action_log` VALUES ('2449', '1', '100000', '192.168.0.110', '编辑', '编辑配置，name：config_group_list', '/epock/public/admin/config/configedit.html', '1', '1537881733', '1537881733');
INSERT INTO `xt_action_log` VALUES ('2450', '1', '100000', '192.168.0.110', '编辑', '编辑配置，name：config_group_list', '/epock/public/admin/config/configedit.html', '1', '1537881751', '1537881751');
INSERT INTO `xt_action_log` VALUES ('2451', '1', '100000', '192.168.0.110', '编辑', '编辑配置，name：config_group_list', '/epock/public/admin/config/configedit.html', '1', '1537881788', '1537881788');
INSERT INTO `xt_action_log` VALUES ('2452', '1', '100000', '192.168.0.110', '设置', '系统设置保存', '/epock/public/admin/config/setting.html', '1', '1537881844', '1537881844');
INSERT INTO `xt_action_log` VALUES ('2453', '1', '100000', '192.168.0.110', '设置', '系统设置保存', '/epock/public/admin/config/setting.html', '1', '1537881856', '1537881856');
INSERT INTO `xt_action_log` VALUES ('2454', '1', '100000', '192.168.0.110', '设置', '系统设置保存', '/epock/public/admin/config/setting.html', '1', '1537881867', '1537881867');
INSERT INTO `xt_action_log` VALUES ('2455', '1', '100000', '192.168.0.110', '编辑', 'SEO编辑，name：首页SEO信息', '/epock/public/admin/seo/seoedit.html', '1', '1537881934', '1537881934');
INSERT INTO `xt_action_log` VALUES ('2456', '1', '100000', '192.168.0.110', '编辑', 'SEO编辑，name：善策', '/epock/public/admin/seo/seoedit.html', '1', '1537881952', '1537881952');
INSERT INTO `xt_action_log` VALUES ('2457', '1', '100000', '192.168.0.110', '编辑', '产品编辑，name：案例-Fasterfx 打造全球领先的金融互动', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537883317', '1537883317');
INSERT INTO `xt_action_log` VALUES ('2458', '1', '100000', '192.168.0.110', '编辑', '产品编辑，name：案例-Fasterfx 打造全球领先的金融互动', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537883378', '1537883378');
INSERT INTO `xt_action_log` VALUES ('2459', '1', '100000', '192.168.0.110', '编辑', '分类编辑，name：数字化转型', '/epock/public/admin/shopadmin/shopcategoryedit.html', '1', '1537883390', '1537883390');
INSERT INTO `xt_action_log` VALUES ('2460', '1', '100000', '192.168.0.110', '新增', '产品新增，name：asdasd', '/epock/public/admin/shopadmin/shopadd.html', '1', '1537884289', '1537884289');
INSERT INTO `xt_action_log` VALUES ('2461', '1', '100000', '192.168.0.110', '数据状态', '数据状态调整，model：Shop，ids：55，status：-1', '/epock/public/admin/shopadmin/setstatus/ids/55/status/-1.html', '1', '1537884378', '1537884378');
INSERT INTO `xt_action_log` VALUES ('2462', '1', '100000', '192.168.0.110', '新增', '产品新增，name：区块链AI智能交易系统', '/epock/public/admin/shopadmin/shopadd.html', '1', '1537884430', '1537884430');
INSERT INTO `xt_action_log` VALUES ('2463', '1', '100000', '192.168.0.109', '登录', '登录操作，username：100000', '/epock/public/admin/login/loginhandle.html', '1', '1537924965', '1537924965');
INSERT INTO `xt_action_log` VALUES ('2464', '1', '100000', '192.168.0.109', '编辑', '产品编辑，name：区块链AI智能交易系统', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537924992', '1537924992');
INSERT INTO `xt_action_log` VALUES ('2465', '1', '100000', '192.168.0.109', '编辑', '产品编辑，name：案例-Fasterfx 打造全球领先的金融互动', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537925003', '1537925003');
INSERT INTO `xt_action_log` VALUES ('2466', '1', '100000', '192.168.0.109', '编辑', '产品编辑，name：区块链AI智能交易系统', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537928092', '1537928092');
INSERT INTO `xt_action_log` VALUES ('2467', '1', '100000', '192.168.0.109', '编辑', '产品编辑，name：区块链AI智能交易系统', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537928633', '1537928633');
INSERT INTO `xt_action_log` VALUES ('2468', '1', '100000', '192.168.0.109', '编辑', '产品编辑，name：区块链AI智能交易系统', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537928718', '1537928718');
INSERT INTO `xt_action_log` VALUES ('2469', '1', '100000', '192.168.0.109', '编辑', '产品编辑，name：案例-Fasterfx 打造全球领先的金融互动', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537928980', '1537928980');
INSERT INTO `xt_action_log` VALUES ('2470', '1', '100000', '192.168.0.109', '编辑', '产品编辑，name：案例-Fasterfx 打造全球领先的金融互动', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537929032', '1537929032');
INSERT INTO `xt_action_log` VALUES ('2471', '1', '100000', '192.168.0.109', '新增', '产品新增，name：系统系统系统', '/epock/public/admin/shopadmin/shopadd.html', '1', '1537930821', '1537930821');
INSERT INTO `xt_action_log` VALUES ('2472', '1', '100000', '192.168.0.109', '新增', '产品新增，name：系统系统系统', '/epock/public/admin/shopadmin/shopadd.html', '1', '1537930840', '1537930840');
INSERT INTO `xt_action_log` VALUES ('2473', '1', '100000', '192.168.0.109', '新增', '产品新增，name：系统系统系统', '/epock/public/admin/shopadmin/shopadd.html', '1', '1537930856', '1537930856');
INSERT INTO `xt_action_log` VALUES ('2474', '1', '100000', '192.168.0.109', '新增', '产品新增，name：系统系统系统', '/epock/public/admin/shopadmin/shopadd.html', '1', '1537930876', '1537930876');
INSERT INTO `xt_action_log` VALUES ('2475', '1', '100000', '192.168.0.109', '新增', '产品新增，name：系统系统系统', '/epock/public/admin/shopadmin/shopadd.html', '1', '1537930893', '1537930893');
INSERT INTO `xt_action_log` VALUES ('2476', '1', '100000', '192.168.0.105', '登录', '登录操作，username：100000', '/epock/public/admin/login/loginhandle.html', '1', '1537931529', '1537931529');
INSERT INTO `xt_action_log` VALUES ('2477', '1', '100000', '192.168.0.105', '编辑', '产品编辑，name：系统系统系统', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537931622', '1537931622');
INSERT INTO `xt_action_log` VALUES ('2478', '1', '100000', '192.168.0.105', '编辑', '产品编辑，name：系统系统系统', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537931651', '1537931651');
INSERT INTO `xt_action_log` VALUES ('2479', '1', '100000', '192.168.0.105', '编辑', '产品编辑，name：系统系统系统', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537931679', '1537931679');
INSERT INTO `xt_action_log` VALUES ('2480', '1', '100000', '192.168.0.105', '编辑', '产品编辑，name：系统系统系统', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537931694', '1537931694');
INSERT INTO `xt_action_log` VALUES ('2481', '1', '100000', '192.168.0.105', '编辑', '产品编辑，name：系统系统系统', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537931719', '1537931719');
INSERT INTO `xt_action_log` VALUES ('2482', '1', '100000', '192.168.0.105', '编辑', '产品编辑，name：系统系统系统', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537931826', '1537931826');
INSERT INTO `xt_action_log` VALUES ('2483', '1', '100000', '192.168.0.105', '编辑', '产品编辑，name：系统系统系统', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537931969', '1537931969');
INSERT INTO `xt_action_log` VALUES ('2484', '1', '100000', '192.168.0.105', '编辑', '产品编辑，name：系统系统系统', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537932031', '1537932031');
INSERT INTO `xt_action_log` VALUES ('2485', '1', '100000', '192.168.0.105', '编辑', '产品编辑，name：系统系统系统', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537932087', '1537932087');
INSERT INTO `xt_action_log` VALUES ('2486', '1', '100000', '192.168.0.105', '编辑', '产品编辑，name：系统系统系统', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537932124', '1537932124');
INSERT INTO `xt_action_log` VALUES ('2487', '1', '100000', '192.168.0.105', '编辑', '产品编辑，name：系统系统系统', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537932150', '1537932150');
INSERT INTO `xt_action_log` VALUES ('2488', '1', '100000', '192.168.0.105', '编辑', '产品编辑，name：系统系统', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537932172', '1537932172');
INSERT INTO `xt_action_log` VALUES ('2489', '1', '100000', '192.168.0.105', '编辑', '产品编辑，name：系统系统', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537932205', '1537932205');
INSERT INTO `xt_action_log` VALUES ('2490', '1', '100000', '192.168.0.105', '新增', '产品新增，name：rter ', '/epock/public/admin/shopadmin/shopadd.html', '1', '1537932325', '1537932325');
INSERT INTO `xt_action_log` VALUES ('2491', '1', '100000', '192.168.0.105', '编辑', '产品编辑，name：rter', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537932333', '1537932333');
INSERT INTO `xt_action_log` VALUES ('2492', '1', '100000', '192.168.0.105', '编辑', '产品编辑，name：rter', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537932456', '1537932456');
INSERT INTO `xt_action_log` VALUES ('2493', '1', '100000', '192.168.0.105', '编辑', '产品编辑，name：rter', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537932488', '1537932488');
INSERT INTO `xt_action_log` VALUES ('2494', '1', '100000', '192.168.0.109', '编辑', '产品编辑，name：区块链AI智能交易系统', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537932726', '1537932726');
INSERT INTO `xt_action_log` VALUES ('2495', '1', '100000', '192.168.0.109', '编辑', '产品编辑，name：区块链AI智能交易系统', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537932802', '1537932802');
INSERT INTO `xt_action_log` VALUES ('2496', '1', '100000', '192.168.0.105', '编辑', '产品编辑，name：rter', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537932878', '1537932878');
INSERT INTO `xt_action_log` VALUES ('2497', '1', '100000', '192.168.0.109', '编辑', '产品编辑，name：rter', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537933608', '1537933608');
INSERT INTO `xt_action_log` VALUES ('2498', '1', '100000', '192.168.0.109', '编辑', '产品编辑，name：rter', '/epock/public/admin/shopadmin/shopedit.html', '1', '1537933647', '1537933647');
INSERT INTO `xt_action_log` VALUES ('2499', '1', '100000', '113.87.130.222', '登录', '登录操作，username：100000', '/admin/login/loginhandle.html', '1', '1537958450', '1537958450');
INSERT INTO `xt_action_log` VALUES ('2500', '1', '100000', '113.87.130.222', '登录', '登录操作，username：100000', '/admin/login/loginhandle.html', '1', '1537958475', '1537958475');
INSERT INTO `xt_action_log` VALUES ('2501', '1', '100000', '113.87.130.222', '登录', '登录操作，username：100000', '/admin/login/loginhandle.html', '1', '1537967585', '1537967585');
INSERT INTO `xt_action_log` VALUES ('2502', '1', '100000', '113.87.130.222', '登录', '登录操作，username：100000', '/admin/login/loginhandle.html', '1', '1537967791', '1537967791');
INSERT INTO `xt_action_log` VALUES ('2503', '1', '100000', '113.87.130.222', '编辑', '编辑菜单，name：会员管理', '/admin/menu/menuedit.html', '1', '1537967828', '1537967828');
INSERT INTO `xt_action_log` VALUES ('2504', '1', '100000', '113.87.130.222', '编辑', '编辑菜单，name：货币流向', '/admin/menu/menuedit.html', '1', '1537967840', '1537967840');
INSERT INTO `xt_action_log` VALUES ('2505', '1', '100000', '113.87.130.222', '登录', '登录操作，username：100000', '/admin/login/loginhandle.html', '1', '1537967892', '1537967892');
INSERT INTO `xt_action_log` VALUES ('2506', '1', '100000', '101.233.97.71', '登录', '登录操作，username：100000', '/admin/login/loginhandle.html', '1', '1537967998', '1537967998');
INSERT INTO `xt_action_log` VALUES ('2507', '1', '100000', '113.87.130.222', '编辑', '编辑菜单，name：邮箱', '/admin/menu/menuedit.html', '1', '1537969036', '1537969036');
INSERT INTO `xt_action_log` VALUES ('2508', '1', '100000', '113.87.130.222', '编辑', '编辑菜单，name：邮箱', '/admin/menu/menuedit.html', '1', '1537969054', '1537969054');
INSERT INTO `xt_action_log` VALUES ('2509', '1', '100000', '113.87.130.222', '登录', '登录操作，username：100000', '/admin/login/loginhandle.html', '1', '1537970938', '1537970938');
INSERT INTO `xt_action_log` VALUES ('2510', '1', '100000', '113.87.130.222', '编辑', '产品编辑，name：rter', '/admin/shopadmin/shopedit.html', '1', '1537971768', '1537971768');
INSERT INTO `xt_action_log` VALUES ('2511', '1', '100000', '113.87.130.222', '编辑', '产品编辑，name：金融交易系统外汇跟单搭建', '/admin/shopadmin/shopedit.html', '1', '1537971793', '1537971793');
INSERT INTO `xt_action_log` VALUES ('2512', '1', '100000', '113.87.130.222', '编辑', '产品编辑，name：系统系统', '/admin/shopadmin/shopedit.html', '1', '1537971884', '1537971884');
INSERT INTO `xt_action_log` VALUES ('2513', '1', '100000', '113.87.130.222', '编辑', '产品编辑，name：中国智能果园 新农', '/admin/shopadmin/shopedit.html', '1', '1537971938', '1537971938');
INSERT INTO `xt_action_log` VALUES ('2514', '1', '100000', '192.168.0.104', '登录', '登录操作，username：100000', '/company/public/admin/login/loginhandle.html', '1', '1538017825', '1538017825');
INSERT INTO `xt_action_log` VALUES ('2515', '1', '100000', '192.168.0.104', '编辑', '编辑菜单，name：货币流向', '/company/public/admin/menu/menuedit.html', '1', '1538017852', '1538017852');
INSERT INTO `xt_action_log` VALUES ('2516', '1', '100000', '192.168.0.104', '编辑', '编辑配置，name：type_name', '/company/public/admin/config/configedit.html', '1', '1538019504', '1538019504');
INSERT INTO `xt_action_log` VALUES ('2517', '1', '100000', '192.168.0.104', '编辑', '编辑菜单，name：发件箱', '/epock/public/admin/menu/menuedit.html', '1', '1538027444', '1538027444');
INSERT INTO `xt_action_log` VALUES ('2518', '1', '100000', '192.168.0.104', '编辑', '编辑菜单，name：写邮件', '/epock/public/admin/menu/menuedit.html', '1', '1538027451', '1538027451');
INSERT INTO `xt_action_log` VALUES ('2519', '1', '100000', '192.168.0.104', '编辑', '编辑菜单，name：网页留言', '/epock/public/admin/menu/menuedit.html', '1', '1538027479', '1538027479');
INSERT INTO `xt_action_log` VALUES ('2520', '1', '100000', '119.123.72.168', '登录', '登录操作，username：100000', '/admin/login/loginhandle.html', '1', '1538982655', '1538982655');
INSERT INTO `xt_action_log` VALUES ('2521', '1', '100000', '183.13.191.15', '登录', '登录操作，username：100000', '/admin/login/loginhandle.html', '1', '1538983596', '1538983596');
INSERT INTO `xt_action_log` VALUES ('2522', '1', '100000', '183.13.191.15', '编辑', '产品编辑，name：金融交易系统外汇跟单搭建', '/admin/shopadmin/shopedit.html', '1', '1538983682', '1538983682');
INSERT INTO `xt_action_log` VALUES ('2523', '1', '100000', '183.13.191.15', '编辑', '产品编辑，name：金融交易系统外汇跟单搭建', '/admin/shopadmin/shopedit.html', '1', '1538983820', '1538983820');
INSERT INTO `xt_action_log` VALUES ('2524', '1', '100000', '119.123.72.168', '编辑', '产品编辑，name：金融交易系统外汇跟单搭建', '/admin/shopadmin/shopedit.html', '1', '1538984171', '1538984171');
INSERT INTO `xt_action_log` VALUES ('2525', '1', '100000', '119.123.72.168', '登录', '登录操作，username：100000', '/admin/login/loginhandle.html', '1', '1538984284', '1538984284');
INSERT INTO `xt_action_log` VALUES ('2526', '1', '100000', '119.123.72.168', '数据状态', '数据状态调整，model：Config，ids：102,101,99,87，status：-1', '/admin/config/setstatus.html', '1', '1538984780', '1538984780');
INSERT INTO `xt_action_log` VALUES ('2527', '1', '100000', '119.123.72.168', '数据状态', '数据状态调整，model：Config，ids：90,84,83,100,86,89，status：-1', '/admin/config/setstatus.html', '1', '1538984821', '1538984821');
INSERT INTO `xt_action_log` VALUES ('2528', '1', '100000', '119.123.72.168', '数据状态', '数据状态调整，model：Config，ids：91,82,71,85,88,94,95,98,97，status：-1', '/admin/config/setstatus.html', '1', '1538984869', '1538984869');
INSERT INTO `xt_action_log` VALUES ('2529', '1', '100000', '119.123.72.168', '新增', '新增配置，name：banner1', '/admin/config/configadd.html', '1', '1538989237', '1538989237');
INSERT INTO `xt_action_log` VALUES ('2530', '1', '100000', '119.123.72.168', '新增', '新增配置，name：banner2', '/admin/config/configadd.html', '1', '1538989256', '1538989256');
INSERT INTO `xt_action_log` VALUES ('2531', '1', '100000', '119.123.72.168', '编辑', '编辑配置，name：banner2', '/admin/config/configedit.html', '1', '1538989263', '1538989263');
INSERT INTO `xt_action_log` VALUES ('2532', '1', '100000', '119.123.72.168', '新增', '新增配置，name：banner3', '/admin/config/configadd.html', '1', '1538989300', '1538989300');
INSERT INTO `xt_action_log` VALUES ('2533', '1', '100000', '119.123.72.168', '设置', '系统设置保存', '/admin/config/setting.html', '1', '1538989381', '1538989381');
INSERT INTO `xt_action_log` VALUES ('2534', '1', '100000', '127.0.0.1', '登录', '登录操作，username：100000', '/epock/public/admin/login/loginhandle.html', '1', '1538993239', '1538993239');
INSERT INTO `xt_action_log` VALUES ('2535', '1', '100000', '127.0.0.1', '编辑', '产品编辑，name：金融交易系统外汇跟单搭建', '/epock/public/admin/shopadmin/shopedit.html', '1', '1538997596', '1538997596');
INSERT INTO `xt_action_log` VALUES ('2536', '1', '100000', '127.0.0.1', '编辑', '产品编辑，name：金融交易系统外汇跟单搭建', '/epock/public/admin/shopadmin/shopedit.html', '1', '1538997986', '1538997986');
INSERT INTO `xt_action_log` VALUES ('2537', '1', '100000', '127.0.0.1', '编辑', '产品编辑，name：区块链AI智能交易系统', '/epock/public/admin/shopadmin/shopedit.html', '1', '1538998903', '1538998903');
INSERT INTO `xt_action_log` VALUES ('2538', '1', '100000', '127.0.0.1', '编辑', '产品编辑，name：区块链AI智能交易系统', '/epock/public/admin/shopadmin/shopedit.html', '1', '1538998971', '1538998971');
INSERT INTO `xt_action_log` VALUES ('2539', '1', '100000', '127.0.0.1', '编辑', '产品编辑，name：案例-Fasterfx 打造全球领先的金融互动', '/epock/public/admin/shopadmin/shopedit.html', '1', '1538999466', '1538999466');
INSERT INTO `xt_action_log` VALUES ('2540', '1', '100000', '127.0.0.1', '编辑', '产品编辑，name：区块链AI智能交易系统66', '/epock/public/admin/shopadmin/shopedit.html', '1', '1538999578', '1538999578');
INSERT INTO `xt_action_log` VALUES ('2541', '1', '100000', '127.0.0.1', '编辑', '产品编辑，name：区块链AI智能交易系统66', '/epock/public/admin/shopadmin/shopedit.html', '1', '1538999690', '1538999690');
INSERT INTO `xt_action_log` VALUES ('2542', '1', '100000', '127.0.0.1', '编辑', '产品编辑，name：区块链AI智能交易系统', '/epock/public/admin/shopadmin/shopedit.html', '1', '1539000484', '1539000484');
INSERT INTO `xt_action_log` VALUES ('2543', '1', '100000', '127.0.0.1', '编辑', '产品编辑，name：区块链AI智能交易系统', '/epock/public/admin/shopadmin/shopedit.html', '1', '1539000529', '1539000529');
INSERT INTO `xt_action_log` VALUES ('2544', '1', '100000', '127.0.0.1', '编辑', '产品编辑，name：区块链AI智能交易系统', '/epock/public/admin/shopadmin/shopedit.html', '1', '1539000643', '1539000643');
INSERT INTO `xt_action_log` VALUES ('2545', '1', '100000', '127.0.0.1', '编辑', '产品编辑，name：区块链AI智能交易系统', '/epock/public/admin/shopadmin/shopedit.html', '1', '1539000693', '1539000693');
INSERT INTO `xt_action_log` VALUES ('2546', '1', '100000', '119.123.72.168', '编辑', '产品编辑，name：区块链AI智能交易系统', '/admin/shopadmin/shopedit.html', '1', '1539001663', '1539001663');
INSERT INTO `xt_action_log` VALUES ('2547', '1', '100000', '119.123.72.168', '设置', '系统设置保存', '/admin/config/setting.html', '1', '1539001775', '1539001775');
INSERT INTO `xt_action_log` VALUES ('2548', '1', '100000', '119.123.72.168', '设置', '系统设置保存', '/admin/config/setting.html', '1', '1539001800', '1539001800');
INSERT INTO `xt_action_log` VALUES ('2549', '1', '100000', '119.123.72.168', '设置', '系统设置保存', '/admin/config/setting.html', '1', '1539001813', '1539001813');
INSERT INTO `xt_action_log` VALUES ('2550', '1', '100000', '119.123.72.168', '设置', '系统设置保存', '/admin/config/setting.html', '1', '1539001846', '1539001846');
INSERT INTO `xt_action_log` VALUES ('2551', '1', '100000', '119.123.72.168', '设置', '系统设置保存', '/admin/config/setting.html', '1', '1539001858', '1539001858');

-- -----------------------------
-- Table structure for `xt_addon`
-- -----------------------------
DROP TABLE IF EXISTS `xt_addon`;
CREATE TABLE `xt_addon` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名称',
  `describe` varchar(255) NOT NULL DEFAULT '' COMMENT '插件描述',
  `config` text NOT NULL COMMENT '配置',
  `author` varchar(40) NOT NULL DEFAULT '' COMMENT '作者',
  `version` varchar(20) NOT NULL DEFAULT '' COMMENT '版本号',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `xt_addon`
-- -----------------------------
INSERT INTO `xt_addon` VALUES ('3', 'File', '文件上传', '文件上传插件', '', 'Jack', '1.0', '1', '0', '0');
INSERT INTO `xt_addon` VALUES ('4', 'Icon', '图标选择', '图标选择插件', '', 'Bigotry', '1.0', '1', '0', '0');
INSERT INTO `xt_addon` VALUES ('5', 'Editor', '文本编辑器', '富文本编辑器', '', 'Bigotry', '1.0', '1', '0', '0');

-- -----------------------------
-- Table structure for `xt_address`
-- -----------------------------
DROP TABLE IF EXISTS `xt_address`;
CREATE TABLE `xt_address` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `consignee_name` varchar(100) NOT NULL COMMENT '收货人',
  `province` varchar(100) NOT NULL COMMENT '省',
  `city` varchar(100) NOT NULL COMMENT '市',
  `county` varchar(100) DEFAULT NULL COMMENT '县/区',
  `address` text NOT NULL COMMENT '详细地址',
  `mobile` varchar(11) NOT NULL COMMENT '联系电话',
  `status` int(10) NOT NULL DEFAULT '1' COMMENT '1-正常 -1-已删除',
  `default` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否为默认收货地址1-是 0-否',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `xt_api`
-- -----------------------------
DROP TABLE IF EXISTS `xt_api`;
CREATE TABLE `xt_api` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(150) NOT NULL DEFAULT '' COMMENT '接口名称',
  `group_id` int(6) unsigned NOT NULL DEFAULT '0' COMMENT '接口分组',
  `request_type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '请求类型 0:POST  1:GET',
  `api_url` char(50) NOT NULL DEFAULT '' COMMENT '请求路径',
  `describe` varchar(255) NOT NULL DEFAULT '' COMMENT '接口描述',
  `describe_text` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT '接口富文本描述',
  `is_request_data` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否需要请求数据',
  `request_data` text NOT NULL COMMENT '请求数据',
  `response_data` text NOT NULL COMMENT '响应数据',
  `is_response_data` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否需要响应数据',
  `is_user_token` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否需要用户token',
  `is_response_sign` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否返回数据签名',
  `is_request_sign` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否验证请求数据签名',
  `response_examples` text NOT NULL COMMENT '响应栗子',
  `developer` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '研发者',
  `api_status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '接口状态（0:待研发，1:研发中，2:测试中，3:已完成）',
  `is_page` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否为分页接口 0：否  1：是',
  `sort` tinyint(5) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=192 DEFAULT CHARSET=utf8 COMMENT='API表';

-- -----------------------------
-- Records of `xt_api`
-- -----------------------------
INSERT INTO `xt_api` VALUES ('186', '登录或注册', '34', '0', 'common/login', '系统登录注册接口，若用户名存在则验证密码正确性，若用户名不存在则注册新用户，返回 user_token 用于操作需验证身份的接口', '', '1', '[{\"field_name\":\"username\",\"data_type\":\"0\",\"is_require\":\"1\",\"field_describe\":\"\\u7528\\u6237\\u540d\"},{\"field_name\":\"password\",\"data_type\":\"0\",\"is_require\":\"1\",\"field_describe\":\"\\u5bc6\\u7801\"}]', '[{\"field_name\":\"data\",\"data_type\":\"2\",\"field_describe\":\"\\u4f1a\\u5458\\u6570\\u636e\\u53causer_token\"}]', '1', '0', '1', '0', '{\r\n    &quot;code&quot;: 0,\r\n    &quot;msg&quot;: &quot;操作成功&quot;,\r\n    &quot;data&quot;: {\r\n        &quot;member_id&quot;: 51,\r\n        &quot;nickname&quot;: &quot;sadasdas&quot;,\r\n        &quot;username&quot;: &quot;sadasdas&quot;,\r\n        &quot;create_time&quot;: &quot;2017-09-09 13:40:17&quot;,\r\n        &quot;user_token&quot;: &quot;eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJPbmVCYXNlIEpXVCIsImlhdCI6MTUwNDkzNTYxNywiZXhwIjoxNTA0OTM2NjE3LCJhdWQiOiJPbmVCYXNlIiwic3ViIjoiT25lQmFzZSIsImRhdGEiOnsibWVtYmVyX2lkIjo1MSwibmlja25hbWUiOiJzYWRhc2RhcyIsInVzZXJuYW1lIjoic2FkYXNkYXMiLCJjcmVhdGVfdGltZSI6IjIwMTctMDktMDkgMTM6NDA6MTcifX0.6PEShODuifNsa-x1TumLoEaR2TCXpUEYgjpD3Mz3GRM&quot;\r\n    }\r\n}', '0', '1', '0', '0', '1', '1504501410', '1520504982');
INSERT INTO `xt_api` VALUES ('187', '文章分类列表', '44', '0', 'article/categorylist', '文章分类列表接口', '', '0', '', '[{\"field_name\":\"id\",\"data_type\":\"0\",\"field_describe\":\"\\u6587\\u7ae0\\u5206\\u7c7bID\"},{\"field_name\":\"name\",\"data_type\":\"0\",\"field_describe\":\"\\u6587\\u7ae0\\u5206\\u7c7b\\u540d\\u79f0\"}]', '1', '0', '0', '0', '{\r\n    &quot;code&quot;: 0,\r\n    &quot;msg&quot;: &quot;操作成功&quot;,\r\n    &quot;data&quot;: [\r\n        {\r\n            &quot;id&quot;: 2,\r\n            &quot;name&quot;: &quot;测试文章分类2&quot;\r\n        },\r\n        {\r\n            &quot;id&quot;: 1,\r\n            &quot;name&quot;: &quot;测试文章分类1&quot;\r\n        }\r\n    ]\r\n}', '0', '0', '0', '2', '1', '1504765581', '1520504982');
INSERT INTO `xt_api` VALUES ('188', '文章列表', '44', '0', 'article/articlelist', '文章列表接口', '', '1', '[{\"field_name\":\"category_id\",\"data_type\":\"0\",\"is_require\":\"0\",\"field_describe\":\"\\u82e5\\u4e0d\\u4f20\\u9012\\u6b64\\u53c2\\u6570\\u5219\\u4e3a\\u6240\\u6709\\u5206\\u7c7b\"}]', '', '0', '0', '0', '0', '{\r\n    &quot;code&quot;: 0,\r\n    &quot;msg&quot;: &quot;操作成功&quot;,\r\n    &quot;data&quot;: {\r\n        &quot;total&quot;: 9,\r\n        &quot;per_page&quot;: &quot;10&quot;,\r\n        &quot;current_page&quot;: 1,\r\n        &quot;last_page&quot;: 1,\r\n        &quot;data&quot;: [\r\n            {\r\n                &quot;id&quot;: 16,\r\n                &quot;name&quot;: &quot;11111111&quot;,\r\n                &quot;category_id&quot;: 2,\r\n                &quot;describe&quot;: &quot;22222222&quot;,\r\n                &quot;create_time&quot;: &quot;2017-08-07 13:58:37&quot;\r\n            },\r\n            {\r\n                &quot;id&quot;: 15,\r\n                &quot;name&quot;: &quot;tttttt&quot;,\r\n                &quot;category_id&quot;: 1,\r\n                &quot;describe&quot;: &quot;sddd&quot;,\r\n                &quot;create_time&quot;: &quot;2017-08-07 13:24:46&quot;\r\n            }\r\n        ]\r\n    }\r\n}', '0', '0', '1', '1', '1', '1504779780', '1520504982');
INSERT INTO `xt_api` VALUES ('189', '首页接口', '45', '0', 'combination/index', '首页聚合接口', '', '1', '[{\"field_name\":\"category_id\",\"data_type\":\"0\",\"is_require\":\"0\",\"field_describe\":\"\\u6587\\u7ae0\\u5206\\u7c7bID\"}]', '[{\"field_name\":\"article_category_list\",\"data_type\":\"2\",\"field_describe\":\"\\u6587\\u7ae0\\u5206\\u7c7b\\u6570\\u636e\"},{\"field_name\":\"article_list\",\"data_type\":\"2\",\"field_describe\":\"\\u6587\\u7ae0\\u6570\\u636e\"}]', '1', '0', '1', '0', '{\r\n    &quot;code&quot;: 0,\r\n    &quot;msg&quot;: &quot;操作成功&quot;,\r\n    &quot;data&quot;: {\r\n        &quot;article_category_list&quot;: [\r\n            {\r\n                &quot;id&quot;: 2,\r\n                &quot;name&quot;: &quot;测试文章分类2&quot;\r\n            },\r\n            {\r\n                &quot;id&quot;: 1,\r\n                &quot;name&quot;: &quot;测试文章分类1&quot;\r\n            }\r\n        ],\r\n        &quot;article_list&quot;: {\r\n            &quot;total&quot;: 8,\r\n            &quot;per_page&quot;: &quot;2&quot;,\r\n            &quot;current_page&quot;: &quot;1&quot;,\r\n            &quot;last_page&quot;: 4,\r\n            &quot;data&quot;: [\r\n                {\r\n                    &quot;id&quot;: 15,\r\n                    &quot;name&quot;: &quot;tttttt&quot;,\r\n                    &quot;category_id&quot;: 1,\r\n                    &quot;describe&quot;: &quot;sddd&quot;,\r\n                    &quot;create_time&quot;: &quot;2017-08-07 13:24:46&quot;\r\n                },\r\n                {\r\n                    &quot;id&quot;: 14,\r\n                    &quot;name&quot;: &quot;1111111111111111111&quot;,\r\n                    &quot;category_id&quot;: 1,\r\n                    &quot;describe&quot;: &quot;123123&quot;,\r\n                    &quot;create_time&quot;: &quot;2017-08-04 15:37:20&quot;\r\n                }\r\n            ]\r\n        }\r\n    }\r\n}', '0', '0', '1', '0', '1', '1504785072', '1520504982');
INSERT INTO `xt_api` VALUES ('190', '详情页接口', '45', '0', 'combination/details', '详情页接口', '', '1', '[{\"field_name\":\"article_id\",\"data_type\":\"0\",\"is_require\":\"1\",\"field_describe\":\"\\u6587\\u7ae0ID\"}]', '[{\"field_name\":\"article_category_list\",\"data_type\":\"2\",\"field_describe\":\"\\u6587\\u7ae0\\u5206\\u7c7b\\u6570\\u636e\"},{\"field_name\":\"article_details\",\"data_type\":\"2\",\"field_describe\":\"\\u6587\\u7ae0\\u8be6\\u60c5\\u6570\\u636e\"}]', '1', '0', '0', '0', '{\r\n    &quot;code&quot;: 0,\r\n    &quot;msg&quot;: &quot;操作成功&quot;,\r\n    &quot;data&quot;: {\r\n        &quot;article_category_list&quot;: [\r\n            {\r\n                &quot;id&quot;: 2,\r\n                &quot;name&quot;: &quot;测试文章分类2&quot;\r\n            },\r\n            {\r\n                &quot;id&quot;: 1,\r\n                &quot;name&quot;: &quot;测试文章分类1&quot;\r\n            }\r\n        ],\r\n        &quot;article_details&quot;: {\r\n            &quot;id&quot;: 1,\r\n            &quot;name&quot;: &quot;213&quot;,\r\n            &quot;category_id&quot;: 1,\r\n            &quot;describe&quot;: &quot;test001&quot;,\r\n            &quot;content&quot;: &quot;第三方发送到&quot;&quot;&quot;,\r\n            &quot;create_time&quot;: &quot;2014-07-22 11:56:53&quot;\r\n        }\r\n    }\r\n}', '0', '0', '0', '0', '1', '1504922092', '1520504982');
INSERT INTO `xt_api` VALUES ('191', '修改密码', '34', '0', 'common/changepassword', '修改密码接口', '', '1', '[{\"field_name\":\"old_password\",\"data_type\":\"0\",\"is_require\":\"1\",\"field_describe\":\"\\u65e7\\u5bc6\\u7801\"},{\"field_name\":\"new_password\",\"data_type\":\"0\",\"is_require\":\"1\",\"field_describe\":\"\\u65b0\\u5bc6\\u7801\"}]', '', '0', '1', '0', '0', '{\r\n    &quot;code&quot;: 0,\r\n    &quot;msg&quot;: &quot;操作成功&quot;,\r\n    &quot;exe_time&quot;: &quot;0.037002&quot;\r\n}', '0', '0', '0', '0', '1', '1504941496', '1520504982');

-- -----------------------------
-- Table structure for `xt_api_group`
-- -----------------------------
DROP TABLE IF EXISTS `xt_api_group`;
CREATE TABLE `xt_api_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(120) NOT NULL DEFAULT '' COMMENT 'aip分组名称',
  `sort` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=utf8 COMMENT='api分组表';

-- -----------------------------
-- Records of `xt_api_group`
-- -----------------------------
INSERT INTO `xt_api_group` VALUES ('34', '基础接口', '0', '1504501195', '0', '1');
INSERT INTO `xt_api_group` VALUES ('44', '文章接口', '1', '1504765319', '1504765319', '1');
INSERT INTO `xt_api_group` VALUES ('45', '聚合接口', '0', '1504784149', '1504784149', '1');

-- -----------------------------
-- Table structure for `xt_article`
-- -----------------------------
DROP TABLE IF EXISTS `xt_article`;
CREATE TABLE `xt_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文章ID',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '会员id',
  `name` char(40) NOT NULL DEFAULT '' COMMENT '文章名称',
  `category_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文章分类',
  `describe` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `content` text NOT NULL COMMENT '文章内容',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '封面图片id',
  `file_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件id',
  `img_ids` varchar(200) NOT NULL DEFAULT '',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='文章表';

-- -----------------------------
-- Records of `xt_article`
-- -----------------------------
INSERT INTO `xt_article` VALUES ('1', '1', '312312321312', '8', '3213213', '3213123213213试试同为额儿童额恩恩&amp;nbsp;', '0', '0', '', '1535006408', '1536146338', '1');

-- -----------------------------
-- Table structure for `xt_article_category`
-- -----------------------------
DROP TABLE IF EXISTS `xt_article_category`;
CREATE TABLE `xt_article_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '分类名称',
  `describe` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  `icon` char(20) NOT NULL DEFAULT '' COMMENT '分类图标',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='分类表';

-- -----------------------------
-- Records of `xt_article_category`
-- -----------------------------
INSERT INTO `xt_article_category` VALUES ('7', '报单产品', '报单产品', '1509620712', '1536146329', '-1', 'fa-street-view');
INSERT INTO `xt_article_category` VALUES ('8', '后台介绍', '后台功能介绍', '1509792822', '1509792822', '1', 'fa-user');

-- -----------------------------
-- Table structure for `xt_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `xt_auth_group`;
CREATE TABLE `xt_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL DEFAULT '' COMMENT '用户组所属模块',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '用户组名称',
  `describe` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(1000) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='权限组表';

-- -----------------------------
-- Records of `xt_auth_group`
-- -----------------------------
INSERT INTO `xt_auth_group` VALUES ('3', '', '普通会员', '', '1', '1,225,226,227,228,229,232,233,238,231,239,230,234,235,236,237,198,199,210,221', '1', '1536062740', '1536060679');
INSERT INTO `xt_auth_group` VALUES ('4', '', '报单中心', '', '1', '1,225,226,227,228,229,232,233,238,240,231,239,230,234,235,236,237,198,199,210,221', '1', '1536062776', '1536062691');

-- -----------------------------
-- Table structure for `xt_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `xt_auth_group_access`;
CREATE TABLE `xt_auth_group_access` (
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户组id',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户组授权表';


-- -----------------------------
-- Table structure for `xt_blogroll`
-- -----------------------------
DROP TABLE IF EXISTS `xt_blogroll`;
CREATE TABLE `xt_blogroll` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(50) NOT NULL DEFAULT '' COMMENT '链接名称',
  `img_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '链接图片封面',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `describe` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='友情链接表';


-- -----------------------------
-- Table structure for `xt_bonus`
-- -----------------------------
DROP TABLE IF EXISTS `xt_bonus`;
CREATE TABLE `xt_bonus` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `times_id` bigint(20) NOT NULL COMMENT '期号，对应times表的id',
  `member_id` int(10) unsigned NOT NULL COMMENT '会员id',
  `username` char(50) NOT NULL DEFAULT '' COMMENT '会员账号',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `data_status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  `b0` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '奖0',
  `b1` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '奖1',
  `b2` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '奖2',
  `b3` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '奖3',
  `b4` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '奖4',
  `b5` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '奖5',
  `b6` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '奖6',
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=451 DEFAULT CHARSET=utf8 COMMENT='奖金表';

-- -----------------------------
-- Records of `xt_bonus`
-- -----------------------------
INSERT INTO `xt_bonus` VALUES ('445', '377', '1', '100000', '1537014339', '0', '1', '0.00', '3.60', '0.00', '0.00', '0.00', '0.00', '0.00', '0');
INSERT INTO `xt_bonus` VALUES ('446', '378', '1', '100000', '1537924980', '0', '1', '0.00', '0.00', '20.00', '0.00', '0.00', '0.00', '0.00', '0');
INSERT INTO `xt_bonus` VALUES ('447', '379', '1', '100000', '1538017826', '0', '1', '0.00', '0.00', '20.00', '0.00', '0.00', '0.00', '0.00', '0');
INSERT INTO `xt_bonus` VALUES ('448', '380', '1', '100000', '1538100613', '0', '1', '0.00', '0.00', '20.00', '0.00', '0.00', '0.00', '0.00', '0');
INSERT INTO `xt_bonus` VALUES ('449', '381', '1', '100000', '1538982657', '0', '1', '0.00', '0.00', '20.00', '0.00', '0.00', '0.00', '0.00', '0');
INSERT INTO `xt_bonus` VALUES ('450', '382', '1', '100000', '1539050084', '0', '1', '0.00', '0.00', '20.00', '0.00', '0.00', '0.00', '0.00', '0');

-- -----------------------------
-- Table structure for `xt_config`
-- -----------------------------
DROP TABLE IF EXISTS `xt_config`;
CREATE TABLE `xt_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置标题',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置选项',
  `describe` varchar(255) NOT NULL DEFAULT '' COMMENT '配置说明',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `value` text NOT NULL COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=112 DEFAULT CHARSET=utf8 COMMENT='配置表';

-- -----------------------------
-- Records of `xt_config`
-- -----------------------------
INSERT INTO `xt_config` VALUES ('1', 'seo_title', '1', '网站标题', '3', '', '', '1378898976', '1539059216', '1', '善策', '3');
INSERT INTO `xt_config` VALUES ('2', 'seo_description', '2', '网站描述', '3', '', '共享传媒', '1378898976', '1537881867', '1', '善策', '100');
INSERT INTO `xt_config` VALUES ('3', 'seo_keywords', '2', '网站关键字', '3', '', '', '1378898976', '1537881843', '1', '善策', '99');
INSERT INTO `xt_config` VALUES ('9', 'config_type_list', '3', '配置类型列表', '3', '', '主要用于数据解析和页面表单的生成', '1378898976', '1539059216', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举\r\n5:图片\r\n6:文件\r\n7:富文本\r\n8:单选\r\n9:多选\r\n10:日期\r\n11:时间\r\n12:颜色\r\n13:多图片', '100');
INSERT INTO `xt_config` VALUES ('20', 'config_group_list', '3', '配置分组', '3', '', '配置分组', '1379228036', '1539059216', '1', '1:参数设置 \r\n2:参数设置 \r\n3:参数设置 \r\n4:参数设置 ', '100');
INSERT INTO `xt_config` VALUES ('25', 'list_rows', '0', '每页数据记录数', '2', '', '数据每页显示记录数', '1379503896', '1507197630', '1', '10', '10');
INSERT INTO `xt_config` VALUES ('29', 'data_backup_part_size', '0', '数据库备份卷大小', '2', '', '该值用于限制压缩后的分卷最大长度。单位：B', '1381482488', '1507197630', '1', '52428800', '7');
INSERT INTO `xt_config` VALUES ('30', 'data_backup_compress', '4', '数据库备份文件是否启用压缩', '2', '0:不压缩\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1507197630', '1', '1', '9');
INSERT INTO `xt_config` VALUES ('31', 'data_backup_compress_level', '4', '数据库备份文件压缩级别', '2', '1:普通\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1507197630', '1', '9', '10');
INSERT INTO `xt_config` VALUES ('33', 'allow_url', '3', '不受权限验证的url', '3', '', '', '1386644047', '1539059216', '1', '0:file/pictureupload\r\n1:addon/execute', '100');
INSERT INTO `xt_config` VALUES ('43', 'empty_list_describe', '1', '数据列表为空时的描述信息', '2', '', '', '1492278127', '1507197630', '1', 'aOh! 暂时还没有数据~', '0');
INSERT INTO `xt_config` VALUES ('44', 'trash_config', '3', '回收站配置', '3', '', 'key为模型名称，值为显示列。', '1492312698', '1539059216', '1', 'Config:name\r\nAuthGroup:name\r\nMember:nickname\r\nMenu:name\r\nArticle:name\r\nArticleCategory:name\r\nAddon:name\r\nPicture:name\r\nFile:name\r\nActionLog:describe\r\nApi:name\r\nApiGroup:name\r\nBlogroll:name\r\nExeLog:exe_url\r\nSeo:name', '0');
INSERT INTO `xt_config` VALUES ('49', 'static_domain', '1', '静态资源域名', '0', '', '若静态资源为本地资源则此项为空，若为外部资源则为存放静态资源的域名', '1502430387', '1536124701', '1', '', '0');
INSERT INTO `xt_config` VALUES ('52', 'team_developer', '3', '研发团队人员', '4', '', '', '1504236453', '1510894595', '1', '0:Bigotry\r\n1:扫地僧', '0');
INSERT INTO `xt_config` VALUES ('53', 'api_status_option', '3', 'API接口状态', '4', '', '', '1504242433', '1510894595', '1', '0:待研发\r\n1:研发中\r\n2:测试中\r\n3:已完成', '0');
INSERT INTO `xt_config` VALUES ('54', 'api_data_type_option', '3', 'API数据类型', '4', '', '', '1504328208', '1510894595', '1', '0:字符\r\n1:文本\r\n2:数组\r\n3:文件', '0');
INSERT INTO `xt_config` VALUES ('55', 'frontend_theme', '1', '前端主题', '1', '', '', '1504762360', '1534571556', '-1', 'default', '0');
INSERT INTO `xt_config` VALUES ('56', 'api_domain', '1', 'API部署域名', '4', '', '', '1504779094', '1510894595', '1', 'https://demo.onebase.org', '0');
INSERT INTO `xt_config` VALUES ('57', 'api_key', '1', 'API加密KEY', '4', '', '泄露后API将存在安全隐患', '1505302112', '1510894595', '1', 'l2V|gfZp{8`;jzR~6Y1_', '0');
INSERT INTO `xt_config` VALUES ('58', 'loading_icon', '4', '页面Loading图标设置', '0', '1:图标1\r\n2:图标2\r\n3:图标3\r\n4:图标4\r\n5:图标5\r\n6:图标6\r\n7:图标7', '页面Loading图标支持7种图标切换', '1505377202', '1536124784', '1', '7', '80');
INSERT INTO `xt_config` VALUES ('59', 'sys_file_field', '3', '文件字段配置', '3', '', 'key为模型名，值为文件列名。', '1505799386', '1539059216', '1', '0_article:file_id', '0');
INSERT INTO `xt_config` VALUES ('60', 'sys_picture_field', '3', '图片字段配置', '3', '', 'key为模型名，值为图片列名。', '1506315422', '1539059216', '1', '0_article:cover_id\r\n1_article:img_ids', '0');
INSERT INTO `xt_config` VALUES ('61', 'jwt_key', '1', 'JWT加密KEY', '4', '', '', '1506748805', '1537879642', '1', 'l2V|DSFXXXgfZp{8`;FjzR~6Y1_', '0');
INSERT INTO `xt_config` VALUES ('64', 'is_write_exe_log', '4', '是否写入执行记录', '3', '0:否\r\n1:是', '', '1510544340', '1539059216', '1', '1', '101');
INSERT INTO `xt_config` VALUES ('65', 'admin_allow_ip', '3', '超级管理员登录IP', '3', '', '后台超级管理员登录IP限制，其他角色不受限。', '1510995580', '1539059216', '1', '0:27.22.112.250', '0');
INSERT INTO `xt_config` VALUES ('66', 'pjax_mode', '8', 'PJAX模式', '3', '0:否\r\n1:是', '若为PJAX模式则浏览器不会刷新，若为常规模式则为AJAX+刷新', '1512370397', '1539059216', '1', '0', '120');
INSERT INTO `xt_config` VALUES ('67', 'reco', '2', '推荐奖', '1', '', '', '1533280243', '1536550226', '-1', '5', '0');
INSERT INTO `xt_config` VALUES ('68', 'cpzj', '2', '注册金额', '0', '', '注册金额的多少', '1533294825', '1537879642', '1', '3000|5000|10000|30000|50000', '0');
INSERT INTO `xt_config` VALUES ('69', 'treeplace', '2', '左中右区设置', '0', '', '相对于上级 的哪个区域', '1533295624', '1537879642', '1', '0-左|1-中|2-右', '0');
INSERT INTO `xt_config` VALUES ('70', 'vip_level', '2', '会员级别', '1', '', '会员的级别', '1533355032', '1536550353', '-1', '2000会员|5000会员|10000会员|30000会员|50000会员', '0');
INSERT INTO `xt_config` VALUES ('71', 'type_name', '2', '奖项名称显示', '1', '', '', '1533871065', '1538984869', '-1', '0-余额|50-充值|61-领取任务|30-转账|1-ui|2-前端|3-后端', '4');
INSERT INTO `xt_config` VALUES ('90', 'kefu_weixin', '7', '客服微信二维码', '1', '', '', '1536568561', '1538984821', '-1', '&amp;lt;h3 class=&amp;quot;spec-title&amp;quot; style=&amp;quot;font-size:16px;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	&amp;lt;span style=&amp;quot;color:#333333;font-family:&amp;amp;quot;font-size:14px;font-weight:700;background-color:#FFFFFF;&amp;quot;&amp;gt;客服微信二维码&amp;lt;/span&amp;gt; \r\n&amp;lt;/h3&amp;gt;\r\n&amp;lt;p class=&amp;quot;title&amp;quot; style=&amp;quot;color:#FE702F;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	划线价格\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	指商品的专柜价、吊牌价、正品零售价、厂商指导价或该商品的曾经展示过的销售价等，&amp;lt;span style=&amp;quot;color:#333333;font-weight:600;&amp;quot;&amp;gt;并非原价&amp;lt;/span&amp;gt;，仅供参考。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;title&amp;quot; style=&amp;quot;color:#FE702F;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	未划线价格\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	指商品的&amp;lt;span style=&amp;quot;color:#333333;font-weight:600;&amp;quot;&amp;gt;实时标价&amp;lt;/span&amp;gt;，不因表述的差异改变性质。具体成交价格根据商品参加活动，或会员使用优惠券、积分等发生变化，最终以订单结算页价格为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	商家详情页（含主图）以图片或文字形式标注的一口价、促销价、优惠价等价格可能是在使用优惠券、满减或特定优惠活动和时段等情形下的价格，具体请以结算页面的标价、优惠条件或活动规则为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	此说明仅当出现价格比较时有效，具体请参见《淘宝价格发布规范》。若商家单独对划线价格进行说明的，以商家的表述为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p&amp;gt;\r\n	&amp;lt;img src=&amp;quot;/j8830/public/upload/picture/20180908/fec63cfd4f9bda7464a815873f02d406.jpg&amp;quot; alt=&amp;quot;&amp;quot; /&amp;gt; \r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;div&amp;gt;\r\n	&amp;lt;br /&amp;gt;\r\n&amp;lt;/div&amp;gt;', '1');
INSERT INTO `xt_config` VALUES ('73', 'is_agent', '2', '报单中心配置', '0', '', '', '1536109819', '1537879642', '1', '1-普通会员|2-报单中心', '0');
INSERT INTO `xt_config` VALUES ('72', 'agent_income', '2', '代理商提成', '1', '', '按身份证所在归属地，得利润（省|市|县）', '1534571441', '1536110329', '-1', '3-10|2-7|1-5', '0');
INSERT INTO `xt_config` VALUES ('74', 's_ratio', '2', '沙棘链比例', '1', '', '', '1536110316', '1536549400', '-1', '2000-1.5| 5000-1.5|10000- 2|30000-2.5|50000-3', '0');
INSERT INTO `xt_config` VALUES ('75', 'everyday_time', '2', '每日时间', '0', '', '每日发奖后更新时间', '1536110905', '1537879642', '1', '1539014400', '0');
INSERT INTO `xt_config` VALUES ('76', 'achievement', '2', '业绩奖', '1', '', '左右区和', '1536121084', '1536549400', '-1', '6', '0');
INSERT INTO `xt_config` VALUES ('77', 'manage', '2', '管理奖', '1', '', '拿下几代会员的业绩奖', '1536124636', '1536549400', '-1', '1-20|2-15|3-10', '0');
INSERT INTO `xt_config` VALUES ('78', 'see_you', '2', '滑落奖', '1', '', '注册金额-层数', '1536125806', '1536549388', '-1', '2000-8|5000-9|10000-10|30000-12|50000-15\r\n', '0');
INSERT INTO `xt_config` VALUES ('79', 'see_you_ratio', '2', '滑落奖比例', '1', '', '', '1536126087', '1536549388', '-1', '1', '0');
INSERT INTO `xt_config` VALUES ('80', 'agent_center', '2', '报单奖比例', '1', '', '', '1536130873', '1536549388', '-1', '3', '0');
INSERT INTO `xt_config` VALUES ('81', 'tax', '2', '税比例', '1', '', '', '1536132648', '1536549388', '-1', '10', '0');
INSERT INTO `xt_config` VALUES ('82', 'money_type', '2', '钱包-奖', '1', '', '什么奖进入什么钱包', '1536281115', '1538984869', '-1', '1-静态收益钱包|2-动态收益钱包|', '4');
INSERT INTO `xt_config` VALUES ('88', 'statistic_income', '2', '静态收益', '1', '', '每天分享任务1次到朋友圈，收益4元/每日（如，五个广告包，每日分享5次可收益20元每天）    ', '1536549994', '1538984869', '-1', '4', '13');
INSERT INTO `xt_config` VALUES ('83', 'alipay', '7', '支付宝付款码', '1', '', '', '1536404196', '1538984821', '-1', '&amp;lt;h3 class=&amp;quot;spec-title&amp;quot; style=&amp;quot;font-size:16px;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	&amp;lt;span style=&amp;quot;color:#333333;font-family:&amp;amp;quot;font-size:14px;font-weight:700;background-color:#FFFFFF;&amp;quot;&amp;gt;支付宝付款码&amp;lt;/span&amp;gt; \r\n&amp;lt;/h3&amp;gt;\r\n&amp;lt;p class=&amp;quot;title&amp;quot; style=&amp;quot;color:#FE702F;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	划线价格\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	指商品的专柜价、吊牌价、正品零售价、厂商指导价或该商品的曾经展示过的销售价等，&amp;lt;span style=&amp;quot;color:#333333;font-weight:600;&amp;quot;&amp;gt;并非原价&amp;lt;/span&amp;gt;，仅供参考。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;title&amp;quot; style=&amp;quot;color:#FE702F;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	未划线价格\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	指商品的&amp;lt;span style=&amp;quot;color:#333333;font-weight:600;&amp;quot;&amp;gt;实时标价&amp;lt;/span&amp;gt;，不因表述的差异改变性质。具体成交价格根据商品参加活动，或会员使用优惠券、积分等发生变化，最终以订单结算页价格为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	商家详情页（含主图）以图片或文字形式标注的一口价、促销价、优惠价等价格可能是在使用优惠券、满减或特定优惠活动和时段等情形下的价格，具体请以结算页面的标价、优惠条件或活动规则为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	此说明仅当出现价格比较时有效，具体请参见《淘宝价格发布规范》。若商家单独对划线价格进行说明的，以商家的表述为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p&amp;gt;\r\n	&amp;lt;img src=&amp;quot;/j8830/public/upload/picture/20180908/fec63cfd4f9bda7464a815873f02d406.jpg&amp;quot; alt=&amp;quot;&amp;quot; /&amp;gt; \r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;div&amp;gt;\r\n	&amp;lt;br /&amp;gt;\r\n&amp;lt;/div&amp;gt;', '2');
INSERT INTO `xt_config` VALUES ('84', 'weixin', '7', '微信付款码', '1', '', '', '1536404301', '1538984821', '-1', '&amp;lt;h3 class=&amp;quot;spec-title&amp;quot; style=&amp;quot;font-size:16px;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	&amp;lt;span style=&amp;quot;color:#333333;font-family:&amp;amp;quot;font-size:14px;font-weight:700;background-color:#FFFFFF;&amp;quot;&amp;gt;微信付款码&amp;lt;/span&amp;gt; \r\n&amp;lt;/h3&amp;gt;\r\n&amp;lt;p class=&amp;quot;title&amp;quot; style=&amp;quot;color:#FE702F;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	划线价格\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	指商品的专柜价、吊牌价、正品零售价、厂商指导价或该商品的曾经展示过的销售价等，&amp;lt;span style=&amp;quot;color:#333333;font-weight:600;&amp;quot;&amp;gt;并非原价&amp;lt;/span&amp;gt;，仅供参考。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;title&amp;quot; style=&amp;quot;color:#FE702F;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	未划线价格\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	指商品的&amp;lt;span style=&amp;quot;color:#333333;font-weight:600;&amp;quot;&amp;gt;实时标价&amp;lt;/span&amp;gt;，不因表述的差异改变性质。具体成交价格根据商品参加活动，或会员使用优惠券、积分等发生变化，最终以订单结算页价格为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	商家详情页（含主图）以图片或文字形式标注的一口价、促销价、优惠价等价格可能是在使用优惠券、满减或特定优惠活动和时段等情形下的价格，具体请以结算页面的标价、优惠条件或活动规则为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	此说明仅当出现价格比较时有效，具体请参见《淘宝价格发布规范》。若商家单独对划线价格进行说明的，以商家的表述为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p&amp;gt;\r\n	&amp;lt;img src=&amp;quot;/j8830/public/upload/picture/20180908/fec63cfd4f9bda7464a815873f02d406.jpg&amp;quot; alt=&amp;quot;&amp;quot; /&amp;gt; \r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;div&amp;gt;\r\n	&amp;lt;br /&amp;gt;\r\n&amp;lt;/div&amp;gt;', '2');
INSERT INTO `xt_config` VALUES ('85', 'ad', '2', '广告位字符串', '1', '', '', '1536406831', '1538984869', '-1', ' 广告位招租：联系XXXXXX的法国德国法国队电饭锅大地飞歌地方电饭锅的风格的风格的地方', '10');
INSERT INTO `xt_config` VALUES ('86', 'how', '7', '如何返佣', '1', '', '', '1536409204', '1538984821', '-1', '&amp;lt;h3 class=&amp;quot;spec-title&amp;quot; style=&amp;quot;font-size:16px;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	&amp;lt;span style=&amp;quot;color:#333333;font-family:&amp;amp;quot;font-size:14px;font-weight:700;background-color:#FFFFFF;&amp;quot;&amp;gt;如何返佣&amp;lt;/span&amp;gt; \r\n&amp;lt;/h3&amp;gt;\r\n&amp;lt;p class=&amp;quot;title&amp;quot; style=&amp;quot;color:#FE702F;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	划线价格\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	指商品的专柜价、吊牌价、正品零售价、厂商指导价或该商品的曾经展示过的销售价等，&amp;lt;span style=&amp;quot;color:#333333;font-weight:600;&amp;quot;&amp;gt;并非原价&amp;lt;/span&amp;gt;，仅供参考。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;title&amp;quot; style=&amp;quot;color:#FE702F;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	未划线价格\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	指商品的&amp;lt;span style=&amp;quot;color:#333333;font-weight:600;&amp;quot;&amp;gt;实时标价&amp;lt;/span&amp;gt;，不因表述的差异改变性质。具体成交价格根据商品参加活动，或会员使用优惠券、积分等发生变化，最终以订单结算页价格为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	商家详情页（含主图）以图片或文字形式标注的一口价、促销价、优惠价等价格可能是在使用优惠券、满减或特定优惠活动和时段等情形下的价格，具体请以结算页面的标价、优惠条件或活动规则为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	此说明仅当出现价格比较时有效，具体请参见《淘宝价格发布规范》。若商家单独对划线价格进行说明的，以商家的表述为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p&amp;gt;\r\n	&amp;lt;img src=&amp;quot;/j8830/public/upload/picture/20180908/fec63cfd4f9bda7464a815873f02d406.jpg&amp;quot; alt=&amp;quot;&amp;quot; /&amp;gt; \r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;div&amp;gt;\r\n	&amp;lt;br /&amp;gt;\r\n&amp;lt;/div&amp;gt;', '3');
INSERT INTO `xt_config` VALUES ('87', 'task', '7', '任务一', '1', '', '', '1536539506', '1538984780', '-1', '&amp;lt;h3 class=&amp;quot;spec-title&amp;quot; style=&amp;quot;font-size:16px;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	任务一\r\n&amp;lt;/h3&amp;gt;\r\n&amp;lt;p class=&amp;quot;title&amp;quot; style=&amp;quot;color:#FE702F;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	划线价格\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	指商品的专柜价、吊牌价、正品零售价、厂商指导价或该商品的曾经展示过的销售价等，&amp;lt;span style=&amp;quot;color:#333333;font-weight:600;&amp;quot;&amp;gt;并非原价&amp;lt;/span&amp;gt;，仅供参考。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;title&amp;quot; style=&amp;quot;color:#FE702F;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	未划线价格\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	指商品的&amp;lt;span style=&amp;quot;color:#333333;font-weight:600;&amp;quot;&amp;gt;实时标价&amp;lt;/span&amp;gt;，不因表述的差异改变性质。具体成交价格根据商品参加活动，或会员使用优惠券、积分等发生变化，最终以订单结算页价格为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	商家详情页（含主图）以图片或文字形式标注的一口价、促销价、优惠价等价格可能是在使用优惠券、满减或特定优惠活动和时段等情形下的价格，具体请以结算页面的标价、优惠条件或活动规则为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	此说明仅当出现价格比较时有效，具体请参见《淘宝价格发布规范》。若商家单独对划线价格进行说明的，以商家的表述为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p&amp;gt;\r\n	&amp;lt;img src=&amp;quot;/j8830/public/upload/picture/20180908/fec63cfd4f9bda7464a815873f02d406.jpg&amp;quot; alt=&amp;quot;&amp;quot; /&amp;gt; \r\n&amp;lt;/p&amp;gt;', '0');
INSERT INTO `xt_config` VALUES ('89', 'dynamic_income', '2', '动态收益', '1', '', ' 拿直推分享收益的50% （如；就是我推荐A，他做完任务可以得4块，那么我得50%，2块，A推B，B 做完任务，B得4块，A得2块，我得1块，然后B推C，C做完任务，C得4块，B得2块，A得一块，我得0.5）   无限推', '1536550117', '1538984821', '-1', '1-4|2-2|3-1|4-0.5', '11');
INSERT INTO `xt_config` VALUES ('91', 'ad_content', '7', '广告投放页面', '1', '', '', '1536647163', '1538984869', '-1', '&amp;lt;h3 class=&amp;quot;spec-title&amp;quot; style=&amp;quot;font-size:16px;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	&amp;lt;span style=&amp;quot;color:#333333;font-family:&amp;amp;quot;font-size:14px;font-weight:700;background-color:#FFFFFF;&amp;quot;&amp;gt;广告投放页面&amp;lt;/span&amp;gt; \r\n&amp;lt;/h3&amp;gt;\r\n&amp;lt;p class=&amp;quot;title&amp;quot; style=&amp;quot;color:#FE702F;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	划线价格\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	指商品的专柜价、吊牌价、正品零售价、厂商指导价或该商品的曾经展示过的销售价等，&amp;lt;span style=&amp;quot;color:#333333;font-weight:600;&amp;quot;&amp;gt;并非原价&amp;lt;/span&amp;gt;，仅供参考。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;title&amp;quot; style=&amp;quot;color:#FE702F;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	未划线价格\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	指商品的&amp;lt;span style=&amp;quot;color:#333333;font-weight:600;&amp;quot;&amp;gt;实时标价&amp;lt;/span&amp;gt;，不因表述的差异改变性质。具体成交价格根据商品参加活动，或会员使用优惠券、积分等发生变化，最终以订单结算页价格为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	商家详情页（含主图）以图片或文字形式标注的一口价、促销价、优惠价等价格可能是在使用优惠券、满减或特定优惠活动和时段等情形下的价格，具体请以结算页面的标价、优惠条件或活动规则为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	此说明仅当出现价格比较时有效，具体请参见《淘宝价格发布规范》。若商家单独对划线价格进行说明的，以商家的表述为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p&amp;gt;\r\n	&amp;lt;img src=&amp;quot;/j8830/public/upload/picture/20180908/fec63cfd4f9bda7464a815873f02d406.jpg&amp;quot; alt=&amp;quot;&amp;quot; /&amp;gt; \r\n&amp;lt;/p&amp;gt;', '1');
INSERT INTO `xt_config` VALUES ('92', 'scroll_picture ', '5', '滚动图片', '1', '', '', '1536740209', '1536740639', '-1', '', '21');
INSERT INTO `xt_config` VALUES ('93', 'scroll_p', '5', '滚动图片', '0', '', '', '1536740653', '1536917911', '1', '0', '33');
INSERT INTO `xt_config` VALUES ('94', 'end_time', '2', '倒计时（小时）', '1', '', '', '1536741568', '1538984869', '-1', '5', '34');
INSERT INTO `xt_config` VALUES ('95', 'max_ad', '2', '最多持有广告包数目（个）', '1', '', '', '1536808039', '1538984869', '-1', '5', '36');
INSERT INTO `xt_config` VALUES ('96', 'be_out_ad', '2', '出局广告包金额（广告包价格-出局算的广告包金额）', '0', '', '广告包价格是商品广告包的价格应该和广告包商品的价格保持一致，出局当的广告包金额', '1536808506', '1536887746', '1', '198|20', '35');
INSERT INTO `xt_config` VALUES ('97', 'dynamic_out', '2', '动态收益达到多少出局一个广告包', '1', '', '', '1536831572', '1538984869', '-1', '200', '38');
INSERT INTO `xt_config` VALUES ('98', 'statistic_out', '2', '静态收益达到多少出局一个广告包', '1', '', '', '1536831625', '1538984869', '-1', '300', '37');
INSERT INTO `xt_config` VALUES ('99', 'bank', '2', '银行', '0', '', '', '1536899953', '1538984780', '-1', '支付宝|中国工商银行|中国银行|中国农业银行|中国建设银行|中国邮政储蓄银行|广发银行|浦发银行|平安银行|交通银行|招商银行|兴业银行\'|中信银行|民生银行|光大银行', '0');
INSERT INTO `xt_config` VALUES ('100', 'bank_gathering', '7', '银行收款码', '1', '', '', '1536974273', '1538984821', '-1', '&amp;lt;h3 class=&amp;quot;spec-title&amp;quot; style=&amp;quot;font-size:16px;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	&amp;lt;span style=&amp;quot;color:#333333;font-family:&amp;amp;quot;font-size:14px;font-weight:700;background-color:#FFFFFF;&amp;quot;&amp;gt;银行付款码&amp;lt;/span&amp;gt; \r\n&amp;lt;/h3&amp;gt;\r\n&amp;lt;p class=&amp;quot;title&amp;quot; style=&amp;quot;color:#FE702F;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	划线价格\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	指商品的专柜价、吊牌价、正品零售价、厂商指导价或该商品的曾经展示过的销售价等，&amp;lt;span style=&amp;quot;color:#333333;font-weight:600;&amp;quot;&amp;gt;并非原价&amp;lt;/span&amp;gt;，仅供参考。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;title&amp;quot; style=&amp;quot;color:#FE702F;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	未划线价格\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	指商品的&amp;lt;span style=&amp;quot;color:#333333;font-weight:600;&amp;quot;&amp;gt;实时标价&amp;lt;/span&amp;gt;，不因表述的差异改变性质。具体成交价格根据商品参加活动，或会员使用优惠券、积分等发生变化，最终以订单结算页价格为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	商家详情页（含主图）以图片或文字形式标注的一口价、促销价、优惠价等价格可能是在使用优惠券、满减或特定优惠活动和时段等情形下的价格，具体请以结算页面的标价、优惠条件或活动规则为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	此说明仅当出现价格比较时有效，具体请参见《淘宝价格发布规范》。若商家单独对划线价格进行说明的，以商家的表述为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p&amp;gt;\r\n	&amp;lt;img src=&amp;quot;/j8830/public/upload/picture/20180908/fec63cfd4f9bda7464a815873f02d406.jpg&amp;quot; alt=&amp;quot;&amp;quot; /&amp;gt; \r\n&amp;lt;/p&amp;gt;', '3');
INSERT INTO `xt_config` VALUES ('101', 'task2', '7', '任务二', '1', '', '', '1536995620', '1538984780', '-1', '&amp;lt;h3 class=&amp;quot;spec-title&amp;quot; style=&amp;quot;font-size:16px;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	任务说明二\r\n&amp;lt;/h3&amp;gt;\r\n&amp;lt;p class=&amp;quot;title&amp;quot; style=&amp;quot;color:#FE702F;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	划线价格\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	指商品的专柜价、吊牌价、正品零售价、厂商指导价或该商品的曾经展示过的销售价等，&amp;lt;span style=&amp;quot;color:#333333;font-weight:600;&amp;quot;&amp;gt;并非原价&amp;lt;/span&amp;gt;，仅供参考。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;title&amp;quot; style=&amp;quot;color:#FE702F;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	未划线价格\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	指商品的&amp;lt;span style=&amp;quot;color:#333333;font-weight:600;&amp;quot;&amp;gt;实时标价&amp;lt;/span&amp;gt;，不因表述的差异改变性质。具体成交价格根据商品参加活动，或会员使用优惠券、积分等发生变化，最终以订单结算页价格为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	商家详情页（含主图）以图片或文字形式标注的一口价、促销价、优惠价等价格可能是在使用优惠券、满减或特定优惠活动和时段等情形下的价格，具体请以结算页面的标价、优惠条件或活动规则为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	此说明仅当出现价格比较时有效，具体请参见《淘宝价格发布规范》。若商家单独对划线价格进行说明的，以商家的表述为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p&amp;gt;\r\n	&amp;lt;img src=&amp;quot;/j8830/public/upload/picture/20180908/fec63cfd4f9bda7464a815873f02d406.jpg&amp;quot; alt=&amp;quot;&amp;quot; /&amp;gt; \r\n&amp;lt;/p&amp;gt;', '0');
INSERT INTO `xt_config` VALUES ('102', 'task_specification', '7', '任务说明', '1', '', '', '1536995754', '1538984780', '-1', '&amp;lt;h3 class=&amp;quot;spec-title&amp;quot; style=&amp;quot;font-size:16px;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	任务说明\r\n&amp;lt;/h3&amp;gt;\r\n&amp;lt;p class=&amp;quot;title&amp;quot; style=&amp;quot;color:#FE702F;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	划线价格\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	指商品的专柜价、吊牌价、正品零售价、厂商指导价或该商品的曾经展示过的销售价等，&amp;lt;span style=&amp;quot;color:#333333;font-weight:600;&amp;quot;&amp;gt;并非原价&amp;lt;/span&amp;gt;，仅供参考。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;title&amp;quot; style=&amp;quot;color:#FE702F;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	未划线价格\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	指商品的&amp;lt;span style=&amp;quot;color:#333333;font-weight:600;&amp;quot;&amp;gt;实时标价&amp;lt;/span&amp;gt;，不因表述的差异改变性质。具体成交价格根据商品参加活动，或会员使用优惠券、积分等发生变化，最终以订单结算页价格为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	商家详情页（含主图）以图片或文字形式标注的一口价、促销价、优惠价等价格可能是在使用优惠券、满减或特定优惠活动和时段等情形下的价格，具体请以结算页面的标价、优惠条件或活动规则为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p class=&amp;quot;info&amp;quot; style=&amp;quot;color:#666666;font-family:tahoma, arial, &amp;amp;quot;background-color:#FFFFFF;&amp;quot;&amp;gt;\r\n	此说明仅当出现价格比较时有效，具体请参见《淘宝价格发布规范》。若商家单独对划线价格进行说明的，以商家的表述为准。\r\n&amp;lt;/p&amp;gt;\r\n&amp;lt;p&amp;gt;\r\n	&amp;lt;img src=&amp;quot;/j8830/public/upload/picture/20180908/fec63cfd4f9bda7464a815873f02d406.jpg&amp;quot; alt=&amp;quot;&amp;quot; /&amp;gt; \r\n&amp;lt;/p&amp;gt;', '0');
INSERT INTO `xt_config` VALUES ('103', 'banner1', '5', '首页轮播图1', '1', '', '', '1538989237', '1539064739', '1', '48', '0');
INSERT INTO `xt_config` VALUES ('104', 'banner2', '5', '首页轮播图2', '1', '', '', '1538989256', '1539063095', '1', '48', '0');
INSERT INTO `xt_config` VALUES ('105', 'banner3', '5', '首页轮播图3', '1', '', '', '1538989300', '1539064739', '1', '45', '0');
INSERT INTO `xt_config` VALUES ('106', 'case_banner', '5', '案例banner', '1', '', '', '1539056441', '1539064739', '1', '58', '0');
INSERT INTO `xt_config` VALUES ('107', 'service_banner', '5', '服务banner', '1', '', '', '1539056504', '1539064739', '1', '48', '0');
INSERT INTO `xt_config` VALUES ('108', 'about_banner', '5', '关于banner', '1', '', '', '1539056538', '1539064739', '1', '0', '0');
INSERT INTO `xt_config` VALUES ('109', 'mobile_case_banner', '5', '手机案例banner', '1', '', '', '1539063236', '1539063236', '1', '', '0');
INSERT INTO `xt_config` VALUES ('110', 'mobile_service_banner', '5', '手机服务banner', '1', '', '', '1539063390', '1539063390', '1', '', '0');
INSERT INTO `xt_config` VALUES ('111', 'mobile_about_banner', '5', '手机关于banner', '1', '', '', '1539063474', '1539063474', '1', '', '0');

-- -----------------------------
-- Table structure for `xt_draw`
-- -----------------------------
DROP TABLE IF EXISTS `xt_draw`;
CREATE TABLE `xt_draw` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `uid` mediumint(8) NOT NULL DEFAULT '0' COMMENT '用户id',
  `ctime` int(11) DEFAULT '0',
  `num` int(11) DEFAULT '0',
  `name` varchar(20) CHARACTER SET utf8 NOT NULL COMMENT '支付宝验证名',
  `card` varchar(30) CHARACTER SET utf8 NOT NULL COMMENT '支付宝账号',
  `bank` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `kaihu` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `content` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0' COMMENT '状态0代表未审核 1代表已完成 2代表驳回',
  `order_id` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `issq` tinyint(1) DEFAULT '0',
  `error` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `type` tinyint(1) DEFAULT '0',
  `text` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- -----------------------------
-- Table structure for `xt_driver`
-- -----------------------------
DROP TABLE IF EXISTS `xt_driver`;
CREATE TABLE `xt_driver` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `service_name` varchar(40) NOT NULL DEFAULT '' COMMENT '服务标识',
  `driver_name` varchar(20) NOT NULL DEFAULT '' COMMENT '驱动标识',
  `config` text NOT NULL COMMENT '配置',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='插件表';


-- -----------------------------
-- Table structure for `xt_exe_log`
-- -----------------------------
DROP TABLE IF EXISTS `xt_exe_log`;
CREATE TABLE `xt_exe_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `ip` char(50) NOT NULL DEFAULT '' COMMENT 'IP地址',
  `exe_url` varchar(2000) NOT NULL DEFAULT '' COMMENT '执行URL',
  `exe_time` float(10,6) unsigned NOT NULL DEFAULT '0.000000' COMMENT '执行时间 单位 秒',
  `exe_memory` char(20) NOT NULL DEFAULT '' COMMENT '内存占用KB',
  `exe_os` char(30) NOT NULL DEFAULT '' COMMENT '操作系统',
  `source_url` varchar(2000) NOT NULL DEFAULT '' COMMENT '来源URL',
  `session_id` char(32) NOT NULL DEFAULT '' COMMENT 'session_id',
  `browser` char(30) NOT NULL DEFAULT '' COMMENT '浏览器',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `login_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '执行者ID',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '类型  0 ： 应用范围 ， 1：API 范围 ',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17227 DEFAULT CHARSET=utf8 COMMENT='执行记录表';

-- -----------------------------
-- Records of `xt_exe_log`
-- -----------------------------
INSERT INTO `xt_exe_log` VALUES ('17222', '192.168.0.197', '/s8726/public/admin/statistic/exespeed.html?_pjax=.content', '0.17301', '2.31 MB', 'Windows', 'http://192.168.0.197/s8726/public/admin/index/index.html', '17tq6r8q7bgb2vcqtu95du7tg0', 'Chrome', '1', '1534328025', '1534328025', '1', '0');
INSERT INTO `xt_exe_log` VALUES ('17223', '192.168.0.197', '/s8726/public/index/index/index.html?_pjax=.content', '0.093005', '2.22 MB', 'Windows', 'http://192.168.0.197/s8726/public/admin/statistic/exespeed.html', '17tq6r8q7bgb2vcqtu95du7tg0', 'Chrome', '1', '1534328033', '1534328033', '1', '0');
INSERT INTO `xt_exe_log` VALUES ('17224', '192.168.0.197', '/s8726/public/index/index/index.html', '0.102006', '2.26 MB', 'Windows', 'http://192.168.0.197/s8726/public/admin/statistic/exespeed.html', '17tq6r8q7bgb2vcqtu95du7tg0', 'Chrome', '1', '1534328033', '1534328033', '1', '0');
INSERT INTO `xt_exe_log` VALUES ('17225', '192.168.0.197', '/s8726/public/admin/index/index.html', '0.223013', '2.02 MB', 'Windows', 'http://192.168.0.197/s8726/public/index/index/index.html', '17tq6r8q7bgb2vcqtu95du7tg0', 'Chrome', '1', '1534328034', '1534328034', '1', '0');
INSERT INTO `xt_exe_log` VALUES ('17226', '192.168.0.197', '/s8726/public/admin/exelog/applist.html?_pjax=.content', '0.185011', '2.19 MB', 'Windows', 'http://192.168.0.197/s8726/public/admin/index/index.html', '17tq6r8q7bgb2vcqtu95du7tg0', 'Chrome', '1', '1534328050', '1534328050', '1', '0');

-- -----------------------------
-- Table structure for `xt_file`
-- -----------------------------
DROP TABLE IF EXISTS `xt_file`;
CREATE TABLE `xt_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '保存名称',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '远程地址',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '上传时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='文件表';

-- -----------------------------
-- Records of `xt_file`
-- -----------------------------
INSERT INTO `xt_file` VALUES ('1', '8cf1200e7587bd072a0dbc5ccc628bee.jpg', '20180823/8cf1200e7587bd072a0dbc5ccc628bee.jpg', '', '15b49f44d67d54111648596bf95e21e68a37b814', '1535006559', '0', '1');
INSERT INTO `xt_file` VALUES ('2', '8f322ac6d3678332bed4a5c82052ff57.jpg', '20180823/8f322ac6d3678332bed4a5c82052ff57.jpg', '', '2f2108c930c69861f55a4479de3b40bc18fcef43', '1535006567', '0', '1');
INSERT INTO `xt_file` VALUES ('3', '42abf306fe95e8a745d473af4ba0804c.jpg', '20180823/42abf306fe95e8a745d473af4ba0804c.jpg', '', 'f0c7066ecbd16879194bc49500eb4cd6db6ef667', '1535006614', '0', '1');
INSERT INTO `xt_file` VALUES ('4', '2b3837e08bf15b587306cb380bbb301a.jpg', '20180910/2b3837e08bf15b587306cb380bbb301a.jpg', '', '57e1e2096c439547f014e73cf00795eac4e58d73', '1536546209', '0', '1');
INSERT INTO `xt_file` VALUES ('5', '2fc8c3c763f6a01fbd17dbf0fd916484.jpg', '20181009/2fc8c3c763f6a01fbd17dbf0fd916484.jpg', '', '75fc9562b9cbc91bb2a0f65a73c0c41ad835ff2c', '1539058795', '0', '1');
INSERT INTO `xt_file` VALUES ('6', '8ffd61d4fbe1ae0855a569c29bbd055f.txt', '20181009/8ffd61d4fbe1ae0855a569c29bbd055f.txt', '', 'cf4bc5eaaffdb56ee00ee3b0cc834dad71a005b3', '1539058800', '0', '1');

-- -----------------------------
-- Table structure for `xt_history`
-- -----------------------------
DROP TABLE IF EXISTS `xt_history`;
CREATE TABLE `xt_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `user_id` varchar(50) DEFAULT NULL,
  `did` int(11) NOT NULL,
  `user_did` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `action_type` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `pdt` int(11) NOT NULL,
  `epoints` decimal(12,2) NOT NULL DEFAULT '0.00',
  `allp` decimal(12,2) NOT NULL DEFAULT '0.00',
  `bz` text,
  `type` smallint(1) NOT NULL COMMENT '充值0明细1',
  `act_pdt` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL,
  `issq` int(11) NOT NULL,
  `text` varchar(255) NOT NULL,
  `task` text,
  `task_type` varchar(255) NOT NULL,
  `img_ids` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`action_type`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=1134 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xt_history`
-- -----------------------------
INSERT INTO `xt_history` VALUES ('1122', '1', '100000', '1', '100000', '0', '1537014128', '-19.00', '0.00', '', '1', '0', '0', '0', '', '', '', '');
INSERT INTO `xt_history` VALUES ('1123', '1', '100000', '1', '100000', '61', '1537014135', '0.00', '0.00', '', '1', '0', '3', '0', '', '<h3 class=\"spec-title\" style=\"font-size:16px;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	任务一\r\n</h3>\r\n<p class=\"title\" style=\"color:#FE702F;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	划线价格\r\n</p>\r\n<p class=\"info\" style=\"color:#666666;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	指商品的专柜价、吊牌价、正品零售价、厂商指导价或该商品的曾经展示过的销售价等，<span style=\"color:#333333;font-weight:600;\">并非原价</span>，仅供参考。\r\n</p>\r\n<p class=\"title\" style=\"color:#FE702F;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	未划线价格\r\n</p>\r\n<p class=\"info\" style=\"color:#666666;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	指商品的<span style=\"color:#333333;font-weight:600;\">实时标价</span>，不因表述的差异改变性质。具体成交价格根据商品参加活动，或会员使用优惠券、积分等发生变化，最终以订单结算页价格为准。\r\n</p>\r\n<p class=\"info\" style=\"color:#666666;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	商家详情页（含主图）以图片或文字形式标注的一口价、促销价、优惠价等价格可能是在使用优惠券、满减或特定优惠活动和时段等情形下的价格，具体请以结算页面的标价、优惠条件或活动规则为准。\r\n</p>\r\n<p class=\"info\" style=\"color:#666666;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	此说明仅当出现价格比较时有效，具体请参见《淘宝价格发布规范》。若商家单独对划线价格进行说明的，以商家的表述为准。\r\n</p>\r\n<p>\r\n	<img src=\"/j8830/public/upload/picture/20180908/fec63cfd4f9bda7464a815873f02d406.jpg\" alt=\"\" /> \r\n</p>', 'task', '24');
INSERT INTO `xt_history` VALUES ('1124', '1', '100000', '1', '100000', '61', '1537014140', '0.00', '0.00', '', '1', '0', '1', '0', '', '<h3 class=\"spec-title\" style=\"font-size:16px;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	任务说明二\r\n</h3>\r\n<p class=\"title\" style=\"color:#FE702F;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	划线价格\r\n</p>\r\n<p class=\"info\" style=\"color:#666666;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	指商品的专柜价、吊牌价、正品零售价、厂商指导价或该商品的曾经展示过的销售价等，<span style=\"color:#333333;font-weight:600;\">并非原价</span>，仅供参考。\r\n</p>\r\n<p class=\"title\" style=\"color:#FE702F;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	未划线价格\r\n</p>\r\n<p class=\"info\" style=\"color:#666666;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	指商品的<span style=\"color:#333333;font-weight:600;\">实时标价</span>，不因表述的差异改变性质。具体成交价格根据商品参加活动，或会员使用优惠券、积分等发生变化，最终以订单结算页价格为准。\r\n</p>\r\n<p class=\"info\" style=\"color:#666666;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	商家详情页（含主图）以图片或文字形式标注的一口价、促销价、优惠价等价格可能是在使用优惠券、满减或特定优惠活动和时段等情形下的价格，具体请以结算页面的标价、优惠条件或活动规则为准。\r\n</p>\r\n<p class=\"info\" style=\"color:#666666;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	此说明仅当出现价格比较时有效，具体请参见《淘宝价格发布规范》。若商家单独对划线价格进行说明的，以商家的表述为准。\r\n</p>\r\n<p>\r\n	<img src=\"/j8830/public/upload/picture/20180908/fec63cfd4f9bda7464a815873f02d406.jpg\" alt=\"\" /> \r\n</p>', 'task2', '24');
INSERT INTO `xt_history` VALUES ('1125', '1', '100000', '1', '100000', '0', '1537014231', '-19.00', '0.00', '', '1', '0', '0', '0', '', '', '', '');
INSERT INTO `xt_history` VALUES ('1126', '1', '100000', '1', '100000', '61', '1537014234', '0.00', '0.00', '', '1', '0', '1', '0', '', '<h3 class=\"spec-title\" style=\"font-size:16px;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	任务一\r\n</h3>\r\n<p class=\"title\" style=\"color:#FE702F;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	划线价格\r\n</p>\r\n<p class=\"info\" style=\"color:#666666;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	指商品的专柜价、吊牌价、正品零售价、厂商指导价或该商品的曾经展示过的销售价等，<span style=\"color:#333333;font-weight:600;\">并非原价</span>，仅供参考。\r\n</p>\r\n<p class=\"title\" style=\"color:#FE702F;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	未划线价格\r\n</p>\r\n<p class=\"info\" style=\"color:#666666;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	指商品的<span style=\"color:#333333;font-weight:600;\">实时标价</span>，不因表述的差异改变性质。具体成交价格根据商品参加活动，或会员使用优惠券、积分等发生变化，最终以订单结算页价格为准。\r\n</p>\r\n<p class=\"info\" style=\"color:#666666;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	商家详情页（含主图）以图片或文字形式标注的一口价、促销价、优惠价等价格可能是在使用优惠券、满减或特定优惠活动和时段等情形下的价格，具体请以结算页面的标价、优惠条件或活动规则为准。\r\n</p>\r\n<p class=\"info\" style=\"color:#666666;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	此说明仅当出现价格比较时有效，具体请参见《淘宝价格发布规范》。若商家单独对划线价格进行说明的，以商家的表述为准。\r\n</p>\r\n<p>\r\n	<img src=\"/j8830/public/upload/picture/20180908/fec63cfd4f9bda7464a815873f02d406.jpg\" alt=\"\" /> \r\n</p>', 'task', '24');
INSERT INTO `xt_history` VALUES ('1127', '1', '100000', '1', '100000', '61', '1537014238', '0.00', '0.00', '', '1', '0', '0', '0', '', '<h3 class=\"spec-title\" style=\"font-size:16px;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	任务说明二\r\n</h3>\r\n<p class=\"title\" style=\"color:#FE702F;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	划线价格\r\n</p>\r\n<p class=\"info\" style=\"color:#666666;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	指商品的专柜价、吊牌价、正品零售价、厂商指导价或该商品的曾经展示过的销售价等，<span style=\"color:#333333;font-weight:600;\">并非原价</span>，仅供参考。\r\n</p>\r\n<p class=\"title\" style=\"color:#FE702F;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	未划线价格\r\n</p>\r\n<p class=\"info\" style=\"color:#666666;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	指商品的<span style=\"color:#333333;font-weight:600;\">实时标价</span>，不因表述的差异改变性质。具体成交价格根据商品参加活动，或会员使用优惠券、积分等发生变化，最终以订单结算页价格为准。\r\n</p>\r\n<p class=\"info\" style=\"color:#666666;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	商家详情页（含主图）以图片或文字形式标注的一口价、促销价、优惠价等价格可能是在使用优惠券、满减或特定优惠活动和时段等情形下的价格，具体请以结算页面的标价、优惠条件或活动规则为准。\r\n</p>\r\n<p class=\"info\" style=\"color:#666666;font-family:tahoma, arial, &quot;background-color:#FFFFFF;\">\r\n	此说明仅当出现价格比较时有效，具体请参见《淘宝价格发布规范》。若商家单独对划线价格进行说明的，以商家的表述为准。\r\n</p>\r\n<p>\r\n	<img src=\"/j8830/public/upload/picture/20180908/fec63cfd4f9bda7464a815873f02d406.jpg\" alt=\"\" /> \r\n</p>', 'task2', '');
INSERT INTO `xt_history` VALUES ('1128', '1', '100000', '1', '100000', '1', '1537014339', '4.00', '0.00', '', '1', '0', '0', '0', '', '', '', '');
INSERT INTO `xt_history` VALUES ('1129', '1', '100000', '1', '100000', '2', '1537924980', '20.00', '0.00', '', '1', '0', '0', '0', '', '', '', '');
INSERT INTO `xt_history` VALUES ('1130', '1', '100000', '1', '100000', '2', '1538017826', '20.00', '0.00', '', '1', '0', '0', '0', '', '', '', '');
INSERT INTO `xt_history` VALUES ('1131', '1', '100000', '1', '100000', '2', '1538100613', '20.00', '0.00', '', '1', '0', '0', '0', '', '', '', '');
INSERT INTO `xt_history` VALUES ('1132', '1', '100000', '1', '100000', '2', '1538982657', '20.00', '0.00', '', '1', '0', '0', '0', '', '', '', '');
INSERT INTO `xt_history` VALUES ('1133', '1', '100000', '1', '100000', '2', '1539050084', '20.00', '0.00', '', '1', '0', '0', '0', '', '', '', '');

-- -----------------------------
-- Table structure for `xt_hook`
-- -----------------------------
DROP TABLE IF EXISTS `xt_hook`;
CREATE TABLE `xt_hook` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `describe` varchar(255) NOT NULL COMMENT '描述',
  `addon_list` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子挂载的插件 ''，''分割',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COMMENT='钩子表';

-- -----------------------------
-- Records of `xt_hook`
-- -----------------------------
INSERT INTO `xt_hook` VALUES ('36', 'File', '文件上传钩子', 'File', '1', '0', '0');
INSERT INTO `xt_hook` VALUES ('37', 'Icon', '图标选择钩子', 'Icon', '1', '0', '0');
INSERT INTO `xt_hook` VALUES ('38', 'ArticleEditor', '富文本编辑器', 'Editor', '1', '0', '0');

-- -----------------------------
-- Table structure for `xt_member`
-- -----------------------------
DROP TABLE IF EXISTS `xt_member`;
CREATE TABLE `xt_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `nickname` char(50) NOT NULL DEFAULT '' COMMENT '昵称',
  `username` char(16) NOT NULL DEFAULT '' COMMENT '用户名',
  `name` varchar(255) NOT NULL,
  `password` char(32) NOT NULL DEFAULT '' COMMENT '密码',
  `password2` varchar(255) NOT NULL,
  `email` char(32) NOT NULL DEFAULT '' COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL DEFAULT '' COMMENT '用户手机',
  `card` varchar(255) NOT NULL,
  `card_d` varchar(255) NOT NULL,
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `red_packet_time` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户状态',
  `leader_id` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '上级会员ID',
  `address` text NOT NULL,
  `is_share_member` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否共享会员',
  `is_inside` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否为后台使用者',
  `user_id` varchar(255) NOT NULL,
  `cpzj` varchar(255) NOT NULL,
  `u_level` varchar(255) NOT NULL,
  `re_id` varchar(255) NOT NULL,
  `re_uid` varchar(255) NOT NULL,
  `re_path` varchar(255) NOT NULL,
  `re_level` varchar(255) NOT NULL,
  `re_nums` int(11) NOT NULL,
  `father_id` varchar(255) NOT NULL,
  `father_uid` varchar(255) NOT NULL,
  `p_path` varchar(255) NOT NULL DEFAULT ',',
  `p_level` varchar(255) NOT NULL DEFAULT '0',
  `is_pay` varchar(255) NOT NULL,
  `is_lock` varchar(255) NOT NULL,
  `day_feng` varchar(255) NOT NULL,
  `zone_a` int(11) NOT NULL,
  `zone_b` int(11) NOT NULL,
  `zone_c` int(11) NOT NULL,
  `l` int(11) NOT NULL,
  `xl` int(11) NOT NULL,
  `xxl` int(11) NOT NULL,
  `lr` int(11) NOT NULL,
  `treeplace` int(11) NOT NULL,
  `r` int(11) NOT NULL,
  `xr` int(11) NOT NULL,
  `xxr` int(11) NOT NULL,
  `qq` varchar(255) NOT NULL,
  `red_packet` int(11) NOT NULL,
  `b0` int(11) NOT NULL,
  `b1` int(11) NOT NULL,
  `b2` int(11) NOT NULL,
  `b3` int(11) NOT NULL,
  `b4` int(11) NOT NULL,
  `b5` int(11) NOT NULL,
  `b6` int(11) NOT NULL,
  `b7` int(11) NOT NULL,
  `b8` int(11) NOT NULL,
  `b9` int(11) NOT NULL,
  `b10` int(11) NOT NULL,
  `b11` int(11) NOT NULL,
  `b12` int(11) NOT NULL,
  `b13` int(11) NOT NULL,
  `b14` int(11) NOT NULL,
  `b15` int(11) NOT NULL,
  `b16` int(11) NOT NULL,
  `b17` int(11) NOT NULL,
  `b18` int(11) NOT NULL,
  `b19` int(11) NOT NULL,
  `b20` int(11) NOT NULL,
  `b21` int(11) NOT NULL,
  `b22` int(11) NOT NULL,
  `c0` int(11) NOT NULL,
  `c1` int(11) NOT NULL,
  `c2` int(11) NOT NULL,
  `c3` int(11) NOT NULL,
  `c4` int(11) NOT NULL,
  `c5` int(11) NOT NULL,
  `bank` varchar(255) NOT NULL,
  `agent` int(11) NOT NULL,
  `agent_level` int(11) NOT NULL,
  `weixin` varchar(255) NOT NULL,
  `alipay` varchar(255) NOT NULL,
  `re_money` int(11) NOT NULL,
  `team_money` int(11) NOT NULL,
  `is_agent` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `agent_uid` varchar(255) NOT NULL,
  `ad_bag` int(11) NOT NULL,
  `remainder_ad` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='会员表';

-- -----------------------------
-- Records of `xt_member`
-- -----------------------------
INSERT INTO `xt_member` VALUES ('1', '100000', '100000', '王', '1', '222222', '525630631@qq.com', '18555550710', '360822198305022623', '吉水县(区/县)', '1539052411', '1533267710', '1535299200', '1', '0', '', '0', '1', '100000', '10000', '1', '', '100000', '', '', '666', '', '', ',1,', '1', '1', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '0', '100066', '4', '100', '0', '0', '0', '4', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '4', '1', '1', '', '3888', '3888', '2', '0', '', '2', '0');

-- -----------------------------
-- Table structure for `xt_menu`
-- -----------------------------
DROP TABLE IF EXISTS `xt_menu`;
CREATE TABLE `xt_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '菜单名称',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `module` char(20) NOT NULL DEFAULT '' COMMENT '模块',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `is_hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `icon` char(30) NOT NULL DEFAULT '' COMMENT '图标',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=248 DEFAULT CHARSET=utf8 COMMENT='菜单表';

-- -----------------------------
-- Records of `xt_menu`
-- -----------------------------
INSERT INTO `xt_menu` VALUES ('1', '我的信息', '0', '0', 'admin', 'index/index', '1', 'fa-home', '1', '1536570092', '0');
INSERT INTO `xt_menu` VALUES ('16', '会员管理', '0', '3', 'admin', 'member/index', '1', 'fa-users', '1', '1537967828', '0');
INSERT INTO `xt_menu` VALUES ('17', '会员列表', '16', '1', 'admin', 'member/memberlist', '0', 'fa-list', '1', '1495272875', '0');
INSERT INTO `xt_menu` VALUES ('18', '会员注册', '16', '2', 'admin', 'index/index/member_add', '0', 'fa-user-plus', '1', '1536570487', '0');
INSERT INTO `xt_menu` VALUES ('27', '权限管理', '16', '3', 'admin', 'auth/grouplist', '1', 'fa-key', '1', '1536570394', '0');
INSERT INTO `xt_menu` VALUES ('32', '权限组编辑', '27', '0', 'admin', 'auth/groupedit', '1', '', '1', '1492002620', '0');
INSERT INTO `xt_menu` VALUES ('34', '授权', '27', '0', 'admin', 'auth_manager/group', '1', '', '1', '0', '0');
INSERT INTO `xt_menu` VALUES ('35', '菜单授权', '27', '0', 'admin', 'auth/menuauth', '1', '', '1', '1492095653', '0');
INSERT INTO `xt_menu` VALUES ('36', '会员授权', '27', '0', 'admin', 'auth_manager/memberaccess', '1', '', '1', '0', '0');
INSERT INTO `xt_menu` VALUES ('68', '后台管理', '0', '7', 'admin', 'config/group', '0', 'fa-wrench', '1', '1537879226', '0');
INSERT INTO `xt_menu` VALUES ('69', '系统设置', '0', '10', 'admin', 'config/setting', '0', 'fa-cogs', '1', '1536570294', '0');
INSERT INTO `xt_menu` VALUES ('70', '配置管理', '68', '2', 'admin', 'config/index', '0', 'fa-cog', '-1', '1534495080', '0');
INSERT INTO `xt_menu` VALUES ('71', '配置编辑', '70', '0', 'admin', 'config/configedit', '1', '', '1', '1491674180', '0');
INSERT INTO `xt_menu` VALUES ('72', '配置删除', '70', '0', 'admin', 'config/configDel', '1', '', '1', '1491674201', '0');
INSERT INTO `xt_menu` VALUES ('73', '配置添加', '70', '0', 'admin', 'config/configadd', '0', 'fa-plus', '1', '1491666947', '0');
INSERT INTO `xt_menu` VALUES ('75', '菜单管理', '68', '5', 'admin', 'menu/index', '0', 'fa-th-large', '1', '1537879243', '0');
INSERT INTO `xt_menu` VALUES ('98', '菜单编辑', '75', '0', 'admin', 'menu/menuedit', '1', '', '1', '1512459021', '0');
INSERT INTO `xt_menu` VALUES ('108', '修改密码', '17', '0', 'admin', 'user/update_password', '1', '', '1', '0', '0');
INSERT INTO `xt_menu` VALUES ('109', '修改昵称', '17', '0', 'admin', 'user/update_nickname', '1', '', '1', '1491578211', '0');
INSERT INTO `xt_menu` VALUES ('124', '菜单列表', '75', '0', 'admin', 'menu/menulist', '0', 'fa-list', '1', '1534495527', '0');
INSERT INTO `xt_menu` VALUES ('125', '菜单添加', '75', '0', 'admin', 'menu/menuadd', '0', 'fa-plus', '1', '1491318307', '0');
INSERT INTO `xt_menu` VALUES ('126', '配置列表', '70', '0', 'admin', 'config/configlist', '0', 'fa-list', '1', '1491666890', '1491666890');
INSERT INTO `xt_menu` VALUES ('127', '菜单状态', '75', '0', 'admin', 'menu/setstatus', '1', '', '1', '1534495462', '1491674128');
INSERT INTO `xt_menu` VALUES ('128', '权限组添加', '27', '0', 'admin', 'auth/groupadd', '1', '', '1', '1492002635', '1492002635');
INSERT INTO `xt_menu` VALUES ('134', '授权', '17', '0', 'admin', 'member/memberauth', '1', '', '1', '1492238568', '1492101426');
INSERT INTO `xt_menu` VALUES ('135', '回收站', '68', '4', 'admin', 'trash/trashlist', '0', ' fa-recycle', '-1', '1534495127', '1492311462');
INSERT INTO `xt_menu` VALUES ('136', '回收站数据', '135', '0', 'admin', 'trash/trashdatalist', '1', 'fa-database', '1', '1492319477', '1492319392');
INSERT INTO `xt_menu` VALUES ('140', '服务管理', '68', '5', 'admin', 'admin/service/servicelist', '1', 'fa-server', '1', '1536918795', '1492352972');
INSERT INTO `xt_menu` VALUES ('141', '插件管理', '68', '6', 'admin', 'addon/index', '1', 'fa-puzzle-piece', '1', '1535971039', '1492427605');
INSERT INTO `xt_menu` VALUES ('142', '钩子列表', '141', '0', 'admin', 'addon/hooklist', '0', 'fa-anchor', '1', '1492427665', '1492427665');
INSERT INTO `xt_menu` VALUES ('143', '插件列表', '141', '0', 'admin', 'addon/addonlist', '0', 'fa-list', '1', '1492428116', '1492427838');
INSERT INTO `xt_menu` VALUES ('144', '公告管理', '68', '4', 'admin', 'article/index', '1', 'fa-edit', '1', '1536568258', '1492480187');
INSERT INTO `xt_menu` VALUES ('145', '文章列表', '144', '0', 'admin', 'article/articlelist', '0', 'fa-list', '1', '1492480245', '1492480245');
INSERT INTO `xt_menu` VALUES ('146', '文章分类', '144', '0', 'admin', 'article/articlecategorylist', '0', 'fa-list', '1', '1492480359', '1492480342');
INSERT INTO `xt_menu` VALUES ('147', '文章分类编辑', '146', '0', 'admin', 'article/articlecategoryedit', '1', '', '1', '1492485294', '1492485294');
INSERT INTO `xt_menu` VALUES ('148', '分类添加', '144', '0', 'admin', 'article/articlecategoryadd', '0', 'fa-plus', '1', '1492486590', '1492486576');
INSERT INTO `xt_menu` VALUES ('149', '文章添加', '144', '0', 'admin', 'article/articleadd', '0', 'fa-plus', '1', '1492518453', '1492518453');
INSERT INTO `xt_menu` VALUES ('150', '文章编辑', '145', '0', 'admin', 'article/articleedit', '1', '', '1', '1492879589', '1492879589');
INSERT INTO `xt_menu` VALUES ('151', '插件安装', '143', '0', 'admin', 'addon/addoninstall', '1', '', '1', '1492879763', '1492879763');
INSERT INTO `xt_menu` VALUES ('152', '插件卸载', '143', '0', 'admin', 'addon/addonuninstall', '1', '', '1', '1492879789', '1492879789');
INSERT INTO `xt_menu` VALUES ('153', '文章删除', '145', '0', 'admin', 'article/articledel', '1', '', '1', '1492879960', '1492879960');
INSERT INTO `xt_menu` VALUES ('154', '文章分类删除', '146', '0', 'admin', 'article/articlecategorydel', '1', '', '1', '1492879995', '1492879995');
INSERT INTO `xt_menu` VALUES ('156', '驱动安装', '140', '0', 'admin', 'service/driverinstall', '1', '', '1', '1536411965', '1502267009');
INSERT INTO `xt_menu` VALUES ('157', '接口管理', '68', '5', 'admin', 'api/index', '1', 'fa fa-book', '1', '1536918823', '1504000434');
INSERT INTO `xt_menu` VALUES ('158', '分组管理', '157', '0', 'admin', 'api/apigrouplist', '0', 'fa fa-fw fa-th-list', '1', '1504000977', '1504000723');
INSERT INTO `xt_menu` VALUES ('159', '分组添加', '157', '0', 'admin', 'api/apigroupadd', '0', 'fa fa-fw fa-plus', '1', '1504004646', '1504004646');
INSERT INTO `xt_menu` VALUES ('160', '分组编辑', '157', '0', 'admin', 'api/apigroupedit', '1', '', '1', '1504004710', '1504004710');
INSERT INTO `xt_menu` VALUES ('161', '分组删除', '157', '0', 'admin', 'api/apigroupdel', '1', '', '1', '1504004732', '1504004732');
INSERT INTO `xt_menu` VALUES ('162', '接口列表', '157', '0', 'admin', 'api/apilist', '0', 'fa fa-fw fa-th-list', '1', '1504172326', '1504172326');
INSERT INTO `xt_menu` VALUES ('163', '接口添加', '157', '0', 'admin', 'api/apiadd', '0', 'fa fa-fw fa-plus', '1', '1504172352', '1504172352');
INSERT INTO `xt_menu` VALUES ('164', '接口编辑', '157', '0', 'admin', 'api/apiedit', '1', '', '1', '1504172414', '1504172414');
INSERT INTO `xt_menu` VALUES ('165', '接口删除', '157', '0', 'admin', 'api/apidel', '1', '', '1', '1504172435', '1504172435');
INSERT INTO `xt_menu` VALUES ('166', '优化维护', '68', '6', 'admin', 'maintain/index', '0', 'fa-legal', '1', '1537879280', '1505387256');
INSERT INTO `xt_menu` VALUES ('167', 'SEO管理', '166', '0', 'admin', 'seo/seolist', '0', 'fa-list', '1', '1506309608', '1505387303');
INSERT INTO `xt_menu` VALUES ('168', '数据库', '0', '8', 'admin', 'maintain/database', '0', 'fa-database', '1', '1536918913', '1505539394');
INSERT INTO `xt_menu` VALUES ('169', '数据备份', '168', '0', 'admin', 'database/databackup', '0', 'fa-download', '1', '1506309900', '1505539428');
INSERT INTO `xt_menu` VALUES ('170', '数据还原', '168', '11', 'admin', 'database/datarestore', '0', 'fa-exchange', '1', '1536918969', '1505539492');
INSERT INTO `xt_menu` VALUES ('171', '文件清理', '166', '0', 'admin', 'fileclean/cleanlist', '0', 'fa-file', '1', '1506310152', '1505788517');
INSERT INTO `xt_menu` VALUES ('174', '行为日志', '166', '0', 'admin', 'log/loglist', '0', 'fa-street-view', '1', '1507201516', '1507200836');
INSERT INTO `xt_menu` VALUES ('176', '执行记录', '166', '0', 'admin', 'exelog/index', '0', 'fa-list-alt', '1', '1509433351', '1509433351');
INSERT INTO `xt_menu` VALUES ('177', '全局范围', '176', '0', 'admin', 'exelog/applist', '0', 'fa-tags', '1', '1509433570', '1509433570');
INSERT INTO `xt_menu` VALUES ('178', '接口范围', '176', '0', 'admin', 'exelog/apilist', '0', 'fa-tag', '1', '1509433591', '1509433591');
INSERT INTO `xt_menu` VALUES ('198', '关系图', '0', '5', 'admin', 'statistic/index', '1', 'fa-connectdevelop', '1', '1536917934', '1512638014');
INSERT INTO `xt_menu` VALUES ('199', '权限等级', '198', '0', 'admin', 'statistic/membertree', '1', 'fa-users', '1', '1535966149', '1512638868');
INSERT INTO `xt_menu` VALUES ('200', '浏览器统计', '203', '0', 'admin', 'statistic/performerfacility', '0', 'fa-edge', '1', '1533865293', '1512727672');
INSERT INTO `xt_menu` VALUES ('201', '执行速度', '203', '0', 'admin', 'statistic/exespeed', '0', 'fa-fighter-jet', '1', '1533865324', '1512787226');
INSERT INTO `xt_menu` VALUES ('202', '会员增长', '203', '0', 'admin', 'statistic/membergrowth', '0', 'fa-line-chart', '1', '1533865366', '1512801997');
INSERT INTO `xt_menu` VALUES ('203', '友情链接', '75', '7', 'admin', 'blogroll/index', '0', 'fa-link', '1', '1534495422', '1520505717');
INSERT INTO `xt_menu` VALUES ('204', '链接列表', '203', '0', 'admin', 'blogroll/blogrolllist', '0', 'fa-th', '1', '1520505777', '1520505777');
INSERT INTO `xt_menu` VALUES ('205', '链接添加', '203', '0', 'admin', 'blogroll/blogrolladd', '0', 'fa-plus', '1', '1520505826', '1520505826');
INSERT INTO `xt_menu` VALUES ('206', '链接编辑', '203', '0', 'admin', 'blogroll/blogrolledit', '1', 'fa-edit', '1', '1520505863', '1520505863');
INSERT INTO `xt_menu` VALUES ('207', '链接删除', '203', '0', 'admin', 'blogroll/blogrolldel', '1', 'fa-minus', '1', '1520505889', '1520505889');
INSERT INTO `xt_menu` VALUES ('208', '菜单排序', '75', '0', 'admin', 'menu/setsort', '1', '', '1', '1520506696', '1520506696');
INSERT INTO `xt_menu` VALUES ('209', '货币流向', '0', '9', 'admin', 'statistic/historyList', '1', 'fa-reorder', '1', '1539050103', '1533349314');
INSERT INTO `xt_menu` VALUES ('210', '接点图', '198', '0', 'admin', 'statistic/Tree3', '1', 'fa-users', '1', '1536553566', '1533353131');
INSERT INTO `xt_menu` VALUES ('211', '购物商城', '0', '6', 'admin', 'index/index/index', '1', 'fa-archive', '1', '1536570177', '1533644958');
INSERT INTO `xt_menu` VALUES ('212', '产品管理', '0', '1', 'admin', 'shopadmin/index', '0', 'fa-cogs', '1', '1536570226', '1533700168');
INSERT INTO `xt_menu` VALUES ('213', '产品浏览', '211', '0', 'admin', 'index/index/index', '0', 'fa-cart-plus', '1', '1535942311', '1533700412');
INSERT INTO `xt_menu` VALUES ('214', '产品列表', '212', '0', 'admin', 'shopadmin/shoplist', '0', 'fa-align-justify', '1', '1533708430', '1533701028');
INSERT INTO `xt_menu` VALUES ('215', '产品分类', '212', '1', 'admin', 'shopadmin/shopcategorylist', '0', 'fa-list', '1', '1533708447', '1533701057');
INSERT INTO `xt_menu` VALUES ('216', '分类添加', '212', '3', 'admin', 'shopadmin/shopcategoryadd', '0', 'fa-plus', '1', '1533708455', '1533701084');
INSERT INTO `xt_menu` VALUES ('217', '产品添加', '212', '5', 'admin', 'shopadmin/shopadd', '0', 'fa-plus', '1', '1533708462', '1533701124');
INSERT INTO `xt_menu` VALUES ('218', '订单管理', '211', '0', 'admin', 'shop/order_list', '0', 'fa-home', '1', '1534585512', '1533862708');
INSERT INTO `xt_menu` VALUES ('219', '购物车', '218', '0', 'admin', 'shop/car_list', '0', 'fa-shopping-cart', '-1', '1534585375', '1533862794');
INSERT INTO `xt_menu` VALUES ('220', '我的订单', '218', '0', 'admin', 'shop/order_list', '0', 'fa-align-left', '-1', '1534585371', '1533862853');
INSERT INTO `xt_menu` VALUES ('221', '推荐图', '198', '0', 'admin', 'vip/tree1', '0', 'fa-pagelines', '1', '1535967780', '1533884570');
INSERT INTO `xt_menu` VALUES ('222', '清空数据库', '170', '0', 'admin', 'member/clean', '0', 'fa-leaf', '-1', '1534478660', '1534476785');
INSERT INTO `xt_menu` VALUES ('223', '会员充值', '16', '0', 'admin', 'shopadmin/charge', '0', 'fa-jpy', '1', '1536029508', '1534823178');
INSERT INTO `xt_menu` VALUES ('224', '会员提现', '16', '0', 'admin', 'shopadmin/drawal', '0', '', '1', '1534989255', '1534989255');
INSERT INTO `xt_menu` VALUES ('225', '个人设置', '0', '1', 'admin', 'index/user/inde', '1', 'fa-user', '1', '1536568298', '1535966736');
INSERT INTO `xt_menu` VALUES ('226', '资料修改', '225', '0', 'admin', 'user/my_data', '0', '', '1', '1535969069', '1535966788');
INSERT INTO `xt_menu` VALUES ('227', '注册账户', '229', '0', 'admin', 'index/member_add', '1', '', '0', '1536563044', '1535966876');
INSERT INTO `xt_menu` VALUES ('228', '二维码分享', '229', '0', 'admin', 'vip/qcode', '0', '', '1', '1536195197', '1535966957');
INSERT INTO `xt_menu` VALUES ('229', '会员中心', '0', '2', 'admin', 'vip', '1', '', '1', '1536568310', '1535969770');
INSERT INTO `xt_menu` VALUES ('230', '提现', '242', '2', 'admin', 'vip/withdrawadd', '0', '', '1', '1536194963', '1535969850');
INSERT INTO `xt_menu` VALUES ('231', '转账', '242', '1', 'admin', 'vip/transfer', '0', '', '1', '1536194934', '1535969902');
INSERT INTO `xt_menu` VALUES ('232', '流水明细', '242', '0', 'admin', 'vip/record', '0', '', '1', '1536549578', '1535970098');
INSERT INTO `xt_menu` VALUES ('233', '新闻公告', '243', '0', 'admin', 'user/article_list', '0', '', '1', '1536194999', '1535971273');
INSERT INTO `xt_menu` VALUES ('234', '网页留言', '0', '3', 'admin', 'mail', '0', '', '1', '1538027479', '1535971624');
INSERT INTO `xt_menu` VALUES ('235', '收件箱', '234', '0', 'admin', 'vip/inmsg', '0', '', '1', '1536197898', '1535971652');
INSERT INTO `xt_menu` VALUES ('236', '发件箱', '234', '0', 'admin', 'vip/outmsg', '1', '', '1', '1538027444', '1535971664');
INSERT INTO `xt_menu` VALUES ('237', '写邮件', '234', '0', 'admin', 'vip/writemsg', '1', '', '1', '1538027451', '1535971675');
INSERT INTO `xt_menu` VALUES ('238', '奖金明细', '242', '0', 'admin', 'vip/bonusList', '0', '', '1', '1536194918', '1535972688');
INSERT INTO `xt_menu` VALUES ('239', '充值', '242', '1', 'admin', 'vip/charge_member', '0', '', '1', '1536194951', '1536025887');
INSERT INTO `xt_menu` VALUES ('240', '会员激活', '229', '0', 'admin', 'vip/memberList', '1', '', '0', '1536563027', '1536030963');
INSERT INTO `xt_menu` VALUES ('241', '配置列表', '75', '0', 'admin', 'config/configlist', '0', '', '1', '1536052149', '1536052149');
INSERT INTO `xt_menu` VALUES ('242', '会员财务', '0', '3', 'admin', '', '1', '', '1', '1536568372', '1536194839');
INSERT INTO `xt_menu` VALUES ('243', '会员资讯', '0', '4', 'admin', '', '1', '', '1', '1536568245', '1536194878');
INSERT INTO `xt_menu` VALUES ('244', '任务', '242', '10', 'admin', 'vip/task_member', '0', '', '-1', '1536371334', '1536284638');
INSERT INTO `xt_menu` VALUES ('245', '会员任务', '16', '6', 'admin', 'shopadmin/task', '0', '', '1', '1536284783', '1536284783');
INSERT INTO `xt_menu` VALUES ('246', '任务提交', '242', '0', 'admin', 'vip/task_member_submit', '0', '', '-1', '1536371323', '1536294967');
INSERT INTO `xt_menu` VALUES ('247', '任务记录', '242', '0', 'admin', 'vip/task_member_record', '0', '', '-1', '1536371328', '1536294989');

-- -----------------------------
-- Table structure for `xt_msg`
-- -----------------------------
DROP TABLE IF EXISTS `xt_msg`;
CREATE TABLE `xt_msg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `f_uid` int(11) NOT NULL DEFAULT '0',
  `f_user_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `s_uid` int(11) NOT NULL DEFAULT '0',
  `s_user_id` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `f_time` int(11) NOT NULL DEFAULT '0',
  `f_del` smallint(3) NOT NULL DEFAULT '0',
  `s_del` smallint(3) NOT NULL DEFAULT '0',
  `f_read` smallint(3) NOT NULL DEFAULT '0',
  `s_read` smallint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=58 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- -----------------------------
-- Records of `xt_msg`
-- -----------------------------
INSERT INTO `xt_msg` VALUES ('27', '1', '100000', '1', '100000', 'werwerwer', 'werwerwerwe', '1536197094', '0', '1', '1', '1');
INSERT INTO `xt_msg` VALUES ('28', '1', '100000', '1', '100000', '', '', '1536199255', '1', '1', '0', '0');
INSERT INTO `xt_msg` VALUES ('29', '1', '100000', '1', '100000', '认同的人', '儿童额', '1536199286', '0', '1', '0', '1');
INSERT INTO `xt_msg` VALUES ('30', '1', '100000', '1', '100000', '回复：werwerwer', '随碟附送的', '1536201689', '0', '1', '0', '1');
INSERT INTO `xt_msg` VALUES ('31', '1', '100000', '1', '100000', '回复：认同的人', '人味儿', '1536202053', '1', '1', '0', '0');
INSERT INTO `xt_msg` VALUES ('32', '1', '100000', '1', '100000', '回复：回复：werwerwer', '动态 ', '1536202068', '1', '1', '0', '0');
INSERT INTO `xt_msg` VALUES ('33', '1', '100000', '1', '100000', '333', '6666', '1538027256', '0', '1', '0', '0');
INSERT INTO `xt_msg` VALUES ('34', '1', '100000', '1', '100000', '333', '6666', '1538027258', '0', '1', '0', '0');
INSERT INTO `xt_msg` VALUES ('35', '1', '100000', '1', '100000', '333', '6666', '1538027261', '0', '1', '0', '0');
INSERT INTO `xt_msg` VALUES ('36', '1', '100000', '1', '100000', '333', '6666', '1538027264', '0', '1', '0', '1');
INSERT INTO `xt_msg` VALUES ('37', '1', '100000', '1', '100000', '333', '6666', '1538027267', '0', '1', '0', '1');
INSERT INTO `xt_msg` VALUES ('38', '1', '100000', '1', '100000', '333', '6666', '1538027271', '0', '1', '0', '1');
INSERT INTO `xt_msg` VALUES ('39', '1', '100000', '1', '100000', '333', '姓名：李 ，\r\n        电话：12345667\r\n        邮箱：777.163@163.com\r\n        内容：55555\r\n        ', '1538027666', '0', '1', '0', '1');
INSERT INTO `xt_msg` VALUES ('40', '1', '100000', '1', '100000', '访客留言', '姓名： ，\r\n        电话：\r\n        邮箱：\r\n        内容：', '1538960897', '0', '1', '0', '0');
INSERT INTO `xt_msg` VALUES ('41', '1', '100000', '1', '100000', '访客留言', '姓名： ，\r\n        电话：\r\n        邮箱：\r\n        内容：', '1538962847', '0', '1', '0', '0');
INSERT INTO `xt_msg` VALUES ('42', '1', '100000', '1', '100000', '访客留言', '姓名： ，\r\n        电话：\r\n        邮箱：\r\n        内容：', '1538963456', '0', '1', '0', '0');
INSERT INTO `xt_msg` VALUES ('43', '1', '100000', '1', '100000', '访客留言', '姓名： ，\r\n        电话：\r\n        邮箱：\r\n        内容：', '1538966479', '0', '1', '0', '0');
INSERT INTO `xt_msg` VALUES ('44', '1', '100000', '1', '100000', '访客留言', '姓名： ，\r\n        电话：\r\n        邮箱：\r\n        内容：', '1538972248', '0', '1', '0', '0');
INSERT INTO `xt_msg` VALUES ('45', '1', '100000', '1', '100000', '访客留言', '姓名： ，\r\n        电话：\r\n        邮箱：\r\n        内容：', '1538972310', '0', '1', '0', '0');
INSERT INTO `xt_msg` VALUES ('46', '1', '100000', '1', '100000', '访客留言', '姓名： ，\r\n        电话：\r\n        邮箱：\r\n        内容：', '1538972313', '0', '1', '0', '0');
INSERT INTO `xt_msg` VALUES ('47', '1', '100000', '1', '100000', '访客留言', '姓名： ，\r\n        电话：\r\n        邮箱：\r\n        内容：', '1538972319', '0', '1', '0', '0');
INSERT INTO `xt_msg` VALUES ('48', '1', '100000', '1', '100000', '访客留言', '姓名： ，\r\n        电话：\r\n        邮箱：\r\n        内容：', '1538972400', '0', '1', '0', '0');
INSERT INTO `xt_msg` VALUES ('49', '1', '100000', '1', '100000', '访客留言', '姓名： ，\r\n        电话：\r\n        邮箱：\r\n        内容：', '1538972403', '0', '1', '0', '0');
INSERT INTO `xt_msg` VALUES ('50', '1', '100000', '1', '100000', '访客留言', '姓名： ，\r\n        电话：\r\n        邮箱：\r\n        内容：', '1538972439', '0', '1', '0', '0');
INSERT INTO `xt_msg` VALUES ('51', '1', '100000', '1', '100000', '访客留言', '姓名： ，\r\n        电话：\r\n        邮箱：\r\n        内容：', '1538972443', '0', '1', '0', '0');
INSERT INTO `xt_msg` VALUES ('52', '1', '100000', '1', '100000', '访客留言', '姓名： ，\r\n        电话：\r\n        邮箱：\r\n        内容：', '1538972454', '0', '1', '0', '0');
INSERT INTO `xt_msg` VALUES ('53', '1', '100000', '1', '100000', '访客留言', '姓名： ，\r\n        电话：\r\n        邮箱：\r\n        内容：', '1538972497', '0', '1', '0', '0');
INSERT INTO `xt_msg` VALUES ('54', '1', '100000', '1', '100000', '访客留言', '姓名： ，\r\n        电话：\r\n        邮箱：\r\n        内容：', '1538972505', '0', '1', '0', '0');
INSERT INTO `xt_msg` VALUES ('55', '1', '100000', '1', '100000', '访客留言', '姓名： ，\r\n        电话：\r\n        邮箱：\r\n        内容：', '1538972564', '0', '1', '0', '0');
INSERT INTO `xt_msg` VALUES ('56', '1', '100000', '1', '100000', '访客留言', '姓名： ，\r\n        电话：\r\n        邮箱：\r\n        内容：', '1538972683', '0', '1', '0', '1');
INSERT INTO `xt_msg` VALUES ('57', '1', '100000', '1', '100000', '访客留言', '姓名：123 ，\r\n        电话：123\r\n        邮箱：123\r\n        内容：123', '1539004898', '0', '0', '0', '1');

-- -----------------------------
-- Table structure for `xt_picture`
-- -----------------------------
DROP TABLE IF EXISTS `xt_picture`;
CREATE TABLE `xt_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '图片名称',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='图片表';

-- -----------------------------
-- Records of `xt_picture`
-- -----------------------------
INSERT INTO `xt_picture` VALUES ('17', '0e81916fc1710d6f8126103ac2a60604.jpg', '20180908/0e81916fc1710d6f8126103ac2a60604.jpg', '', '1830f6e2c5329b60bbd9814211b3ad131cfa3f4c', '1536382199', '0', '1');
INSERT INTO `xt_picture` VALUES ('18', '261efea42f8b63c020908111d7162b16.png', '20180908/261efea42f8b63c020908111d7162b16.png', '', 'f7a067c2ab59d1bf224c5bbfc52ec5ce02ab9614', '1536382222', '0', '1');
INSERT INTO `xt_picture` VALUES ('19', '56b4e53a7dd8e70a9e691500734fe23b.png', '20180908/56b4e53a7dd8e70a9e691500734fe23b.png', '', '4bf25f965b87c27ee9eec20fc2fcdd9171018477', '1536386327', '0', '1');
INSERT INTO `xt_picture` VALUES ('20', 'fec63cfd4f9bda7464a815873f02d406.jpg', '20180908/fec63cfd4f9bda7464a815873f02d406.jpg', '', '57e1e2096c439547f014e73cf00795eac4e58d73', '1536392281', '0', '1');
INSERT INTO `xt_picture` VALUES ('21', '94c1ee52bde2ac3875595df1bc89894b.jpg', '20180908/94c1ee52bde2ac3875595df1bc89894b.jpg', '', 'c5e2a4026ca4f229b94d5f1f1980b0d0bf31ed85', '1536402051', '0', '1');
INSERT INTO `xt_picture` VALUES ('22', 'a4a907fee61a69c44c917f274c325208.png', '20180908/a4a907fee61a69c44c917f274c325208.png', '', '4b5e606dedd374ff18ab865bc0a7f754b2d15fe8', '1536404207', '0', '1');
INSERT INTO `xt_picture` VALUES ('23', 'a280b315c568700f3e99c233cf6921ef.png', '20180908/a280b315c568700f3e99c233cf6921ef.png', '', 'c7c95f859b432c47aa9a3cda210eccd9f759f52a', '1536409228', '0', '1');
INSERT INTO `xt_picture` VALUES ('24', 'd00cc9b612894a1a5db4bf77e33c70b3.png', '20180912/d00cc9b612894a1a5db4bf77e33c70b3.png', '', 'c50e49bf7a6a9f6f71bf3660897ddaa2b3e43a97', '1536740822', '0', '1');
INSERT INTO `xt_picture` VALUES ('25', '94f7e538fafe28c06e220eb89c31dc09.png', '20180914/94f7e538fafe28c06e220eb89c31dc09.png', '', '87c06ea47b9d6a2ba815f8e1cd041bac2acb3195', '1536887030', '0', '1');
INSERT INTO `xt_picture` VALUES ('26', '32a200af9cf5afdcf6f340cb9642d075.jpg', '20180915/32a200af9cf5afdcf6f340cb9642d075.jpg', '', '309e3e0a7068c452d2e58b10baa7aa79bc7995be', '1536972511', '0', '1');
INSERT INTO `xt_picture` VALUES ('27', 'b887d31fc5307421988745ed2286637d.jpg', '20180915/b887d31fc5307421988745ed2286637d.jpg', '', '5b3eab9ab7d1f24487eae4215d3c02c4c037b948', '1536972583', '0', '1');
INSERT INTO `xt_picture` VALUES ('28', 'e7d19a08f5e97853089d3f251438cb8c.jpg', '20180925/e7d19a08f5e97853089d3f251438cb8c.jpg', '', 'b08afea4a5e14d990684c25efce7d7acbeab97a3', '1537883310', '0', '1');
INSERT INTO `xt_picture` VALUES ('29', '788720bf24e514af5381b15874a977b6.jpg', '20180925/788720bf24e514af5381b15874a977b6.jpg', '', '102d95ef6afddccccc1a9e15d1f1a0fa31b87fd5', '1537883576', '0', '1');
INSERT INTO `xt_picture` VALUES ('30', 'f0e021fc84f4e7847bad008ac68ca19b.jpg', '20180925/f0e021fc84f4e7847bad008ac68ca19b.jpg', '', '90c976b1d7e1957f5e923c1336fdaad8466688c6', '1537884428', '0', '1');
INSERT INTO `xt_picture` VALUES ('31', 'b7e54f4d882b2d42dff30e5c0c4a6215.jpg', '20180926/b7e54f4d882b2d42dff30e5c0c4a6215.jpg', '', 'f6bfe2c73db3fe32ad57470f14f060077d871e0b', '1537930479', '0', '1');
INSERT INTO `xt_picture` VALUES ('32', '24210b35bb5e58f3fbb35db3560d19bc.jpg', '20180926/24210b35bb5e58f3fbb35db3560d19bc.jpg', '', '6db40928bed388ae1c5cf73c97e81e7f35994d90', '1537930815', '0', '1');
INSERT INTO `xt_picture` VALUES ('33', 'b3cef41b718bad740933c31b08f0faf2.jpg', '20180926/b3cef41b718bad740933c31b08f0faf2.jpg', '', '4b767c9632c75f8c1f944b5ce9801746b7052798', '1537930831', '0', '1');
INSERT INTO `xt_picture` VALUES ('34', '736ce78b4e0be544c56d1d4fb6c84f39.jpg', '20180926/736ce78b4e0be544c56d1d4fb6c84f39.jpg', '', '4da44f8fd53a145ad9a90328cf9b7f6b8ee4a44e', '1537930850', '0', '1');
INSERT INTO `xt_picture` VALUES ('35', 'edc69a3813a3153d91c04d51634032bd.jpg', '20180926/edc69a3813a3153d91c04d51634032bd.jpg', '', 'a778cf4eb4394bd6875682e2caf2c0ea4df976d9', '1537930872', '0', '1');
INSERT INTO `xt_picture` VALUES ('36', '684a5f6050803c0fbb4ccb7e0c060715.jpg', '20180926/684a5f6050803c0fbb4ccb7e0c060715.jpg', '', 'e2fa5f0dabe8ac1269c5f89dbcfa894170e047a1', '1537930890', '0', '1');
INSERT INTO `xt_picture` VALUES ('37', '07a9772a0714d6b83084464a5c4eda27.jpg', '20180926/07a9772a0714d6b83084464a5c4eda27.jpg', '', '12fb9ca1aed2e057047ab711dfa9b06ad0e0cd2a', '1537931647', '0', '1');
INSERT INTO `xt_picture` VALUES ('38', '0ec8c3c04a6330bdf002c56bcdeb1114.jpg', '20180926/0ec8c3c04a6330bdf002c56bcdeb1114.jpg', '', '8fbd4b18ad3ca8a220ff03a76f8b0a727dcd7d89', '1537931691', '0', '1');
INSERT INTO `xt_picture` VALUES ('39', '2db503f5dae7aaef0fdae4c36563f183.jpg', '20180926/2db503f5dae7aaef0fdae4c36563f183.jpg', '', 'eaa73191dbf41b3d23f450f899c014f9a56d7810', '1537931712', '0', '1');
INSERT INTO `xt_picture` VALUES ('40', '9af1bf04e46e91675c0a2b71f39cb191.jpg', '20180926/9af1bf04e46e91675c0a2b71f39cb191.jpg', '', 'd2e0d091ce30cbd498bff5f94718242312f633ba', '1537932870', '0', '1');
INSERT INTO `xt_picture` VALUES ('41', '77e20d0cad08919d4a5bda53451bf273.jpg', '20180926/77e20d0cad08919d4a5bda53451bf273.jpg', '', 'f0b1b20ca11b15182f955df50c2fad70cff3b988', '1537971763', '0', '1');
INSERT INTO `xt_picture` VALUES ('42', 'e7fe457db01474ff399d5f432c3888e9.jpg', '20180926/e7fe457db01474ff399d5f432c3888e9.jpg', '', 'e6e9be52a68e4979acd2a04e97f8502706800bca', '1537971844', '0', '1');
INSERT INTO `xt_picture` VALUES ('43', '6e037605d7c7d1ee9b3768e4ca8824c8.jpg', '20181008/6e037605d7c7d1ee9b3768e4ca8824c8.jpg', '', '9c86bdc6efc6870a84d1e533cedd3a3b373630d6', '1538989367', '0', '1');
INSERT INTO `xt_picture` VALUES ('44', '65ed3cdf6f36a45bdf90ab79c8cbae60.jpg', '20181008/65ed3cdf6f36a45bdf90ab79c8cbae60.jpg', '', 'a0068bb06f312efab829826704516b7ab6ff3069', '1538989374', '0', '1');
INSERT INTO `xt_picture` VALUES ('45', '54d01cf395520a38930d1ee044574c70.jpg', '20181008/54d01cf395520a38930d1ee044574c70.jpg', '', '82f63b928f8cf9f2c15893f6794c48e1b0101c5b', '1539001762', '0', '1');
INSERT INTO `xt_picture` VALUES ('46', 'c0f41de88ef0780c40eaebfff8251bac.png', '20181008/c0f41de88ef0780c40eaebfff8251bac.png', '', '0aa414cea134c35ba6b994c8c87bd30c1d941203', '1539001900', '0', '1');
INSERT INTO `xt_picture` VALUES ('47', 'baa3a20ae686d0167437a082fec25edc.jpg', '20181008/baa3a20ae686d0167437a082fec25edc.jpg', '', '955e3a20d17c527851d602398658e57ed654ea39', '1539002619', '0', '1');
INSERT INTO `xt_picture` VALUES ('48', '88bc2c114b9698ded0ccb75533cbb5ce.jpg', '20181008/88bc2c114b9698ded0ccb75533cbb5ce.jpg', '', '75fc9562b9cbc91bb2a0f65a73c0c41ad835ff2c', '1539002683', '0', '1');
INSERT INTO `xt_picture` VALUES ('49', 'c5b2bfdad1529b823857e8c3d9d019be.jpg', '20181009/c5b2bfdad1529b823857e8c3d9d019be.jpg', '', 'fbad79bd4e609795410b716a951d9fff15de5eff', '1539050778', '0', '1');
INSERT INTO `xt_picture` VALUES ('50', '21a06031874746da46605d61af5bd675.jpg', '20181009/21a06031874746da46605d61af5bd675.jpg', '', '670de2a1e94f9924ae13753c0fa2df6c61d838bf', '1539055665', '0', '1');
INSERT INTO `xt_picture` VALUES ('51', 'c90c218aa4b3f459d72d2e10ad532fdd.jpg', '20181009/c90c218aa4b3f459d72d2e10ad532fdd.jpg', '', '8511a94a9893515fe4de5ab2fe6276ac44de2730', '1539055826', '0', '1');
INSERT INTO `xt_picture` VALUES ('52', '5d103b34f533ed4542555c9f6e07d834.jpg', '20181009/5d103b34f533ed4542555c9f6e07d834.jpg', '', '70e87497821968bd171d0652bbbb364c972f1466', '1539056791', '0', '1');
INSERT INTO `xt_picture` VALUES ('53', '137c18045b328871c5999aeda56d1c54.jpg', '20181009/137c18045b328871c5999aeda56d1c54.jpg', '', '29436cd9d8cabfa19ea794f1eab26b58ed3cab14', '1539057554', '0', '1');
INSERT INTO `xt_picture` VALUES ('54', '305d2f154af26f04bc265694b5f60f61.jpg', '20181009/305d2f154af26f04bc265694b5f60f61.jpg', '', 'f9a43fb3f118450fa912e5b8034eba704724ff54', '1539057679', '0', '1');
INSERT INTO `xt_picture` VALUES ('55', 'e5d2aeb6ac3584ae0ad6f702fb98aa0c.jpg', '20181009/e5d2aeb6ac3584ae0ad6f702fb98aa0c.jpg', '', '5763fe12bd5246801015f1a93596a3232864ae30', '1539057844', '0', '1');
INSERT INTO `xt_picture` VALUES ('56', 'a41643b7c6502281e70438d8f5fc1925.jpg', '20181009/a41643b7c6502281e70438d8f5fc1925.jpg', '', 'd592c022a014be3e3e23d56fade6f0688e88f750', '1539057929', '0', '1');
INSERT INTO `xt_picture` VALUES ('57', 'ae9918f804e6ec9ff128a8e929961f8d.png', '20181009/ae9918f804e6ec9ff128a8e929961f8d.png', '', 'a9e39780de37641a10de5884454c1e5a381cec9a', '1539058435', '0', '1');
INSERT INTO `xt_picture` VALUES ('58', 'ad61d55a5fc324e7efe95be82a3cff9a.jpg', '20181009/ad61d55a5fc324e7efe95be82a3cff9a.jpg', '', '6aa4243c3d1596f9dd3dfa6d8227cd2c4303c6ef', '1539064591', '0', '1');
INSERT INTO `xt_picture` VALUES ('59', '532828cfa3827ff112f5a0c60a3487c8.jpg', '20181009/532828cfa3827ff112f5a0c60a3487c8.jpg', '', 'f0a1d73bd2c5e5ca9c36ee1658bc6fdd726218f2', '1539064712', '0', '1');
INSERT INTO `xt_picture` VALUES ('60', '8d341ac655bce60da43f8ce61d23e966.jpg', '20181009/8d341ac655bce60da43f8ce61d23e966.jpg', '', '08878a69d5f8f9dac60a9fc18eb9b1cf9bcceba3', '1539064910', '0', '1');

-- -----------------------------
-- Table structure for `xt_seo`
-- -----------------------------
DROP TABLE IF EXISTS `xt_seo`;
CREATE TABLE `xt_seo` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `url` varchar(40) NOT NULL DEFAULT '' COMMENT '模块',
  `seo_title` text NOT NULL COMMENT '标题',
  `seo_keywords` text NOT NULL COMMENT '关键字',
  `seo_description` text NOT NULL COMMENT '描述',
  `usable_val` varchar(255) NOT NULL DEFAULT '' COMMENT '可用变量',
  `sort` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COMMENT='seo表';

-- -----------------------------
-- Records of `xt_seo`
-- -----------------------------
INSERT INTO `xt_seo` VALUES ('40', '首页SEO信息', 'index/index/index', '善策{$category_name}{$article_title}', 'OneBase,PHP,{$category_name},{$article_title}', '善策', '{$category_name}，{$article_title}，{$article_describe}', '0', '1', '1505445912', '1537881934');
INSERT INTO `xt_seo` VALUES ('41', '善策', 'index/index/login', '善策', '善策', '善策', '', '0', '1', '1505538002', '1537881952');

-- -----------------------------
-- Table structure for `xt_shop`
-- -----------------------------
DROP TABLE IF EXISTS `xt_shop`;
CREATE TABLE `xt_shop` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文章ID',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '会员id',
  `name` char(40) NOT NULL DEFAULT '' COMMENT '文章名称',
  `category_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文章分类',
  `describe` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `content` text NOT NULL COMMENT '文章内容',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '封面图片id',
  `file_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件id',
  `img_ids` varchar(200) NOT NULL DEFAULT '',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  `thumb_a` varchar(255) NOT NULL,
  `num` int(11) NOT NULL DEFAULT '0',
  `price` varchar(255) NOT NULL DEFAULT '0',
  `cost` varchar(255) NOT NULL,
  `des` text NOT NULL,
  `selling` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `coupons` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='购物表';

-- -----------------------------
-- Records of `xt_shop`
-- -----------------------------
INSERT INTO `xt_shop` VALUES ('54', '1', '案例-Fasterfx 打造全球领先的金融互动', '13', '10000', '&lt;div class=&quot;row&quot;&gt;\r\n	&lt;div class=&quot;col-md-8&quot;&gt;\r\n		&lt;p class=&quot;details-text-head&quot;&gt;\r\n			项目背景\r\n		&lt;/p&gt;\r\n		&lt;p class=&quot;details-text-det&quot;&gt;\r\n			2017年7月，快蚁社区网站Fasterfx 快蚁社区正式上线。Fasterfx 快蚁社区，善策不仅全程为其设计了外汇跟单社区商业模式、营销模式、PC端智能跟单系统、报本牛人交易系统、人工智能交易系统、直播系统和用户平台体验，还在商业策略和产品设计上为其制定了产品演进路线。最终实现外汇投资生态链的闭环，从而打造全球领先的外汇社区！\r\n		&lt;/p&gt;\r\n	&lt;/div&gt;\r\n	&lt;div class=&quot;col-md-4&quot;&gt;\r\n	&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;br /&gt;\r\n&lt;br /&gt;\r\n&lt;div class=&quot;row&quot;&gt;\r\n	&lt;div class=&quot;col-md-8&quot;&gt;\r\n		&lt;p class=&quot;details-text-head&quot;&gt;\r\n			最终收获\r\n		&lt;/p&gt;\r\n		&lt;p class=&quot;details-text-det&quot;&gt;\r\n			2017年7月，快蚁社区网站Fasterfx 快蚁社区正式上线。Fasterfx 快蚁社区，善策不仅全程为其设计了外汇跟单社区商业模式、营销模式、PC端智能跟单系统、报本牛人交易系统、人工智能交易系统、直播系统和用户平台体验，还在商业策略和产品设计上为其制定了产品演进路线。最终实现外汇投资生态链的闭环，从而打造全球领先的外汇社区！\r\n		&lt;/p&gt;\r\n	&lt;/div&gt;\r\n	&lt;div class=&quot;col-md-4&quot;&gt;\r\n	&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;detaila-img&quot;&gt;\r\n	&lt;br /&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;row details-cont&quot;&gt;\r\n	&lt;div class=&quot;col-md-8&quot;&gt;\r\n		&lt;p class=&quot;details-text-det&quot;&gt;\r\n			通过全方位的用户研究，设计团队发现外汇行业分为投资人、投资机构、代理商、经纪商四方群体的信任感和安全感的建立、服务个性化与服务升级、用户引导与教育以及产品细节处理上面临很多机遇和挑战。&lt;br /&gt;\r\n&lt;br /&gt;\r\n例如：投资人如何选择安全的经纪商，过高的收益反而会让他们觉得不安全。利用设计体现平台对安全的关注或进行实物化的保障等则可以提高用户对平台的信任感。&lt;br /&gt;\r\n&lt;br /&gt;\r\n面对经纪商较为综合的服务体系，以及会按照不同资产规模区分服务的压力，互联网理财产品应该尽快推出个性化服务。可以根据用户的投资偏好和风险承受能力推荐个性化的资产配比，也可以根据用户的投资行为、交易数据划分用户等级，提供不同的优惠与附加服务。&lt;br /&gt;\r\n&lt;br /&gt;\r\n分散投资型用户缺少有效的统一管理工具，需要第三方资产管理服务。那么引入第三方交易牛人资产数据，全面管理资产成为平台功能转变的一个机遇点。&lt;br /&gt;\r\n&lt;br /&gt;\r\n针对外汇投资交易的双边交易特殊性，双向交易都可以获得利润，设计团队设计出一键智能化跟单系统，正向返向、不同比例、不同倍数跟单方式，满足投资者选择适合的投资策略。&lt;br /&gt;\r\n&lt;br /&gt;\r\n在外汇投资行业，有一大部分群体投资策略和交易经验非常的丰富，但一般的投资者无法接触到。在设计上就出现的牛人这 个身份，只要交易者能够长期保持稳定的收益，他将会在平台获得更多的粉丝和跟随着，从而获得投资者跟随利润。&lt;br /&gt;\r\n&lt;br /&gt;\r\nFasterfx 快蚁社区作为一个第三方服务平台，将对投资人、经纪商、交易牛人进行严格的审核才能入住平台，保障多方权益。\r\n		&lt;/p&gt;\r\n	&lt;/div&gt;\r\n	&lt;div class=&quot;col-md-4&quot;&gt;\r\n	&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;detaila-img&quot;&gt;\r\n	&lt;img src=&quot;/epock/public/admin/shopadmin/shopedit/id/img/案例详情-06@2x.jpg&quot; /&gt; &lt;img src=&quot;/epock/public/admin/shopadmin/shopedit/id/img/案例详情-07@2x.jpg&quot; /&gt; &lt;img src=&quot;/epock/public/admin/shopadmin/shopedit/id/img/案例详情-08@2x.jpg&quot; /&gt; &lt;img src=&quot;/epock/public/admin/shopadmin/shopedit/id/img/案例详情-09@2x.jpg&quot; /&gt; &lt;img src=&quot;/epock/public/admin/shopadmin/shopedit/id/img/案例详情-10@2x.jpg&quot; /&gt; \r\n&lt;/div&gt;\r\n&lt;div class=&quot;details-content&quot;&gt;\r\n	&lt;div class=&quot;row&quot;&gt;\r\n		&lt;div class=&quot;col-md-8&quot;&gt;\r\n			&lt;p class=&quot;details-text-head&quot;&gt;\r\n				Fasterfx 快蚁社区的产品设计，有哪些设计亮点？\r\n			&lt;/p&gt;\r\n			&lt;p class=&quot;details-text-det&quot;&gt;\r\n				2017年7月，快蚁社区网站Fasterfx 快蚁社区正式上线。Fasterfx 快蚁社区，善策不仅全程为其设计了外汇跟单社区商业模式、营销模式、PC端智能跟单系统、报本牛人交易系统、人工智能交易系统、直播系统和用户平台体验，还在商业策略和产品设计上为其制定了产品演进路线。最终实现外汇投资生态链的闭环，从而打造全球领先的外汇社区！\r\n			&lt;/p&gt;\r\n		&lt;/div&gt;\r\n		&lt;div class=&quot;col-md-4&quot;&gt;\r\n		&lt;/div&gt;\r\n	&lt;/div&gt;\r\n&lt;/div&gt;', '28', '0', '', '1535006718', '1539055312', '-1', '', '100', '198', '19', '', '0', '0', '', '0');
INSERT INTO `xt_shop` VALUES ('55', '1', 'asdasd', '7', '', 'asda', '0', '0', '', '1537884289', '1537884378', '-1', '', '0', '', '', '', '0', '0', '', '0');
INSERT INTO `xt_shop` VALUES ('56', '1', '区块链AI智能交易系统', '7', '2017年7月，快蚁社区网站Fasterfx 快蚁社区正式上线。Fasterfx 快蚁社区，善策不仅全程为其设计了外汇跟单社区商业模式、营销模式、PC端智能跟单系统、报本牛人交易系统、人工智能交易系统、直播系统和用户平台体验，还在商业策略和产品设计上为其制定了产品演进路线。最终实现外汇投资生态链的闭环，从而打造全球领先的外汇社区！', '&lt;img src=&quot;/upload/picture/20180926/77e20d0cad08919d4a5bda53451bf273.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/epock/public/upload/picture/20180926/77e20d0cad08919d4a5bda53451bf273.jpg&quot; alt=&quot;&quot; /&gt; \r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	通过全方位的用户研究，设计团队发现外汇行业分为投资人、投资机构、代理商、经纪商四方群体的信任感和安全感的建立、服务个性化与服务升级、用户引导与教育以及产品细节处理上面临很多机遇和挑战。\r\n&lt;/p&gt;\r\n&lt;br /&gt;\r\n例如：投资人如何选择安全的经纪商，过高的收益反而会让他们觉得不安全。利用设计体现平台对安全的关注或进行实物化的保障等则可以提高用户对平台的信任感。&lt;br /&gt;\r\n&lt;br /&gt;\r\n面对经纪商较为综合的服务体系，以及会按照不同资产规模区分服务的压力，互联网理财产品应该尽快推出个性化服务。可以根据用户的投资偏好和风险承受能力推荐个性化的资产配比，也可以根据用户的投资行为、交易数据划分用户等级，提供不同的优惠与附加服务。&lt;br /&gt;\r\n&lt;br /&gt;\r\n分散投资型用户缺少有效的统一管理工具，需要第三方资产管理服务。那么引入第三方交易牛人资产数据，全面管理资产成为平台功能转变的一个机遇点。&lt;br /&gt;\r\n&lt;br /&gt;\r\n针对外汇投资交易的双边交易特殊性，双向交易都可以获得利润，设计团队设计出一键智能化跟单系统，正向返向、不同比例、不同倍数跟单方式，满足投资者选择适合的投资策略。&lt;br /&gt;\r\n&lt;br /&gt;\r\n在外汇投资行业，有一大部分群体投资策略和交易经验非常的丰富，但一般的投资者无法接触到。在设计上就出现的牛人这 个身份，只要交易者能够长期保持稳定的收益，他将会在平台获得更多的粉丝和跟随着，从而获得投资者跟随利润。&lt;br /&gt;\r\n&lt;br /&gt;', '30', '0', '48', '1537884430', '1539055308', '-1', '', '0', '', '2017年7月，快蚁社区网站Fasterfx 快蚁社区正式上线。Fasterfx 快蚁社区，善策不仅全程为其设计了外汇跟单社区商业模式、营销模式、PC端智能跟单系统、报本牛人交易系统、人工智能交易系统、直播系统和用户平台体验，还在商业策略和产品设计上为其制定了产品演进路线。最终实现外汇投资生态链的闭环，从而打造全球领先的外汇社区！', '', '0', '0', '', '0');
INSERT INTO `xt_shop` VALUES ('57', '1', '系统系统系统', '7', '', '系统系统系统', '39', '0', '', '1537930821', '1539055293', '-1', '', '0', '', '', '', '0', '0', '', '0');
INSERT INTO `xt_shop` VALUES ('58', '1', '系统系统系统', '13', '', '系统系统系统', '38', '0', '', '1537930840', '1539055290', '-1', '', '0', '', '', '', '0', '0', '', '0');
INSERT INTO `xt_shop` VALUES ('59', '1', '系统系统系统', '7', '', '系统系统系统', '36', '0', '', '1537930856', '1539055283', '-1', '', '0', '', '', '', '0', '0', '', '0');
INSERT INTO `xt_shop` VALUES ('60', '1', '系统系统系统', '7', '', '系统系统系统', '37', '0', '48', '1537930876', '1539055278', '-1', '', '0', '', '', '', '0', '0', '', '0');
INSERT INTO `xt_shop` VALUES ('61', '1', '中国智能果园 新农', '7', '', '&lt;div class=&quot;details-content&quot;&gt;\r\n	&lt;!--\r\n	&lt;div class=&quot;row&quot;&gt;\r\n		&lt;div class=&quot;col-md-8&quot;&gt;\r\n			&lt;p class=&quot;details-content-p&quot;&gt;\r\n				Fasterfx 打造全球领先的金融互动社区\r\n			&lt;/p&gt;\r\n		&lt;/div&gt;\r\n		&lt;div class=&quot;col-md-4&quot;&gt;\r\n			&lt;div class=&quot;nav case-nav&quot;&gt;\r\n				&lt;a class=&quot;btn btn-default case-nav-btn&quot; href=&quot;/admin/shopadmin/shopedit/id/#&quot;&gt;全部&lt;/a&gt; &lt;a class=&quot;btn btn-default case-nav-btn&quot; href=&quot;/admin/shopadmin/shopedit/id/#&quot;&gt;产品0到1&lt;/a&gt; &lt;a class=&quot;btn btn-default case-nav-btn&quot; href=&quot;/admin/shopadmin/shopedit/id/#&quot;&gt;数字化转型&lt;/a&gt; \r\n			&lt;/div&gt;\r\n		&lt;/div&gt;\r\n	&lt;/div&gt;\r\n--&gt;\r\n	&lt;div class=&quot;row&quot;&gt;\r\n		&lt;div class=&quot;col-md-8&quot;&gt;\r\n			&lt;p class=&quot;details-text-head&quot;&gt;\r\n				项目背景\r\n			&lt;/p&gt;\r\n			&lt;p class=&quot;details-text-det&quot;&gt;\r\n				2017年7月，快蚁社区网站Fasterfx 快蚁社区正式上线。Fasterfx 快蚁社区，善策不仅全程为其设计了外汇跟单社区商业模式、营销模式、PC端智能跟单系统、报本牛人交易系统、人工智能交易系统、直播系统和用户平台体验，还在商业策略和产品设计上为其制定了产品演进路线。最终实现外汇投资生态链的闭环，从而打造全球领先的外汇社区！\r\n			&lt;/p&gt;\r\n		&lt;/div&gt;\r\n		&lt;div class=&quot;col-md-4&quot;&gt;\r\n		&lt;/div&gt;\r\n	&lt;/div&gt;\r\n&lt;br /&gt;\r\n&lt;br /&gt;\r\n	&lt;div class=&quot;row&quot;&gt;\r\n		&lt;div class=&quot;col-md-8&quot;&gt;\r\n			&lt;p class=&quot;details-text-head&quot;&gt;\r\n				最终收获\r\n			&lt;/p&gt;\r\n			&lt;p class=&quot;details-text-det&quot;&gt;\r\n				2017年7月，快蚁社区网站Fasterfx 快蚁社区正式上线。Fasterfx 快蚁社区，善策不仅全程为其设计了外汇跟单社区商业模式、营销模式、PC端智能跟单系统、报本牛人交易系统、人工智能交易系统、直播系统和用户平台体验，还在商业策略和产品设计上为其制定了产品演进路线。最终实现外汇投资生态链的闭环，从而打造全球领先的外汇社区！\r\n			&lt;/p&gt;\r\n		&lt;/div&gt;\r\n		&lt;div class=&quot;col-md-4&quot;&gt;\r\n		&lt;/div&gt;\r\n	&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;detaila-img&quot;&gt;\r\n	&lt;img src=&quot;/upload/picture/20180926/e7fe457db01474ff399d5f432c3888e9.jpg&quot; alt=&quot;&quot; /&gt;&lt;img src=&quot;/upload/picture/20180926/9af1bf04e46e91675c0a2b71f39cb191.jpg&quot; alt=&quot;&quot; /&gt;&lt;br /&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;row details-cont&quot;&gt;\r\n	&lt;div class=&quot;col-md-8&quot;&gt;\r\n		&lt;p class=&quot;details-text-det&quot;&gt;\r\n			通过全方位的用户研究，设计团队发现外汇行业分为投资人、投资机构、代理商、经纪商四方群体的信任感和安全感的建立、服务个性化与服务升级、用户引导与教育以及产品细节处理上面临很多机遇和挑战。&lt;br /&gt;\r\n&lt;br /&gt;\r\n例如：投资人如何选择安全的经纪商，过高的收益反而会让他们觉得不安全。利用设计体现平台对安全的关注或进行实物化的保障等则可以提高用户对平台的信任感。&lt;br /&gt;\r\n&lt;br /&gt;\r\n面对经纪商较为综合的服务体系，以及会按照不同资产规模区分服务的压力，互联网理财产品应该尽快推出个性化服务。可以根据用户的投资偏好和风险承受能力推荐个性化的资产配比，也可以根据用户的投资行为、交易数据划分用户等级，提供不同的优惠与附加服务。&lt;br /&gt;\r\n&lt;br /&gt;\r\n分散投资型用户缺少有效的统一管理工具，需要第三方资产管理服务。那么引入第三方交易牛人资产数据，全面管理资产成为平台功能转变的一个机遇点。&lt;br /&gt;\r\n&lt;br /&gt;\r\n针对外汇投资交易的双边交易特殊性，双向交易都可以获得利润，设计团队设计出一键智能化跟单系统，正向返向、不同比例、不同倍数跟单方式，满足投资者选择适合的投资策略。&lt;br /&gt;\r\n&lt;br /&gt;\r\n在外汇投资行业，有一大部分群体投资策略和交易经验非常的丰富，但一般的投资者无法接触到。在设计上就出现的牛人这 个身份，只要交易者能够长期保持稳定的收益，他将会在平台获得更多的粉丝和跟随着，从而获得投资者跟随利润。&lt;br /&gt;\r\n&lt;br /&gt;\r\nFasterfx 快蚁社区作为一个第三方服务平台，将对投资人、经纪商、交易牛人进行严格的审核才能入住平台，保障多方权益。\r\n		&lt;/p&gt;\r\n	&lt;/div&gt;\r\n	&lt;div class=&quot;col-md-4&quot;&gt;\r\n	&lt;/div&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;detaila-img&quot;&gt;\r\n	&lt;img src=&quot;/upload/picture/20180926/9af1bf04e46e91675c0a2b71f39cb191.jpg&quot; alt=&quot;&quot; /&gt;&lt;br /&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;details-content&quot;&gt;\r\n	&lt;div class=&quot;row&quot;&gt;\r\n		&lt;div class=&quot;col-md-8&quot;&gt;\r\n			&lt;p class=&quot;details-text-head&quot;&gt;\r\n				Fasterfx 快蚁社区的产品设计，有哪些设计亮点？\r\n			&lt;/p&gt;\r\n			&lt;p class=&quot;details-text-det&quot;&gt;\r\n				2017年7月，快蚁社区网站Fasterfx 快蚁社区正式上线。Fasterfx 快蚁社区，善策不仅全程为其设计了外汇跟单社区商业模式、营销模式、PC端智能跟单系统、报本牛人交易系统、人工智能交易系统、直播系统和用户平台体验，还在商业策略和产品设计上为其制定了产品演进路线。最终实现外汇投资生态链的闭环，从而打造全球领先的外汇社区！\r\n			&lt;/p&gt;\r\n		&lt;/div&gt;\r\n		&lt;div class=&quot;col-md-4&quot;&gt;\r\n		&lt;/div&gt;\r\n	&lt;/div&gt;\r\n&lt;/div&gt;', '28', '0', '', '1537930893', '1539055274', '-1', '', '0', '', '', '', '0', '0', '', '0');
INSERT INTO `xt_shop` VALUES ('62', '1', '金融交易系统外汇跟单搭建', '7', 'ytryry', '&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;', '30', '0', '', '1537932325', '1539055269', '-1', '', '0', '', 'uyuyuuygrtrt', '', '0', '0', '', '0');
INSERT INTO `xt_shop` VALUES ('63', '1', 'Fasterfx 打造全球领先的金融互动社区', '15', '整个saas服务设计将帮助Fasterfx 快蚁社区从0到1。将快蚁社区打造成在让每一个普通人都能够简单、快速地参与到投资市场，让用户能够通过简单易懂、安全透明、公平稳定的方式进行量化分析、复制学习、社会化学习、自动化交易和智能化体验，多方共赢，营造一个可持续的共赢金融科技生态环境。成为行业标杆企业社区。\r\n', '&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;img src=&quot;/upload/picture/20180926/77e20d0cad08919d4a5bda53451bf273.jpg&quot; alt=&quot;&quot; /&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;img src=&quot;/upload/picture/20181009/c90c218aa4b3f459d72d2e10ad532fdd.jpg&quot; alt=&quot;&quot; /&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot;&gt;&lt;img src=&quot;/upload/picture/20181009/5d103b34f533ed4542555c9f6e07d834.jpg&quot; alt=&quot;&quot; /&gt;&lt;br /&gt;\r\n&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot;&gt;&lt;img src=&quot;/upload/picture/20181009/137c18045b328871c5999aeda56d1c54.jpg&quot; alt=&quot;&quot; /&gt;&lt;br /&gt;\r\n&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot;&gt;&lt;br /&gt;\r\n&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;通过全方位的用户研究，设计团队发现外汇行业分为投资人、投资机构、代理商、经纪商四方群体的信任感和安全感的建立、服务个性化与服务&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;升级、用户引导与教育以及产品细节处理上面临很多机遇和挑战。&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot;&gt;&lt;br /&gt;\r\n&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p2&quot;&gt;\r\n	&lt;span class=&quot;s1&quot;&gt;&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;例如：投资人如何选择安全的经纪商，过高的收益反而会让他们觉得不安全。利用设计体现平台对安全的关注或进行实物化的保障等则可以提高&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;用户对平台的信任感。&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot;&gt;&lt;br /&gt;\r\n&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p2&quot;&gt;\r\n	&lt;span class=&quot;s1&quot;&gt;&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;面对经纪商较为综合的服务体系，以及会按照不同资产规模区分服务的压力，互联网理财产品应该尽快推出个性化服务。可以根据用户的投资偏好&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;和风险承受能力推荐个性化的资产配比，也可以根据用户的投资行为、交易数据划分用户等级，提供不同的优惠与附加服务。&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p2&quot;&gt;\r\n	&lt;span class=&quot;s1&quot;&gt;&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot;&gt;&lt;br /&gt;\r\n&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;分散投资型用户缺少有效的统一管理工具，需要第三方资产管理服务。那么引入第三方交易牛人资产数据，全面管理资产成为平台功能转变的一个&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;机遇点。&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot;&gt;&lt;br /&gt;\r\n&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p2&quot;&gt;\r\n	&lt;span class=&quot;s1&quot;&gt;&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;针对外汇投资交易的双边交易特殊性，双向交易都可以获得利润，设计团队设计出一键智能化跟单系统，正向返向、不同比例、不同倍数跟单方式，&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;满足投资者选择适合的投资策略。&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot;&gt;&lt;br /&gt;\r\n&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p2&quot;&gt;\r\n	&lt;span class=&quot;s1&quot;&gt;&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;在外汇投资行业，有一大部分群体投资策略和交易经验非常的丰富，但一般的投资者无法接触到。在设计上就出现的牛人这 个身份，只要交易者能&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;够长期保持稳定的收益，他将会在平台获得更多的粉丝和跟随着，从而获得投资者跟随利润。&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot;&gt;&lt;br /&gt;\r\n&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p2&quot;&gt;\r\n	&lt;span class=&quot;s1&quot;&gt;&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;Fasterfx 快蚁社区作为一个第三方服务平台，将对投资人、经纪商、交易牛人进行严格的审核才能入住平台，保障多方权益。&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;img src=&quot;/upload/picture/20181009/305d2f154af26f04bc265694b5f60f61.jpg&quot; alt=&quot;&quot; /&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;img src=&quot;/upload/picture/20180926/e7fe457db01474ff399d5f432c3888e9.jpg&quot; alt=&quot;&quot; /&gt; \r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;img src=&quot;/upload/picture/20181009/e5d2aeb6ac3584ae0ad6f702fb98aa0c.jpg&quot; alt=&quot;&quot; /&gt; \r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;img src=&quot;/upload/picture/20180926/9af1bf04e46e91675c0a2b71f39cb191.jpg&quot; alt=&quot;&quot; /&gt; \r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;img src=&quot;/upload/picture/20181009/a41643b7c6502281e70438d8f5fc1925.jpg&quot; alt=&quot;&quot; /&gt; \r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:24px;&quot;&gt;&lt;strong&gt;Fasterfx 快蚁社区的产品设计，有哪些设计亮点？&lt;/strong&gt;&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:18px;&quot;&gt;&lt;strong&gt;&lt;br /&gt;\r\n&lt;/strong&gt;&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:18px;&quot;&gt; &lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;1. 足够简单的应用结构&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;在用户研究中，我们发现有明确理财需求的人年龄普遍在 25岁以上，核心人群年龄更高，他们在设计上非常追求简单直观容易操作。&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;因此，我们精简了底层应用结构，划分为理财与账户两部分内容，产品呈现和操作也更加直接简单。&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;&lt;br /&gt;\r\n&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p2&quot;&gt;\r\n	&lt;span class=&quot;s1&quot;&gt;&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;&amp;nbsp;2. 值得信赖的品牌体验&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;外汇投资和传统银行相比，先天基因中就缺乏大众的信任。用户普遍存在操作频繁、追求短期利益、对安全感存疑等问题。我们利用&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;设计的方法来帮助用户逐渐建立对品牌的信任感，包括突出交易数据透明性，如交易记录、资产分布、累计收益等。还通过设置安全&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;密码保护、模糊多任务状态等细节丰富用户的安全体验。&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;&lt;br /&gt;\r\n&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p2&quot;&gt;\r\n	&lt;span class=&quot;s1&quot;&gt;&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;3. 服务分级和服务个性化&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;与传统外汇社区相比，普遍缺乏规范的服务体系和标准。传统外汇跟单对于用户的划分更细致和成熟，会针对不同层级的用户提供对&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;应的服务和产品。与为投资人、投资机构、代理商、经纪商体系结合在一起，帮助平台提高用户忠诚度。&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;&lt;br /&gt;\r\n&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p2&quot;&gt;\r\n	&lt;span class=&quot;s1&quot;&gt;&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;4. 透明的牛人交易数据展示&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;毫无保留展示交易牛人交易报表，交易订单，他的跟随者，收益率，总获利等交易数据，让跟随者更放心选择想要的交易策略。&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;与 Fasterfx 快蚁社区的合作，是我们在金融领域的又一次突破，我们为其品牌制定了一条长期产品演进路线。欢迎访问 Fasterfx 快蚁&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p1&quot;&gt;\r\n	&lt;span class=&quot;s1&quot; style=&quot;font-size:14px;&quot;&gt;社区 ，享受更品质的财富管理服务。&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;p class=&quot;p2&quot;&gt;\r\n	&lt;span class=&quot;s1&quot;&gt;&lt;/span&gt; \r\n&lt;/p&gt;\r\n&lt;span style=&quot;font-size:14px;&quot;&gt;&lt;/span&gt;&lt;br /&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;\r\n&lt;p&gt;\r\n	&lt;br /&gt;\r\n&lt;/p&gt;', '28', '0', '50', '1539055718', '1539064454', '1', '', '0', '0', '2017年7月，快蚁社区网站Fasterfx 快蚁社区正式上线。Fasterfx 快蚁社区，善策不仅全程为其设计了外汇跟单社区商业模式、营销模式、PC端智能跟单系统、报本牛人交易系统、人工智能交易系统、直播系统和用户平台体验，还在商业策略和产品设计上为其制定了产品演进路线。最终实现外汇投资生态链的闭环，从而打造全球领先的外汇社区！', '', '0', '0', '', '0');

-- -----------------------------
-- Table structure for `xt_shop_car`
-- -----------------------------
DROP TABLE IF EXISTS `xt_shop_car`;
CREATE TABLE `xt_shop_car` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `num` int(5) NOT NULL,
  `time` int(11) NOT NULL,
  `goods_id` bigint(20) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=670 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `xt_shop_category`
-- -----------------------------
DROP TABLE IF EXISTS `xt_shop_category`;
CREATE TABLE `xt_shop_category` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `describe` varchar(255) NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `icon` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xt_shop_category`
-- -----------------------------
INSERT INTO `xt_shop_category` VALUES ('7', '差异化创新', '基础内容', '1509620712', '1535946233', '0', 'fa-street-view');
INSERT INTO `xt_shop_category` VALUES ('13', '数字化转型', '数字化转型', '1535946321', '1537883389', '0', 'fa-close');
INSERT INTO `xt_shop_category` VALUES ('12', '商城消费', 'dfdgdf', '1533981489', '1535946092', '-1', 'fa-font');
INSERT INTO `xt_shop_category` VALUES ('14', '产品0到1 ', '产品0到1 ', '1539055351', '1539055351', '0', 'fa-th-list');
INSERT INTO `xt_shop_category` VALUES ('15', '金融SAAS服务', '金融SAAS服务', '1539055363', '1539055363', '0', 'fa-check');
INSERT INTO `xt_shop_category` VALUES ('16', '品牌策略', '品牌策略', '1539055374', '1539055374', '0', 'fa-check');
INSERT INTO `xt_shop_category` VALUES ('17', '移动应用', '移动应用', '1539055385', '1539055385', '0', 'fa-check');

-- -----------------------------
-- Table structure for `xt_shop_order`
-- -----------------------------
DROP TABLE IF EXISTS `xt_shop_order`;
CREATE TABLE `xt_shop_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `num` int(5) NOT NULL,
  `create_time` int(11) NOT NULL,
  `send_time` int(11) NOT NULL DEFAULT '0',
  `get_time` int(11) NOT NULL DEFAULT '0',
  `express_type` varchar(255) NOT NULL,
  `express_no` varchar(20) NOT NULL DEFAULT '',
  `pay_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0全现金；1全积分；2半现金半积分',
  `money_type` int(8) NOT NULL DEFAULT '0',
  `goods_id` bigint(20) NOT NULL,
  `goods_name` varchar(200) NOT NULL,
  `goods_thumb` varchar(200) NOT NULL,
  `goods_price` decimal(12,2) NOT NULL,
  `address` varchar(200) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `status` tinyint(1) NOT NULL COMMENT '0待发货；1待收货；2已完成',
  `code` varchar(255) NOT NULL,
  `express_code` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `address_fee` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=663253 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `xt_shop_order`
-- -----------------------------
INSERT INTO `xt_shop_order` VALUES ('663251', '1', '100000', '1', '1537014123', '0', '1536997049', '', '', '0', '0', '54', '广告包', '', '198.00', '   ', '', '', '3', 'S20180915153729518543', '', '', '', '');
INSERT INTO `xt_shop_order` VALUES ('663252', '1', '100000', '1', '1537014226', '0', '1536997049', '', '', '0', '0', '54', '广告包', '', '198.00', '   ', '', '', '3', 'S20180915153729719153', '', '', '', '');

-- -----------------------------
-- Table structure for `xt_times`
-- -----------------------------
DROP TABLE IF EXISTS `xt_times`;
CREATE TABLE `xt_times` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` char(10) NOT NULL DEFAULT '' COMMENT '日期',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `data_status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=383 DEFAULT CHARSET=utf8 COMMENT='期号表';

-- -----------------------------
-- Records of `xt_times`
-- -----------------------------
INSERT INTO `xt_times` VALUES ('377', '2018-09-15', '0', '1537014339', '1');
INSERT INTO `xt_times` VALUES ('378', '2018-09-26', '0', '1537924980', '1');
INSERT INTO `xt_times` VALUES ('379', '2018-09-27', '0', '1538017826', '1');
INSERT INTO `xt_times` VALUES ('380', '2018-09-28', '0', '1538100613', '1');
INSERT INTO `xt_times` VALUES ('381', '2018-10-08', '0', '1538982657', '1');
INSERT INTO `xt_times` VALUES ('382', '2018-10-09', '0', '1539050084', '1');
