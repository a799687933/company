Object.html =   '<div class="addWrap" id="addWrap">'+
                '<div class="addTop"><span class="deliverySpan">配送范围</span></div>'+
                '<div class="addContent"><div class="addGroup cl-fix">'+
                '<div class="addTitle">所在区域：</div><div class="selectDiv cl-fix"><dl class="selectDl">'+
                '<dt class="selectDt">选择省份</dt><dd class="selectDd">'+
                '<div class="ddList proList">广东省</div></dd></dl>'+
                '<dl class="selectDl"><dt class="selectDt">选择城市</dt>'+
                '<dd class="selectDd"><div class="ddList cityList">深圳市</div></dd></dl>'+
                '<dl class="selectDl last"><dt class="selectDt">选择地区</dt>'+
                '<dd class="selectDd"><div class="ddList areaList">南山区</div></dd></dl></div></div>'+
                '<div class="addGroup cl-fix"><div class="addTitle">详细地址：</div><div class="addInputDiv">'+
                '<input type="text" placeholder="请输入详细地址" class="addInput"></div></div>'+
                '<div class="addGroup cl-fix"><div class="addTitle">收货人姓名：</div><div class="addInputDiv">'+
                '<input type="text" placeholder="请输入收货人姓名" class="addInput"></div></div>'+
                '<div class="addGroup cl-fix"><div class="addTitle">联系电话：</div>'+
                '<div class="addInputDiv"><input type="text" placeholder="请输入联系电话" class="addInput"></div></div></div>'+
                '<div class="setDefualt cl-fix"><div class="isDefault">设为默认地址</div>'+
                '</div><div class="addBtn">添加</div></div>';
document.write(Object.html);
delete Object.html;