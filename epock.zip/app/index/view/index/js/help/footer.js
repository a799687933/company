Object.html =   '<div class="footer"><div class="footWrap"><div class="footLogo">'+
                '<img src="img/footerLogo.png"></div><div class="footList cl-fix">'+
                '<div class="footType footContent">'+
                '<div class="footTypeName">全部系列</div>'+
                '<div class="footTypeName">很多维C</div>'+
                '<div class="footTypeName">夏天的秘密</div>'+
                '<div class="footTypeName">完美组合</div>'+
                '<div class="footTypeName">你好夏威夷</div>'+
                '<div class="footTypeName">榴芒记</div></div>'+
                '<div class="footIntro footContent"><div class="footIntroName">'+
                '<a href="activity.html" target="_blank">品牌活动</a>'+
                '</div><div class="footIntroName">'+
                '<a href="idea.html" target="_blank">品牌理念</a>'+
                '</div></div>'+
                '<div class="footContact footContent"><p class="footContactInfo">联系我们</p><p class="footContactInfo">服务热线：400-736-8217</p><p class="footContactInfo">工作时间：早上10:00~晚上22:00</p><p class="footContactInfo">店铺地址：广东省深圳市南山区深圳大学内</p></div>'+
                '<div class="footQrcode footContent last"><div class="qrcodeDiv"><img src="img/juiceQrcode.png"></div>'+
                '<p class="qrcodeTip first">关注微信</p><p class="qrcodeTip">获取更多活动信息</p></div></div></div></div>'+
                '<div class="copyright">'+
                '<p>北京和聚网络科技有限公司    京ICP备14009743号 ©HeyJuice 2014    北京市朝阳区东三环北路丙2号18层21B06</p>'+
                '<p>营业执照注册号：110108016581054    食品流通许可证编号：SP1101051410304043(1-1)    产品标准号：GB/T31121    生产许可证：QS1127 0601 0435</p>'+
                '</div>';
document.write(Object.html);
delete Object.html;


                
                
                    
                    
                    
                    
                    
                    
                
                
                
                    
    
        
        
