<?php
namespace app\admin\model;

use think\Model;

class Msg extends Model{
	public function getSendTimeAttr($value, $data){
        return date('Y-m-d H:i:s', $value);
    }
    public function getUserIdAAttr($value, $data){
        return $data['user_id'] == '' ? '客服' : '<a href="'.url('Admin/member_login', ['user_id' => $data['user_id']]).'" onclick="return confirm(\'确定要登入账号【'.$data['user_id'].'】吗？\')">'.$data['user_id'].'</a>';
    }
    public function getToUserIdAAttr($value, $data){
        return $data['to_user_id'] == config('web.admin_info.user_id') ? '公司' : $data['to_user_id'];
    }
    public function getReadTimeAttr($value, $data){
        return $value ? date('Y-m-d H:i:s', $value) : '未查看';
    }
}