<?php
namespace app\admin\model;

use think\Model;

class Config extends Model{

	public function getS1AAttr($value, $data){
        return explode('|', $data['s1']);
    }
    public function getS6AAttr($value, $data){
        $a = explode('|', $data['s6']);
        $r = [];
        foreach ($a as $v) {
            $b = explode('-', $v);
            if (count($b) == 2) {
                $r[] = $b;
            }
        }
        return $r;
    }
    public function getS7AAttr($value, $data){
        return explode('|', $data['s7']);
    }
    public function getS8AAttr($value, $data){
        $a = explode('|', $data['s8']);
        $r = [];
        foreach ($a as $v) {
            $b = explode('-', $v);
            if (count($b) == 4) {
                $r[] = [
                    're_nums' => intval($b[0]),
                    'level' => intval($b[1]),
                    'percent' => floatval($b[2]) / 100,
                    'rank' => $b[3],
                ];
            }
        }
        return $r;
    }
    public function getS9AAttr($value, $data){
        $a = explode('|', $data['s9']);
        $r = [];
        foreach ($a as $v) {
            $b = explode('-', $v);
            if (count($b) == 4) {
                $r[] = [
                    're_nums' => intval($b[0]),
                    'team' => intval($b[1]),
                    'percent' => floatval($b[2]) / 100,
                    'rank' => $b[3],
                ];
            }
        }
        return $r;
    }
    public function getS10AAttr($value, $data){
        return explode('|', $data['s10']);
    }
    public function getS11AAttr($value, $data){
        $a = explode('|', $data['s11']);
        $r = [];
        foreach ($a as $v) {
            $b = explode('-', $v);
            if (count($b) == 2) {
                $r[] = $b;
            }
        }
        return $r;
    }
    public function getS12AAttr($value, $data){
        $a = explode('|', $data['s12']);
        $r = [];
        foreach ($a as $v) {
            $b = explode('-', $v);
            if (count($b) == 2) {
                $r[$b[0]] = $b[1];
            }
        }
        return $r;
    }

    public function getTimeAttr($value, $data){
        if ($data['service_time']) {
            return strtotime($data['service_time']);
        }
        return time();
    }
    public function getS14AAttr($value, $data){
        return explode('|', $data['s14']);
    }
}