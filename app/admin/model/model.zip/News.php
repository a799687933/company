<?php
namespace app\admin\model;

use think\Model;

class News extends Model{
	public function getTimeAttr($value, $data){
		return date('Y-m-d H:i:s', $value);
	}
	public function getSlideImgAAttr($value, $data){
		if ($data['slide_img']) {
        	return __PUBLIC__.'/uploads/slide/'.$data['slide_img'];
        }
        return '';
	}
}