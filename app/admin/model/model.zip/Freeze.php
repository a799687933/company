<?php
namespace app\admin\model;

use think\Model;
use think\Db;

class Freeze extends Model{
	public static function add($money, $user, $config){
		$data = [
			'money' 	=> $money,
			'uid' 		=> $user->id,
			'user_id' 	=> $user->user_id,
			'time' 		=> $config->time + $config->i12 * 24 * 3600,
		];
		return Db::name('freeze')->insertGetId($data);
	}

	public static function money($user, $config){
		$time = $config->time;
		$where = [
			['uid', '=', $user->id],
			['time', '>', $time]
		];
		return Db::name('freeze')->where($where)->sum('money');
	}
}