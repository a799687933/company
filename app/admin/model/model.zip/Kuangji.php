<?php
namespace app\admin\model;

use think\Model;

class Kuangji extends Model{

	public function getTimeAttr($value, $data){
		return date('Y/n/j H:i:s', $value);
	}
}