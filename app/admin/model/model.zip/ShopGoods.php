<?php
namespace app\admin\model;

use think\Model;
class ShopGoods extends Model{
	public function getTimeAttr($value, $data){
		return date('Y-m-d H:i:s', $value);
	}
	public function getThumbAAttr($value, $data){
		if ($data['thumb']) {
        	return __PUBLIC__.'/uploads/shop/'.$data['thumb'];
        }
        return '';
	}
}