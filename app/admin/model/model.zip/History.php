<?php
namespace app\admin\model;

use think\Model;
use think\Db;

class History extends Model{

	// 1：本息钱包。提现
	// 2：动态钱包。提现
	// 3：团队业绩钱包。提现
	// 4：any。后台充值
	// 5：动态钱包。直推奖
	// 6：动态钱包。领导奖
	// 7：团队业绩钱包。团队业绩奖
	// 8：权益积分钱包。动态收益75%
	// 9：权益积分钱包。静态收益25%
	// 10：any。提现手续费
	// 11：本息钱包。普惠区提取本金
	// 12：本息钱包。普惠区利息
	// 13：本息钱包。极速区本息
	// 14：any。撤回订单
	

	// 记录改变信息
	public static function add($user, $money, $title, $time, $type, $type_text, $change_after, $user_id_trigger = '', $flag = ''){
		$data = [
			'uid' 		=> $user->id,
			'user_id' 	=> $user->user_id,
			'title' 	=> $title,
			'money' 	=> $money,
			'time' 		=> $time,
			'type' 		=> $type,
			'type_text' => $type_text,
			'change_after' => $change_after,
			'user_id_trigger' => $user_id_trigger,
			'flag' => $flag,
		];
		return Db::name('history')->insertGetId($data);
	}

	protected function getTimeAttr($value, $data){
        return date('Y-m-d H:i:s', $value);
    }
}