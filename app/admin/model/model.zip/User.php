<?php
namespace app\admin\model;

use think\Model;
use think\Db;

class User extends Model{
	// b0：排单总额
	// b1：本息钱包（本金+静态收益）
	// b2：动态钱包（直推奖+领导奖）
	// b3：团队业绩钱包
	// b4：权益积分
	// b5：提现总额
    protected function getTimeAttr($value, $data){
        return date('Y-m-d H:i:s', $value);
    }
    protected function getActivateTimeAttr($value, $data){
    	if ($value == 0) {
    		return '<span style="color: orange;">未激活</span>';
    	}
        return date('Y-m-d H:i:s', $value);
    }
    protected function getTimePdAttr($value, $data){
    	if ($value == 0) {
    		return '未排单';
    	}
        return date('Y-m-d H:i:s', $value);
    }
    protected function getStatusAttr($value, $data){
    	$s = ['<span style="color: green;">正常</span>', '<span style="color: orange;">未激活</span>', '<span style="color: red;">封号</span>'];
        return $s[$value];
    }
    protected function getReAttr($value, $data){
        if ($this->getData('re_id')) {
			return $this->get($this->getData('re_id'));
        }
        return null;
    }
    public function register($params, $config){
		$where = [
			['user_id', '=', $params['re_user_id']]
		];
		$re_user = $this->where($where)->find();
		$salt = random_string();
		$data = [
			're_level' 			=> $re_user->re_level + 1,
			're_path' 			=> $re_user->re_path ?  $re_user->re_path.$re_user->id.',' : ','.$re_user->id.',',
			'user_id' 			=> $params['user_id'],
			'user_name' 		=> $params['user_name'],
			'mobile' 			=> $params['mobile'],
			'bank_name' 		=> $params['bank_name'],
			'bank_card' 		=> $params['bank_card'],
			'alipay' 			=> $params['alipay'],
			'address' 			=> $params['address'],
			're_id' 			=> $re_user->id,
			're_user_id' 		=> $params['re_user_id'],
			'password' 			=> $params['password'],
			'password_encry' 	=> encrypt_password($params['password'], $salt),
			'password2' 		=> $params['password2'],
			'password2_encry' 	=> encrypt_password($params['password2'], $salt),
			'salt' 				=> $salt,
			'time' 				=> $config->time,
			'status' 			=> 0, // 账号状态：0正常；1未激活；2封号
		];
		$this->save($data);
		$re_user->re_nums += 1;
		$re_user->save();
		// 给他的所有上级增加团队总人数
		$where = [
			['id', 'in', explode(',', '0'.$data['re_path'].'0')]
		];
		$this->where($where)->setInc('team', 1);

		// 给会员默认权限：普通会员
		$data = [
			'uid' => $this->getData('id'),
			'group_id' => 1,
		];
		Db::name('auth_group_access')->insertGetId($data);
	}

	// 获取等级名称
	protected function getRankAttr($value, $data){
		$config = \app\admin\model\Config::get(1);
        $s9 = $config->s9_a;
        $re_nums = $this->getData('re_nums');
        $team = $this->getData('team');
        for ($i = count($s9) - 1; $i >= 0; $i--) { 
        	if ($re_nums >= $s9[$i]['re_nums'] && $team >= $s9[$i]['team']) {
        		return $s9[$i]['rank'];
        	}
        }

        $s8 = $config->s8_a;
        for ($i = count($s8) - 1; $i >= 0; $i--) { 
        	if ($re_nums >= $s8[$i]['re_nums']) {
        		return $s8[$i]['rank'];
        	}
        }

        return '无等级';
    }

}