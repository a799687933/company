<?php
namespace app\admin\model;
use think\Model;
use think\Db;
use app\admin\model\Config;
use app\admin\model\User;
use app\admin\model\History;
use app\admin\model\Bonus;

class Mmm extends Model{
	public function getTimeAttr($value, $data){
        return date('Y-m-d H:i:s', $value);
    }
    public function getDoneTimeAttr($value, $data){
        if ($value) {
            return date('Y-m-d H:i:s', $value);
        }
        return '未完成全款';
    }
    public function getFreezeTimeAttr($value, $data){
        if ($data['done_time_pre']) {
            $config = Config::get(1);
            return date('Y-m-d H:i:s', $data['done_time_pre'] + $config->i10 * 24 * 3600);
        }
        return '未完成预付款';
    }
    public function getStatusAAttr($value, $data){
    	$status = [
            0 => '<b style="color:orange;">等待匹配</b>', 
            1 => '<b style="color:#44aef6;">等待汇款</b>', 
    		2 => '<b style="color:#4f5ae2;">等待收款</b>', 
            3 => '<b style="color:#dc5a5a;">超时未打款</b>', 
            4 => '<b style="color:red;">超时未收款</b>', 
            5 => '<b style="color:#13ec50;">部分匹配</b>', 
            6 => '<b style="color:green;">匹配完成:'.date('Y-m-d H:i:s', $data['done_time']).'</b>', 
            7 => '<b style="color:#807963;">交易完成:'.date('Y-m-d H:i:s', $data['out_time']).'</b>', 
    	];
        return $status[$data['status']];
    }
    // public function getXidAAttr($value, $data){
    //     if ($data['xid']) {
    //         return $this>get($data['xid']);
    //     }
    //     return null;
    // }
    public function getType2AAttr($value, $data){
        $type = ['普惠区', '极速区'];
        return $type[$data['type2']];
    }
    public function getType3AAttr($value, $data){
        $type = ['尾款', '预付款'];
        return $type[$data['type3']];
    }
    public function getType4AAttr($value, $data){
        $status = [
            0 => '', 
            1 => '&nbsp;<b style="color:blue;cursor:pointer;" title="金额级别提示，会生成发货订单">￥</b>', 
            2 => '&nbsp;<b style="color:orange;cursor:pointer;" title="预付款">预</b>', 
            3 => '&nbsp;<b style="color:red;cursor:pointer;" title="会员首单">首</b>', 
        ];
        return $status[$data['type4']];
    }
    public function getType5AAttr($value, $data){
        $status = [
            0 => '', 
            1 => '&nbsp;<b style="color:red;cursor:pointer;" title="会员首单">首</b>', 
        ];
        return $status[$data['type5']];
    }
    public function getType6AAttr($value, $data){
        $status = [
            0 => '', 
            1 => '&nbsp;<b style="color:red;cursor:pointer;" title="含有超时不打款退回的金额">超</b>', 
            2 => '&nbsp;<b style="color:orange;cursor:pointer;" title="含有回滚时退回的金额">滚</b>', 
        ];
        return $status[$data['type6']];
    }
    public function getOutTypeAAttr($value, $data){
        $type = [
            0 => '', 
            1 => '<b style="color:#44aef6;">本息钱包</b>', 
            2 => '<b style="color:#4f5ae2;">动态钱包</b>', 
            3 => '<b style="color:#dc5a5a;">团队业绩钱包</b>', 
        ];
        return $type[$data['out_type']];
    }

    public function getXidAAttr($value, $data){
        return $this->get($this->getData('xid'));
    }

    // 获取订单的收益
    public function getIncomeAttr($value, $data){
        $config = Config::get(1);
        $percent_all = 0;
        $money_all = 0;
        $list = [];
        $time = $config->time;
        $flag           = $this->getData('id');
        $done_time_pre  = $this->getData('done_time_pre'); // done_time_pre：付完预付款时的时间戳
        $done_time      = $this->getData('done_time'); // done_time：付完全款时的时间戳
        $out_time       = $this->getData('out_time'); // out_time：提取本金时的时间戳
        $type2          = $this->getData('type2'); // 0：常规；1：极速
        $money_main     = $this->getData('money_main'); // 排单金额
        $s10 = $config->s10_a; // 只打预付款|打完全款未解冻|打完全款已解冻
        $user = User::get($this->getData('uid'));

        $history = Db::name('history')->where('flag', $this->getData('id'))->column('flag', 'time');

        if ($type2 == 0) {
            if ($done_time_pre == 0 || $done_time_pre > $time) {
                return ['percent' => 0, 'money' => '0.00', 'list' => []];
            }
            $base_time = $done_time_pre + 24 * 3600;
            $time_freeze = $done_time_pre + $config->i10 * 24 * 3600; // 解冻时间

            $can_pick = false;
            $money_no_pick = 0;

            while ($base_time < $time) {
                if ($out_time != 0 && $base_time >= $out_time) {
                    break;
                }
                $percent = 0;
                // 只打预付款
                // if ($done_time_pre && $base_time < $done_time) {
                    $percent = floatval($s10[0]);
                // }
                // 打完全款未解冻
                if ($done_time && $base_time >= $done_time && $base_time <= $time_freeze) {
                    $percent = floatval($s10[1]);
                    $can_pick = true;
                }

                // 打完全款已解冻
                if ($done_time && $base_time > $time_freeze) {
                    $percent = floatval($s10[2]);
                    $can_pick = true;
                }

                $percent = $percent_all + $percent > $config->i11 ? $config->i11 - $percent_all : $percent;
                $money = $money_main * $percent / 100;
                $percent_all += $percent;
                $money_all += $money;
                $list[] = ['time' => date('Y-m-d', $base_time), 'percent' => $percent, 'money' => number_format($money, 2, '.', ''), 'can_pick' => $can_pick];

                if (!$can_pick) {
                    $money_no_pick += $money;
                }

                if ($can_pick && !isset($history[$base_time])) {// 打完全款收益就直接进入钱包
                    $money = $money_no_pick ? $money_no_pick + $money : $money;
                    $money_no_pick = 0;
                    $user->b1 += $money;
                    History::add($user, $money, '普惠区收益', $base_time, 12, '静态钱包', $user->b1, '', $flag);
                    Bonus::add($user, $money, $base_time, 'b0');
                }

                if ($percent_all >= $config->i11) {
                    break;
                }
                $base_time += 24 * 3600;
            }
        }else{
            if ($done_time == 0 || $done_time > $time) {
                return ['percent' => 0, 'money' => '0.00', 'list' => []];
            }
            $base_time = $done_time;
            $percent_all = floatval($config->s3);
            $money_all = $money_main * $percent_all / 100;
            $list[] = ['time' => date('Y-m-d H:00', $base_time), 'percent' => $percent_all, 'money' => number_format($money_all, 2, '.', '')];
            $base_time += 3600;
            while ($base_time < $time) {
                if ($out_time != 0 && $base_time > $out_time) {
                    break;
                }
                $percent = floatval($config->s4);
                $percent = $percent_all + $percent > $config->s5 ? $config->s5 - $percent_all : $percent;
                $money = $money_main * $percent / 100;
                $percent_all += $percent;
                $money_all += $money;
                $list[] = ['time' => date('Y-m-d H:00', $base_time), 'percent' => $percent, 'money' => number_format($money, 2, '.', '')];

                if (!isset($history[$base_time])) {
                    $user->b1 += $money;
                    History::add($user, $money, '极速区收益', $base_time, 13, '静态钱包', $user->b1, '', $flag);
                    Bonus::add($user, $money, $base_time, 'b1');
                }

                if ($percent_all >= $config->s5) {
                    break;
                }
                $base_time += 3600;
            }
        }
        $user->save();
        return ['percent' => $percent_all, 'money' => number_format($money_all, 2, '.', ''), 'list' => array_reverse($list)];
    }
}