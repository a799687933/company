<?php
namespace app\admin\model;

use think\Model;

class ShopCar extends Model{
	public function getGoodsThumbAAttr($value, $data){
		if ($data['goods_thumb']) {
        	return __PUBLIC__.'/uploads/shop/'.$data['goods_thumb'];
        }
        return '';
	}
}