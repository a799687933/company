<?php
namespace app\admin\model;
use think\Model;
use think\Db;

class MmmMatch extends Model{
    public static function add(&$in, &$out, $money, $time){
        $in->remain -= $money;
        $in->status = 1;
        $out->remain -= $money;
        $out->status = 1;
        $in->save();
        $out->save();
        $data = [
            'id_in' => $in->id,
            'id_out' => $out->id,
            'user_id_in' => $in->user_id,
            'user_id_out' => $out->user_id,
            'code_in' => $in->id,
            'code_out' => $out->id,
            'time_in' => $in->getData('time'),
            'time_out' => $out->getData('time'),
            'time' => $time,
            'money' => $money,
        ];
        return Db::name('mmm_match')->insertGetId($data);
    }
    public function getTimeAttr($value, $data){
        return date('Y-m-d H:i:s', $value);
    }
    public function getTimeInAttr($value, $data){
        return date('Y-m-d H:i:s', $value);
    }
    public function getTimeOutAttr($value, $data){
        return date('Y-m-d H:i:s', $value);
    }
    public function getComplaintAAttr($value, $data){
        return $data['complaint'] ? $data['complaint'] : '无';
    }
    public function getPayTimeAttr($value, $data){
        return $value ? date('Y-m-d H:i:s', $value) : '等待打款';
    }
    public function getComfirmTimeAttr($value, $data){
        return $value ? date('Y-m-d H:i:s', $value) : '等待收款';
    }
    public function getVoucherAAttr($value, $data){
        if (!$data['voucher']) {
        	return __STATIC__.'/images/nopic.jpg';
        }
        if (strpos($data['voucher'], 'http') === false) {
        	return __PUBLIC__.'/uploads/voucher/'.str_replace('\\', '/', $data['voucher']);
        }
        return $data['voucher'];
    }
    public function getStatusAAttr($value, $data){
        $status = [ 
            '<b style="color:#44aef6;">等待汇款</b>', 
            '<b style="color:#4f5ae2;">等待收款</b>', 
            '<b style="color:#dc5a5a;">超时未打款</b>', 
            '<b style="color:red;">超时未收款</b>', 
            '<b style="color:green;">匹配完成</b>', 
        ]; 
        return $status[$data['status']];
    }
    public function getOverdueTimeInAttr($value, $data){
    	$config = Db::name('config')->find();
    	$overdue_time = $data['time'] + $config['i17'] * 3600;
        return date('Y-m-d H:i:s', $overdue_time);
    }
    public function getOverdueTimeOutAttr($value, $data){
    	if ($data['pay_time'] == 0) {
    		return '等待对方打款';
    	}
    	$config = Db::name('config')->find();
    	$overdue_time = $data['pay_time'] + $config['i18'] * 3600;
        return date('Y-m-d H:i:s', $overdue_time);
    }
    public function getUserInAttr($value, $data){
        $mmm = Db::name('mmm')->where('id', $data['id_in'])->find();
    	return Db::name('user')->where('id', $mmm['uid'])->find();
    }
    public function getUserOutAttr($value, $data){
    	$mmm = Db::name('mmm')->where('id', $data['id_out'])->find();
    	return Db::name('user')->where('id', $mmm['uid'])->find();
    }
}