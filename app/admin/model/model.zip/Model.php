<?php
namespace app\admin\model;
use think\Model as M;
// use think\facade\Session;
// use app\admin\model\User;
use app\admin\model\Config;
class Model extends M{
    // protected $user;
    protected $config;
    public function __construct() {
        parent::__construct();
        // if(Session::get(config('web.user_auth_key'))){
        //     $this->user = User::get(session(config('web.user_auth_key')));
        // }else{
        //     $this->user = null;
        // }
        $this->config = Config::get(1);
    }

}