<?php
namespace app\admin\model;

use think\Model;
use think\Db;

class Bonus extends Model{
	// 记录奖金表
	// b0：静态收益30%；
	// b1：静态收益20%；
	// b2：直推奖；
	// b3：领导奖；
	// b4：团队业绩奖；
	// b5：权益积分；
	public static function add($user, $money, $time, $field){
		// 获取期号
		$date = date('Y-m-d', $time);
		$times = Db::name('times')->where('date', $date)->find();
		if ($times) {
			$times_id = $times['id'];
		}else{
			$times_id = Db::name('times')->insertGetId(['date' => $date]);
		}

		$where = [
			['uid', '=', $user->id],
			['times_id', '=', $times_id],
		];
		$bonus = Db::name('bonus')->where($where)->find();
		if (empty($bonus)) {
			$data = [
				'times_id' 	=> $times_id,
				'uid' 		=> $user->id,
				'user_id' 	=> $user->user_id,
				'time' 		=> $time,
				$field 		=> $money,
			];
			return Db::name('bonus')->insertGetId($data);
		}else{
			$data = [
				'time' => $time,
				$field => $bonus[$field] + $money
			];
			return Db::name('bonus')->where('id', $bonus['id'])->update($data);
		}
	}

}