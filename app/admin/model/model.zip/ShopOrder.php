<?php
namespace app\admin\model;

use think\Model;

class ShopOrder extends Model{
	public function getCreateTimeAttr($value, $data){
		return date('Y-m-d H:i:s', $value);
	}
	public function getSendTimeAttr($value, $data){
		if ($value) {
			return date('Y-m-d H:i:s', $value);
		}
		return '等待发货';
	}
	public function getGetTimeAttr($value, $data){
		if ($value) {
			return date('Y-m-d H:i:s', $value);
		}
		return '等待收货';
	}
	public function getStatusAAttr($value, $data){
    	$status = [
            '<span style="color:red;">待发货</span>', 
            '<span style="color:orange;">待收货</span>', 
    		'<span style="color:green;">已完成</span>',
    	];
        return $status[$data['status']];
    }
    public function getPayTypeAAttr($value, $data){
    	$pay_type = ['全现金', '全积分', '半现金半积分'];
        return $pay_type[$data['pay_type']];
    }
	public function getGoodsThumbAAttr($value, $data){
		if ($data['goods_thumb']) {
        	return __PUBLIC__.'/uploads/shop/'.$data['goods_thumb'];
        }
        return '';
	}
}